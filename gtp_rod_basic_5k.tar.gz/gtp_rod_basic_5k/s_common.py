import struct 

def enum(**enums):
    return type('Enum', (), enums)

if "__main__" == __name__:
    numbers = enum(ONE = 1, TWO = 2, THREE = 3)
    print numbers.ONE
    print numbers.TWO
    print numbers.THREE
