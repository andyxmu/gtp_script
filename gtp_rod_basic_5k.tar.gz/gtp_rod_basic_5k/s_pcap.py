#!/usr/bin/python
import string, glob, os, sys
import inspect
from ctypes import *

SNAP_LEN = 4096

class S_Pcap:
    def __init__(self):
        script_path = os.path.abspath(os.path.dirname(inspect.getfile(inspect.currentframe())))
        self.dll = CDLL(script_path + "/s_socket/s_pcap.so")

        # open socket
        self.dll.s_open_pcap.argtypes = [c_char_p, c_char_p, c_char_p]
        self.dll.s_open_pcap.restypes = [c_void_p]

        # close socket
        self.dll.s_close_pcap.argtypes = [c_void_p]

        # recv packet
        self.dll.s_recv_packet.argtypes = [c_void_p, POINTER(c_int)]
        self.dll.s_recv_packet.restypes = [c_char_p]

    def open(self, dev, filter_exp):
        #print "filter:" + filter_exp
        err_buf = create_string_buffer(SNAP_LEN)
        self.pcap = self.dll.s_open_pcap(dev, filter_exp, err_buf)

        if 0 == self.pcap:
            print "Socket %s open failure: %s"%(dev, string_at(err_buf, SNAP_LEN))
            return False
        return True

    def close(self):
        self.dll.s_close_pcap(self.pcap)
        self.s = c_int(0)

    def recv(self):
        rlen = c_int()
        data = self.dll.s_recv_packet(self.pcap, pointer(rlen))

        if c_int(0) == rlen:
            return ""

        return string_at(data, rlen)

if "__main__" == __name__:
    pcap = S_Pcap()

    pcap.open("eth2", "dst port 60000")

    count = 0
    while True:
        rcvbuff = pcap.recv()
        print "."
        if "" != rcvbuff:
            count += 1
            print "%d: bufflen=%d"%(count, len(rcvbuff))
            break

    print "good luck!!"
    pcap.close()


