import string, glob, os
import s_net_toolkit as s_net
import ipaddr
from ctypes import *
from struct import *

class S_Ip6_Ext_Hdr:
    pass

#   0 1 2 3 4 5 6 7 0 1 2 3 4 5 6 7 0 1 2 3 4 5 6 7 0 1 2 3 4 5 6 7:w
#   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
#   |Version| Traffic Class |           Flow Label                  |
#   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
#   |         Payload Length        |  Next Header  |   Hop Limit   |
#   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
#   |                                                               |
#   +                                                               +
#   |                                                               |
#   +                         Source Address                        +
#   |                                                               |
#   +                                                               +
#   |                                                               |
#   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
#   |                                                               |
#   +                                                               +
#   |                                                               |
#   +                      Destination Address                      +
#   |                                                               |
#   +                                                               +
#   |                                                               |
#   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
#

class S_Ip6:
    def __init__(self):
        self.version = 0x60         # version
        self.traffic_class = 0      # traffic class
        self.flow_label = 0         # flow label
        self.payload_len = 128      # The rest of the packet following this IPv6 header 
        self.next_hdr = 5           # next header
        self.hop_limit = 0xff       # hop limit
        self.set_ip("::1.1.1.1", "::2.2.2.2")
        #clear_ext_hdr()


    def set_data_len(self, length):
        self.payload_len = length
    
    #def clear_ext_hdr(self):
    #    self.ext_hdr = ""

    #def add_ext_hdr(self, hdr):
    #    self.ext_hdr += hdr

    # ip6 = 
    # style1: "a:b:c:d:e:f:g:h"
    # style2: "a:b::f:g:h"
    # style3: "a:b:c:d:e:f:1.1.1.1"
    # style4: "a:b::e:f:1.1.1.1"
    # style5: "::1.1.1.1"
    # style6: "::"
    def set_ip(self, src_ip6, dst_ip6):
        self.src_ip = ipaddr.IPv6Address(src_ip6)
        self.dst_ip = ipaddr.IPv6Address(dst_ip6)

    def set_proto(self, proto):
        self.next_hdr = proto

    def to_buffer(self):
        return pack("!BBHHBB", self.version, self.traffic_class, self.flow_label, self.payload_len, self.next_hdr, self.hop_limit) + self.src_ip.packed + self.dst_ip.packed

    def from_buffer(self, b):
        self.version = ord(b[0])
        self.traffic_class= ord(b[1])
        self.flow_label = unpack_from("!H", b, 2)[0]
        self.payload_len = unpack_from("!H", b, 4)[0]
        self.next_hdr= ord(b[6])
        self.hop_limit = ord(b[7])
        self.src_ip = ipaddr.IPv6Address(ipaddr.Bytes(b[8:24]))
        self.dst_ip = ipaddr.IPv6Address(ipaddr.Bytes(b[24:40])) 

        return b[40:]

    def dump(self):
        print "**IPv6**"
        print "|-->version=%d,traffic_class=%d,flow_label=%d"%(self.version, self.traffic_class, self.flow_label)
        print "|-->payload_len=%d,next_header=%d,hop_limit=%d"%(self.payload_len, self.next_hdr, self.hop_limit)
        print "|-->src_ip=" + repr(self.src_ip)
        print "|-->dst_ip=" + repr(self.dst_ip)

def main():
    ip = S_Ip6()
    ip.set_ip("::1.1.1.100", "::2.2.2.200")
    buf = ip.to_buffer()
    ip.dump()

    print "len=%d\n"%len(buf)
    ip2 = S_Ip6()
    ip2.from_buffer(buf)
    print repr(ip2.src_ip)
    print repr(ip2.dst_ip)


    ip2.dump()


if "__main__" == __name__:
    main()
