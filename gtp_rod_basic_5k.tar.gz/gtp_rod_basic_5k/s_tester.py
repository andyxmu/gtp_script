#!/bin/python
import string, os, s_ssh, re
import datetime

class Tester(object):
    TIMEOUT = 300

    WAIT_KEY = {"shell":re.compile("\[root@localhost.*\]#"),}
    #WAIT_KEY = {"shell":re.compile("root@.*%|root@%"),}

    def __init__(self, host, port, log):
        self.__host = host
        self.__port = port
        self.log = log
        self.__link = s_ssh.S_Ssh(self.TIMEOUT)   

    def set_log(self, log):
        self.log = log   

    def login(self, user, password):
        try:
            self.__link.login(self.__host, self.__port, user, password)

            keys = [self.WAIT_KEY["shell"],]

            result = self.__link.expect_l("", keys)

            # unexpect
            if result[0] < 0:
                print >> self.log, "Login Tester in a unexpect way, please check it."
                return False

            # shell
            return True
            
        except Exception, e:
            print "\n\nTester login Error---->\n"
            print e
            return False
        return True

    def do_shell(self, cmd):
        return self.__link.expect("%s\r\n"%cmd, self.WAIT_KEY["shell"])
            
    def logout(self):
        try:
            print >> self.log, self.__link.logout()
        except Exception, e:
            print >> self.log, "\n\nTester logout Error---->\n"
            print >> self.log, e

def do_test():
    import s_base_toolkit    
    log = s_base_toolkit.S_Log(datetime.datetime.now().strftime("Dut %Y-%m-%d %H-%M-%S.log"))
    tester = Tester("127.0.0.1", 22, log)

    if tester.login("root", "netscreen"):
        print tester.do_shell("cd ~/public")
        print tester.do_shell("ls -lart")
        tester.logout()
    
if "__main__" ==  __name__:
    do_test()
