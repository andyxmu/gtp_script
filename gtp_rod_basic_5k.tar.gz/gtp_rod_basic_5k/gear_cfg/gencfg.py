#!/usr/bin/python
#-*-coding: UTF-8-*-

import string, os, sys
import re
sys.path.append("../")
import s_cfg 
import xml.etree.ElementTree as ET 

XML_FILE = "/tmp/gtp_topo_config.xml"
def find_eth(content):
    f_eth = re.compile('eth\d')
    eth = []
    for line in content:
        match = f_eth.findall(line)
        if match:
            eth.append(match[0])
    return eth    

def find_ip(content):
    f_ip = re.compile('\d+\.\d+\.\d+\.\d+')
    ip_list = []
    for line in content:
        match = f_ip.findall(line)
        for ip in match:
            if not re.match('.*255.*', ip):
                ip_list.append(ip) 
    return ip_list       

def find_mac(content):
    #f_mac = re.compile("^([0-9A-F]{2}[:]){5}([0-9A-F]{2})$")
    f_mac = re.compile("[0-9a-fA-F]{2}:[0-9a-fA-F]{2}:[0-9a-fA-F]{2}:[0-9a-fA-F]{2}:[0-9a-fA-F]{2}:[0-9a-fA-F]{2}")
    mac = []
    for line in content:
        match = f_mac.findall(line)
        if match:
            mac.append(match[0])
    new_mac = []
    for id in mac:
        if id not in new_mac:
            new_mac.append(id)
    return new_mac

def read_file():
    fp = open("result.txt", 'r')
    #for line in fp:
    content = fp.readlines()
    find_eth(content)
    find_ip(content)
    find_mac(content)

def find_ge(content):
    f_ge = re.compile('ge-\d{1,2}\/\d{1,2}\/\d{1,2}')
    ge = []
    for line in content:
        match = f_ge.findall(line)
        if match:
            ge.append(match[0])
    new_ge = []
    for id in ge:
        if id not in new_ge:
            new_ge.append(id)
    return new_ge

def find_fpc(content):
    f_fpc = re.compile('Slot.*(\d{1,2}).*\s{3}.*SPC.*')
    fpc = [] 
    for line in content:
        match = f_fpc.findall(line)
        if match:
            fpc.append(match[0])   
    return fpc

def find_pic(content):
    f_pic = re.compile('PIC.*(\d{1,2}).*SPU Flow')
    pic = []
    for line in content:
        match = f_pic.findall(line)
        if match:
            pic.append(match[0])
    return pic 

def build_xml_tester():
    fp = open("/tmp/tester.txt", 'r')
    f_line = fp.readline().strip('\n')
    content = fp.readlines()
    root = ET.Element('gen_cfg')
    root.attrib['version'] = '1.0'
    tester = ET.SubElement(root, 'TESTER')
    mgt_info = f_line.split(' ')
    print mgt_info

    # Get mgt interface info
    mgt_inf = ET.SubElement(tester, 'MGT_INF')
    mgt_ip = ET.SubElement(mgt_inf, 'ip')
    mgt_ip.text = mgt_info[0]
    #mgt_port = ET.SubElement(mgt_inf, 'port')
    #mgt_port.text = mgt_info[1] 
    #mgt_user = ET.SubElement(mgt_inf, 'user')
    #mgt_user.text = mgt_info[2]
    #mgt_pass = ET.SubElement(mgt_inf, 'passwd')
    #mgt_pass.text = mgt_info[3]
    mgt_port = ET.SubElement(mgt_inf, 'port')
    mgt_port.text = '22' 
    mgt_user = ET.SubElement(mgt_inf, 'user')
    mgt_user.text = 'regress'
    mgt_pass = ET.SubElement(mgt_inf, 'passwd')
    mgt_pass.text = 'MaRtInI'

    # Get interface info
    eth = find_eth(content)
    iplist = find_ip(content)
    mac = find_mac(content)
    print eth
    print iplist
    print mac
    for i in range(len(eth)):
    #for e in eth:
       inf = ET.SubElement(tester, 'INF')
       inf_name = ET.SubElement(inf, 'if_name')
       inf_name.text = eth[i]
       ip_tag = ET.SubElement(inf, 'ip')
       ip_tag.text = iplist[i]
       mac_tag = ET.SubElement(inf, 'mac')
       mac_tag.text = mac[i]

    tree = ET.ElementTree(root)
    s_cfg.indent(root)
    tree.write(XML_FILE, encoding="UTF-8")
    fp.close()
    return True

def build_xml_dut():
    fp = open("/tmp/dut_info.txt", 'r')
    content = fp.readlines()
    tree = ET.parse(XML_FILE)
    root = tree.getroot()
    dut = ET.SubElement(root, "DUT")
    ge = find_ge(content)
    iplist = find_ip(content)
    mac_list = find_mac(content)
    fpc_list = find_fpc(content)
    pic_list = find_pic(content)

    print ge
    print iplist
    print mac_list
    print fpc_list
    print pic_list
    
    #manage ip and interface part 
    for i in range(len(iplist)):
        if i == 0:
            mgt_inf = ET.SubElement(dut, 'MGT_INF')
            ip_tag = ET.SubElement(mgt_inf, 'ip')
            ip_tag.text = iplist[0]
            port_tag = ET.SubElement(mgt_inf, 'port')
            port_tag.text = '22'
            usr_tag = ET.SubElement(mgt_inf, 'user')
            usr_tag.text = 'root'
            pass_tag = ET.SubElement(mgt_inf, 'passwd')
            pass_tag.text = 'Embe1mpls'
        else:
            inf_tag = ET.SubElement(dut, 'INF')
            inf_name = ET.SubElement(inf_tag, 'if_name')
            inf_name.text = ge[i-1]
            ip_tag = ET.SubElement(inf_tag, 'ip')
            ip_tag.text = iplist[i]
            mac_tag = ET.SubElement(inf_tag, 'mac')
            mac_tag.text = mac_list[i-1]

    #fpc & pic part 
    p = 0
    for f in fpc_list:
        spc_tag = ET.SubElement(dut, 'SPC')
        slot_num = ET.SubElement(spc_tag, 'slot_num')
        slot_num.text = f

        i = p
        while True:
            pic_tag = ET.SubElement(spc_tag, 'pic')
            pic_tag.text = pic_list[i]
            i += 1
            if((i >= len(pic_list)) or (pic_list[i] == '0')):
                p = i
                break
        
    s_cfg.indent(root)
    tree.write(XML_FILE, encoding="UTF-8")
    fp.close()
    return True


def pretty_xmlfile():
    parser = ET.XMLParser()
    xmlfile = ET.parse("tmp.xml", parser)
    pretty_xml = ET.tostring(xmlfile, encoding='UTF-8') 
    file = open("tmp.xml", 'w')
    file.writelines(pretty_xml)
    file.close()

if __name__ == "__main__":
    #read_file()
    build_xml_tester()
    #pretty_xmlfile()
    build_xml_dut()

