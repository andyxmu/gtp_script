#!/usr/bin/python
import string, glob, os, sys, re
import xml.etree.ElementTree as et
import pprint as pp
sys.path.append("../")
rm_xmlns = re.compile(" xmlns.*>")

def load(xml_file, objs):
    try:
        tree = et.ElementTree()
        root = tree.parse(xml_file)

        for obj in objs:
            obj.from_xml(root)
        return True
    except Exception, e:
        print e
        return False
    

def write(xml_file, objs):
    try:
        root = et.Element("gear_cfg")
        tree = et.ElementTree(root)

        for obj in objs:
            obj.to_xml(root)

        indent(root)
        tree.write(xml_file, "utf8")
        return True
    except Exception, e:
        print e
        return False

def print_topology(log, tester, dut):
    print >> log, "\n\n"
    print >> log, "x----------x                    x----------x"
    print >> log, "|          | %s      %s |          |"%(tester.net_ifs[0].if_name, dut.net_ifs[0].if_name)
    print >> log, "|          |--------------------|          |"
    print >> log, "|          |                    |          |"
    print >> log, "|  Tester  |                    |   Dut    |"
    print >> log, "|          | %s      %s |          |"%(tester.net_ifs[1].if_name, dut.net_ifs[1].if_name)
    print >> log, "|          |--------------------|          |"
    print >> log, "|          |                    |          |"
    print >> log, "x----------x                    x----------x"
    print >> log, "\n\n"


class Mgt_If(object):
    def __init__(self):
        self.ip = "1.1.1.1"
        self.port = 21
        self.user = "root"
        self.passwd = "netscreen1"

    @staticmethod
    def name():
        return "MGT_INF"

    def to_xml(self, root):
        node = et.Element(Mgt_If.name())
        child= et.Element("ip")
        child.text = self.ip
        node.append(child)

        child= et.Element("port")
        child.text = "%d"%self.port
        node.append(child)

        child = et.Element("user")
        child.text = self.user
        node.append(child)

        child = et.Element("passwd")
        child.text = self.passwd
        node.append(child)

        root.append(node)

    def from_xml(self, root):
        e = root.find(Mgt_If.name())
        self.ip = e.find("ip").text
        self.port = int(e.find("port").text)
        self.user = e.find("user").text
        self.passwd = e.find("passwd").text

    def dump(self):
        print Mgt_If.name()
        print " %s"%self.ip
        print " %d"%self.port
        print " %s"%self.user
        print " %s"%self.passwd

class Net_If(object):
    def __init__(self, if_name = "eth0", ip = "1.1.1.1", mac = "00:50:56:AC:00:68"):
        self.if_name = if_name
        self.ip = ip
        self.mac = mac

    @staticmethod
    def name():
        return "INF"

    def from_xml(self, e):
        #e = root.find(Net_If.name())
        self.if_name = e.find("if_name").text
        self.ip = e.find("ip").text
        self.mac = e.find("mac").text

    def to_xml(self, root):
        node = et.Element(Net_If.name())
        child = et.Element("if_name")
        child.text = self.if_name
        node.append(child)

        child = et.Element("ip")
        child.text = self.ip
        node.append(child)

        child = et.Element("mac")
        child.text = self.mac
        node.append(child)
        root.append(node)

    def dump(self):
        print Net_If.name()
        print " %s"%self.if_name
        print " %s"%self.ip
        print " %s"%self.mac

class Spc_Info(object):
    def __init__(self):
        self.slot_num = 0
        self.pics = []       

    @staticmethod
    def name():
        return "SPC"

    def from_xml(self, e):
        self.slot_num = int(e.find("slot_num").text)
        pics = e.findall("pic")
        for pic in pics:
            pic_num = int(pic.text)
            self.pics.append(pic_num)

    def to_xml(self, root):
        node = et.Element(Spc_Info.name())
        child = et.Element("slot_num")
        child.text = self.slot_num
        node.append(child)

        for pic in self.pics:
            child = et.Element("pic")
            child.text = pic
            node.append(child)
                
        root.append(node)

    def dump(self):
        print Spc_Info.name()
        print " Slot %d"%self.slot_num
        for pic in self.pics:
            print "  Pic %d "%pic

class Tester(object):
    def __init__(self):
        self.mgt_if = Mgt_If()
        self.mgt_if.ip_addr = "10.208.129.11"
        self.mgt_if.port = 21
        self.mgt_if.user = "root"
        self.mgt_if.passwd = "netscreen"
        self.net_ifs = [Net_If("eth1", "1.1.1.1", "00:50:56:AC:00:68"), Net_If("eth2", "2.2.2.2", "00:50:56:AC:00:7A")]

    @staticmethod
    def name():
        return "TESTER"

    def set_infs(self, infs):
        self.infs = infs

    def to_xml(self, root):
        node = et.Element(Tester.name())
        self.mgt_if.to_xml(node)

        for net_if in self.net_ifs:
            net_if.to_xml(node)
        root.append(node)
        
    def from_xml(self, root):
        e = root.find(Tester.name())
        self.mgt_if.from_xml(e)

        self.net_ifs = []
        if_es = e.findall(Net_If.name())
        for if_e in if_es:
            net_if = Net_If()
            net_if.from_xml(if_e)
            self.net_ifs.append(net_if)
        
    def dump(self):
        print Tester.name()
        self.mgt_if.dump()
        for net_if in self.net_ifs:
            net_if.dump()

class Dut(object):
    def __init__(self):
        self.mgt_if = Mgt_If()
        self.mgt_if.ip_addr = "10.208.130.234"
        self.mgt_if.port = 21
        self.mgt_if.user = "root"
        self.mgt_if.passwd = "netscreen1"
        self.net_ifs = [Net_If("ge-4/0/0", "1.1.1.100", "00:24:dc:20:55:28"), Net_If("ge-4/0/1", "2.2.2.100", "00:24:dc:20:55:29")]
        self.spc_list = []

    @staticmethod
    def name():
        return "DUT"

    def set_infs(self, infs):
        self.infs = infs

    def to_xml(self, root):
        node = et.Element(Dut.name())
        self.mgt_if.to_xml(node)

        for net_if in self.net_ifs:
            net_if.to_xml(node)
        root.append(node)
        
    def from_xml(self, root):
        e = root.find(Dut.name())
        self.mgt_if.from_xml(e)

        self.net_ifs = []
        if_es = e.findall(Net_If.name())
        for if_e in if_es:
            net_if = Net_If()
            net_if.from_xml(if_e)
            self.net_ifs.append(net_if)
        
        spc_es = e.findall(Spc_Info.name())
        for spc_e in spc_es:
            spc_info = Spc_Info()
            spc_info.from_xml(spc_e)
            self.spc_list.append(spc_info)
        
    def dump(self):
        print Dut.name()
        self.mgt_if.dump()
        for net_if in self.net_ifs:
            net_if.dump()
        for spc_info in self.spc_list:
            spc_info.dump()

# in-place prettyprint formatter
def indent(elem, level=0):
    i = "\n" + level*"  "
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = i + "  "
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
        for elem in elem:
            indent(elem, level+1)
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = i


if "__main__" == __name__:
    objs = [Tester(), Dut()]
    load("test.xml", objs)
    objs2 = [Tester(), Dut()]
    write("test.xml", objs2)
    objs2[0].dump()
    objs2[1].dump()

    load("gear_cfg/vm03-bjmud.xml", objs)
    objs[0].dump()
    objs[1].dump()


