import string, os, sys

class S_Log:
    def __init__(self, filename):
        self.fout = file(filename, 'w')

    def __del__(self):
        self.fout.close()
            
    def write(self, msg):        
        self.fout.write(msg)
        sys.stdout.write(msg)
