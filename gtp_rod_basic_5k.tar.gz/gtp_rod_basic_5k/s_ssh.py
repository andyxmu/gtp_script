import os, sys, string, time
import paramiko
import re

class S_Ssh:
    def __init__(self, timeout = 6):
        self.client = paramiko.SSHClient()
        self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.TIMEOUT = timeout
        

    def login(self, host, ssh_port, user, passwd):
        print "login..."
        self.client.connect(hostname = host, port = ssh_port, username = user, password = passwd)
        print "open session"
        self.ch = self.client.get_transport().open_session()
        self.ch.setblocking(0)
        self.ch.get_pty("Linux")
        self.ch.invoke_shell()
       
        
    def logout(self):
        print "close session"
        self.ch.close()
        print "close ssh"
        self.client.close()

    def expect(self, cmd, exp, timeout = -1):
        if -1 == timeout:
            timeout = self.TIMEOUT

        self.ch.settimeout(timeout)
        self.ch.send(cmd + "\n")                
        retry_times = 0

        text = ""

        while True:
            time.sleep(1)
            if self.ch.recv_ready():                
                retry_times += 1
                if retry_times >= timeout:
                    return "error: timeout"

                while True:
                    out = self.ch.recv(4096)
                    out_len = len(out)            
                    if out_len > 0:
                        text += out[0 : out_len]
                        if exp.search(text) >= 0:
                            return text
                    else:
                        break
            
            
        return "error: exception"

    def expect_l(self, cmd, list, timeout = -1):
        if -1 == timeout:
            timeout = self.TIMEOUT

        self.ch.settimeout(timeout)
        self.ch.send(cmd + "\n")                
        retry_times = 0

        text = ""

        list = list[:]
        indices = range(len(list))

        while True:
            time.sleep(1)
            if self.ch.recv_ready():                
                retry_times += 1
                if retry_times >= timeout:
                    return (-1, "error: timeout")

                while True:
                    out = self.ch.recv(1024)
                    out_len = len(out)            
                    if out_len > 0:
                        print out
                        text += out[0 : out_len]
                        for i in indices:
                            if list[i].search(text) >= 0:
                                return (i, text)                      
                    else:
                        break
        return (-1, "error: exception")

    

def main():
    #try:
        ssh = S_Ssh(6)
        exp = [re.compile("\[dev@china-sync"),
               re.compile("\[dev@china-sync")]

        #exp = re.compile("\[dev@china-sync")

       
        #exp = "[dev@china-sync "

        ssh.login("china-sync.juniper.net", "dev", "abcd1234")
        print 1
        #print ssh.send_cmd("pwd")
        print ssh.expect_l("pwd", exp)
        print 2
        #print ssh.send_cmd("ls")
        print ssh.expect_l("ls", exp)
        print 3
        #print ssh.cwd("../ericsong")
        print ssh.expect_l("cd ../ericsong", exp)
        print 4
        #print ssh.send_cmd("ls -l")
        print ssh.expect_l("ls -l", exp)
        print 5
        print ssh.expect_l("", exp)
        

        ssh.logout()

    #except Exception, e:
    #    print e        
        
if "__main__" == __name__:
    main()
