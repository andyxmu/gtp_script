import string, glob, os
import s_net_toolkit as s_net
import ipaddr
from ctypes import *
from struct import *

#
#        0      7 8     15 16    23 24    31  
#         +--------+--------+--------+--------+ 
#         |     Source      |   Destination   | 
#         |      Port       |      Port       | 
#         +--------+--------+--------+--------+ 
#         |                 |                 | 
#         |     Length      |    Checksum     | 
#         +--------+--------+--------+--------+ 
#         |                                     
#         |          data octets ...            
#         +---------------- ...                 
#


class S_Udp:
    def __init__(self):
        self.src_port = 1
        self.dst_port = 2
        self.length = 8
        self.chksum = 0     # in this version, not support chksum in UDP
        self.data = ""

    def set_port(self, src_port, dst_port):
        self.src_port = src_port
        self.dst_port = dst_port

    def set_payload(self, data):
        self.data = data
        self.length = len(data) + 8

    def do_chksum(self, buf):
        length = len(buf)
        n = 0
        checksum = 0
        
        while length :
            checksum += ((ord(buf[n]) << 8) + ord(buf[n+1]))
            n += 2
            length -= 2
            
            while 0xffff < checksum:
                checksum =  (checksum >> 16) + (checksum & 0xFFFF)
        
        self.chksum = 0xffff - checksum

    def to_buffer(self):
        return pack("!HHHH", self.src_port, self.dst_port, self.length, self.chksum) + self.data

    def from_buffer(self, b):
        self.src_port = unpack_from("!H", b, 0)[0]
        self.dst_port = unpack_from("!H", b, 2)[0]
        self.length = unpack_from("!H", b, 4)[0]
        self.chksum = unpack_from("!H", b, 6)[0]
        return b[9:]

    def dump(self):
        print "UDP:"
        print "src_port=%d,dst_port=%d"%(self.src_port, self.dst_port)
        print "length=%d,chksum=%x"%(self.length, self.chksum)

def main():
    udp = S_Udp()
    buf = udp.to_buffer()
    udp.set_port(5000, 6000)
    udp.set_data("1234")
    udp.dump()

    udp2 = S_Udp()
    udp2.from_buffer(buf)
    udp2.dump()
    print "len=%d\n"%len(buf)
    print repr(buf)

if "__main__" == __name__:
    main()
