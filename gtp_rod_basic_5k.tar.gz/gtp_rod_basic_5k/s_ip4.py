import string, glob, os
import s_net_toolkit as s_net
import ipaddr
from ctypes import *
from struct import *

class S_Ip4:
    def __init__(self):
        self.v_l = "\x45\x00"       # version + hdr_len
        self.total_len = 128        # need to be computed
        self.tag = 0                # pkt counter ++
        self.flag = "\x00\x00"      # fragment flag
        self.ttl = "\xfe"           # ttl = 254
        self.set_proto(0)           # sctp
        self.chksum = 0             # need to be computed
        self.set_ip("0.0.0.0", "0.0.0.0")
        self.buff = create_string_buffer(20)

    def set_data_len(self, length):
        self.total_len = length + 20

    def set_ip(self, src_ip, dst_ip):
        self.src_ip = ipaddr.IPv4Address(src_ip)
        self.dst_ip = ipaddr.IPv4Address(dst_ip)

    def set_proto(self, proto):
        self.protocol = proto

    def do_chksum(self, buf):
        length = len(buf)
        n = 0
        checksum = 0
        
        while length :
            checksum += ((ord(buf[n]) << 8) + ord(buf[n+1]))
            n += 2
            length -= 2
            
            while 0xffff < checksum:
                checksum =  (checksum >> 16) + (checksum & 0xFFFF)
        
        self.chksum = 0xffff - checksum

    def to_buffer(self):
        self.tag += 1
        self.chksum = 0
        pack_into("!2sHH2ssBH4s4s", self.buff, 0, self.v_l, self.total_len, self.tag, self.flag, self.ttl, self.protocol, self.chksum, self.src_ip.packed, self.dst_ip.packed)
        self.do_chksum(self.buff)
        pack_into("!H", self.buff, 10, self.chksum)
        return string_at(self.buff, 20) 

    def from_buffer(self, b):
        self.v_l = b[:2]
        self.total_len = unpack_from("!H", b, 2)[0]
        self.tag = unpack_from("!H", b, 4)[0]
        self.flag = b[6:8]
        self.ttl = b[8]
        self.protocol = ord(b[9])
        self.chksum = unpack_from("!H", b, 10)[0]
        self.src_ip = ipaddr.IPv4Address(ipaddr.Bytes(b[12:16]))
        self.dst_ip = ipaddr.IPv4Address(ipaddr.Bytes(b[16:20]))

        return b[((ord(self.v_l[0]) & 0x0F) << 2):]

    def dump(self):
        print "**IPv4**"
        print "|-->hdr_vl=[%x:%x],total_len=%d"%(ord(self.v_l[0]), ord(self.v_l[1]), self.total_len)
        print "|-->tag=%x,flag=[%x:%x]"%(self.tag, ord(self.flag[0]), ord(self.flag[1]))
        print "|-->ttl=%d,protocol=%d,chksum=0x%x"%(ord(self.ttl), self.protocol, self.chksum)
        print "|-->src_ip=%s"%repr(self.src_ip)
        print "|-->dst_ip=%s"%repr(self.dst_ip)
        

def main():
    ip = S_Ip4()
    buf = ip.to_buffer()
    ip.set_ip("1.1.1.1", "2.2.2.2")
    ip.dump()
    ip2 = S_Ip4()
    ip2.from_buffer(buf)
    ip2.dump()
    print "len=%d\n"%len(buf)
    print repr(buf)

if "__main__" == __name__:
    main()
