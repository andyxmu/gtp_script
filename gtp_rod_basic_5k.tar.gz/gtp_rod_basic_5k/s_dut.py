import string, os, s_ssh, re, s_cfg
import datetime

class Dut(object):
    TIMEOUT = 300

    WAIT_KEY = {"shell":re.compile("root@.*%|root@%"),
                "cli":re.compile("root@.*\>|root>"),
                "configure":re.compile("root@.*#|root#"),
                "spu":re.compile("\[flowd.*\].*\(vty\)#"),
                "login":re.compile("login:"),
                "password":re.compile("Password:")}

    SPU_NUM = 2
    
    def __init__(self, host, port, log):
        self.__host = host
        self.__port = port
        self.log = log
        self.__link = s_ssh.S_Ssh(self.TIMEOUT)  
        self.spc_list = []

    def set_log(self, log):
        self.log = log   

    def login(self, user, password):
        
        try:
            self.__link.login(self.__host, self.__port, user, password)

            keys = [self.WAIT_KEY["shell"],
                    self.WAIT_KEY["cli"],
                    self.WAIT_KEY["spu"],
                    self.WAIT_KEY["configure"]]

            result = self.__link.expect_l("", keys)

            # unexpect
            if result[0] < 0:
                print >> self.log, "Login Dut in a unexpect way, please check it."
                return False
            
            # cli
            if 1 == result[0]:
                 print >> self.log, self.exit_cli()

            # spu
            if 2 == result[0]:
                 print >> self.log, self.exit_spu()

            # configure
            if 3 == result[0]:
                 print >> self.log, self.exit_configure()
                 print >> self.log, self.exit_cli()
                

            # shell
            return True
            
        except Exception, e:
            print "\n\nDut login Error---->\n"
            print e
            return False
        return True

    def enter_cli(self):
        return self.__link.expect("cli", self.WAIT_KEY["cli"])

    # exit need \n to answer some question.
    def exit_cli(self):          
        return self.__link.expect("exit\n", self.WAIT_KEY["shell"])

    def enter_configure(self):
        return self.__link.expect("configure", self.WAIT_KEY["configure"])
    def exit_configure(self):          
        return self.__link.expect("exit\n", self.WAIT_KEY["cli"])

    def enter_spu(self, *args):
        if 1 == len(args):
            return self.enter_spu1(args[0])
        if 2 == len(args):
            return self.enter_spu2(args[0], args[1])

        if 3 == len(args):
            return self.enter_spu3(args[0], args[1], args[2])

    def enter_spu1(self, spu_id):
        return self.__link.expect("vty fpc5.pic%d"%spu_id, self.WAIT_KEY["spu"])

    def enter_spu2(self, spc_id, spu_id):
        return self.__link.expect("vty fpc%d.pic%d"%(spc_id, spu_id), self.WAIT_KEY["spu"])

    def enter_spu3(self, cluster, spc_id, spu_id):
        if cluster != 0xff:
            return self.__link.expect("vty node%d.fpc%d.pic%d"%(cluster, spc_id, spu_id), self.WAIT_KEY["spu"])
        else:
            return self.__link.expect("vty fpc%d.pic%d"%(spc_id, spu_id), self.WAIT_KEY["spu"])


    
    def exit_spu(self):
        return self.__link.expect("exit\n", self.WAIT_KEY["shell"])

    # do need \n to skip "----more----"
    def do_cli(self, cmd):
        return self.__link.expect("%s\n"%cmd, self.WAIT_KEY["cli"])

    def do_shell(self, cmd):
        return self.__link.expect("%s\n"%cmd, self.WAIT_KEY["shell"])

    def do_configure(self, cmd):
        return self.__link.expect("%s\n"%cmd, self.WAIT_KEY["configure"])

    def do_spu(self, cmd):
        return self.__link.expect("%s\n"%cmd, self.WAIT_KEY["spu"])

    def box_ready(self):                                                          
        # -->cli                                                                  
        print >> self.log, self.enter_cli()                                       
        print >> buf, self.do_cli("show chassis fpc pic-status")           
        print >> self.log, self.exit_cli()       
        p = re.compile(".*(Offline|Present|Ready).*")                             
        m = p.match(buf)                                                          
        if "None" == m:                                                           
            return True                                                                                  
        return False 

    def clean_box(self):
        # -->cli
        print >> self.log, self.enter_cli()
        #   -->configure
        print >> self.log, self.enter_configure()        
        print >> self.log, self.do_configure("load update /var/tmp/eric/sctp_disable.cfg")
        print >> self.log, self.do_configure("commit")
        print >> self.log, self.do_configure("load update /var/tmp/eric/sctp.cfg.0501")
        print >> self.log, self.do_configure("commit")
        #   -->configure
        print >> self.log, self.exit_configure()
        # -->cli
        print >> self.log, self.do_cli("clear log yflow")
        print >> self.log, self.do_cli("clear log ysec")
        print >> self.log, self.do_cli("clear security flow session all\nyes")
        print >> self.log, self.exit_cli()

        for spu_id in range(0, self.SPU_NUM):
            # -->spu
            print >> self.log, self.enter_spu(spu_id)
            print >> self.log, self.do_spu("debug us fl disable")
            print >> self.log, self.do_spu("undebug us sc detail")
            print >> self.log, self.do_spu("undebug us sc dump")
            print >> self.log, self.do_spu("cl us fl tr")
            print >> self.log, self.do_spu("cl us sc coun")
            print >> self.log, self.do_spu("cl us gfm sta")
            print >> self.log, self.do_spu("sh us fl tr 0")
            print >> self.log, self.do_spu("debug us fl en")
            print >> self.log, self.do_spu("debug us sc detail")
            print >> self.log, self.do_spu("debug us sc dump")
            print >> self.log, self.exit_spu()
            # -->spu

    def show_box(self):
        for spu_id in range(0, self.SPU_NUM):
            # -->spu
            print >> self.log, self.enter_spu(spu_id)
            print >> self.log, self.do_spu("sh us sc ass")
            print >> self.log, self.do_spu("sh us sc coun")
            print >> self.log, self.do_spu("sh us fl se")
            print >> self.log, self.do_spu("sh us gate all")
            print >> self.log, self.do_spu("sh us fl tr 0")
            print >> self.log, self.exit_spu()
            # -->spu
            
    def logout(self):
        try:
            print >> self.log, self.__link.logout()
        except Exception, e:
            print >> self.log, "\n\nDut logout Error---->\n"
            print >> self.log, e
        


def do_test2():
    import s_base_toolkit    
    log = s_base_toolkit.S_Log(datetime.datetime.now().strftime("Dut %Y-%m-%d %H-%M-%S.log"))
    #dut = Dut2("ts20.cnrd.juniper.net", 7029, log)
    dut = Dut("10.208.130.234", 22, log)

    if dut.login("root", "netscreen1"):
        #dut.clean_box()
        #raw_input("send packets...")
        dut.show_box()
        dut.logout()
    

if "__main__" ==  __name__:
    do_test2()
        
