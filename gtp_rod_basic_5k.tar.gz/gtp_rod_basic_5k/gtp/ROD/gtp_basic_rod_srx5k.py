#!/usr/bin/python
import string, glob, os, sys
import datetime, time
import unittest
sys.path.append("../../")
sys.path.append("../")
import s_net_toolkit as s_net
import s_base_toolkit
import s_gtp_dut, s_dut, s_cfg
import s_gtp, s_udp, s_ip, s_eth
import s_tunnel, s_gsn, s_gtp_scenario
import s_socket_daemon
import ipaddr
import ordered_dict
from struct import *
from ctypes import *
from s_gtp_scenario import * 

def suite():
    tests = ['test_ut1', 'test_ut2','test_ut3','test_ut4','test_ut5','test_ut6','test_ut7','test_ut8',
            'test_ut9','test_ut10','test_ut11','test_ut12','test_ut13','test_ut14', 'test_ut15']
    return unittest.TestSuite(map(GTP_BASIC, tests))

class GTP_BASIC(unittest.TestCase):
    def setUp(self):
        self.result = False
        self.scenario = s_gtp_scenario.S_ScenarioComm(log) 

        self.sgsn = s_gsn.S_Gsn(self.scenario.links[0])
        self.sgsn.ip_addr = "20.0.11.1"
        self.sgsn.ver = GTP_V1

        self.ggsn = s_gsn.S_Gsn(self.scenario.links[1])
        self.ggsn.ip_addr = "20.1.11.1"
        self.ggsn.ver = GTP_V1

        self.ho_sgsn = s_gsn.S_Gsn(self.scenario.links[0])
        self.ho_sgsn.ip_addr = "20.0.11.2"
        self.ho_sgsn.ver = GTP_V1

        self.sgsn_u = s_gsn.S_Gsn(self.scenario.links[0])
        self.sgsn_u.ip_addr = "20.0.1.2"
        self.sgsn_u.ver = GTP_V1

        self.ggsn_u = s_gsn.S_Gsn(self.scenario.links[1])
        self.ggsn_u.ip_addr = "20.1.11.1"
        self.ggsn_u.ver = GTP_V1

        self.scenario.clear_box()

    def tearDown(self):
        if not self.result:
            print >> self.scenario.dut.log, self.scenario.dut.enter_cli()
            #print >> self.scenario.dut.log, self.scenario.dut.do_cli("show log gtp_trace | no-more")
            print >> self.scenario.dut.log, self.scenario.dut.do_cli("show security gprs gtp counters all | no-more")
            print >> self.scenario.dut.log, self.scenario.dut.exit_cli()

        show_title("logout DUT")
        self.scenario.dut.logout()

    def test_ut1(self):
        for gtp_ver in range(GTP_V0, GTP_V2 + 1):
            show_ut_title("GTPv%d - Remote Tunnel Process(msg&ctnl&utnl on different spu)"%gtp_ver)

            self.scenario.context = s_tunnel.S_GtpCtxt()

            show_title("1. create tunnel.")
            self.scenario.context.ctnl.dl_teid = 0x2
            self.scenario.context.ctnl.dl_ip = "20.0.11.1"
            self.scenario.context.ctnl.ul_teid = 0x2
            self.scenario.context.ctnl.ul_ip = "20.1.11.1"

            utnl = s_tunnel.S_Tunnel("User")
            utnl.dl_teid = 0x1
            utnl.dl_ip = "20.0.11.1"
            utnl.ul_teid = 0x1
            utnl.ul_ip = "20.1.11.1"
            utnl.uid = 5
            utnl.pri_uid = 5
            
            self.scenario.context.add_utnl(utnl)

            self.sgsn.ip_addr = "20.0.11.2"
            self.sgsn.ver = gtp_ver

            self.ggsn.ip_addr = "20.1.11.2"
            self.ggsn.ver = gtp_ver

            if not self.scenario.create_context(self.sgsn, self.ggsn):
                print >> log, "**FAILURE**"
                return False

            show_title("2. update tunnel.")
            self.scenario.context.ctnl.dl_teid = 0x1
            self.scenario.context.ctnl.dl_ip = "20.0.11.2"
       
            self.scenario.context.utnl[0].dl_teid = 0x2
            self.scenario.context.utnl[0].dl_ip = "20.0.11.2"
            #  for GTPv2, utnl uplink endpoint should not change
            if gtp_ver != GTP_V2:
                self.scenario.context.utnl[0].ul_teid = 0x1
                self.scenario.context.utnl[0].ul_ip = "20.1.11.2"

            self.ggsn.ip_addr = "20.1.11.1" 
            self.ho_sgsn.ip_addr = "20.0.11.2"
            self.ho_sgsn.ver = gtp_ver
            if not self.scenario.update_context(self.ho_sgsn, self.ggsn, 0):
                print >> log, "**FAILURE**"
                return False

            show_title("3. delete tunnel.")
            if not self.scenario.delete_context(self.ho_sgsn, self.ggsn, 0):
                print >> log, "**FAILURE**"
                return False
       
        print >> log, "***[PASS]***     "
        self.result = True

    def test_ut2(self):
        show_ut_title("GTPv1 - Create Secondary PDP)")

        self.scenario.context = s_tunnel.S_GtpCtxt()

        show_title("1. create tunnel.")
        self.scenario.context.ctnl.dl_teid = 0x1
        self.scenario.context.ctnl.dl_ip = "20.0.11.1"
        self.scenario.context.ctnl.ul_teid = 0x1
        self.scenario.context.ctnl.ul_ip = "20.1.11.2"

        utnl = s_tunnel.S_Tunnel("User")
        utnl.dl_teid = 0x1
        utnl.dl_ip = "20.0.11.1"
        utnl.ul_teid = 0x1
        utnl.ul_ip = "20.1.11.1"
        utnl.uid = 5
        utnl.pri_uid = 5

        self.scenario.context.add_utnl(utnl)

        self.ggsn.ip_addr = "20.1.11.2"
        if not self.scenario.create_context(self.sgsn, self.ggsn):
            print >> log, "**FAILURE**"
            return False

        show_title("2. create secondary tunnels.")
        for i in range(1, 11):
            utnl = s_tunnel.S_Tunnel("User")
            utnl.dl_teid = self.scenario.context.utnl[0].dl_teid + i
            utnl.dl_ip = self.scenario.context.utnl[0].dl_ip
            utnl.ul_teid = self.scenario.context.utnl[0].ul_teid + i
            utnl.ul_ip = self.scenario.context.utnl[0].ul_ip
            utnl.uid = self.scenario.context.utnl[0].uid + i
            utnl.pri_uid = self.scenario.context.utnl[0].pri_uid
            
            self.scenario.context.add_utnl(utnl)
            if not self.scenario.create_sec_context(self.sgsn, self.ggsn):
                print >> log, "**FAILURE**" 
                return False

        show_title("2. update tunnel.")
        self.scenario.context.ctnl.dl_teid = 0x2 
        self.scenario.context.ctnl.dl_ip = "20.0.11.2"    
        
        self.ho_sgsn.ip_addr = "20.0.11.2"
        self.ho_sgsn.ver = GTP_V1
        for i in range(0, 11):
            utnl = self.scenario.context.utnl[i]
            utnl.dl_teid = utnl.dl_teid + 1 
            utnl.dl_ip = "20.0.11.2"

            if not self.scenario.update_context(self.ho_sgsn, self.ggsn, i):
                print >> log, "**FAILURE**"
                return False

        show_title("3. delete tunnel.")
        for i in range(1, 11):
            if not self.scenario.delete_context(self.ho_sgsn, self.ggsn, 1):
                print >> log, "**FAILURE**"
                return False
        
        if not self.scenario.delete_context(self.ho_sgsn, self.ggsn, 0):
            print >> log, "**FAILURE**"
            return False


        print >> log, "***[PASS]***     "
        self.result = True

    def test_ut3(self):
        show_ut_title("GTPv2 - Create Multiple PDP)")

        show_title("1. create tunnel.")
        self.scenario.context = s_tunnel.S_GtpCtxt()
        self.scenario.context.ctnl.dl_teid = 0x1 
        self.scenario.context.ctnl.dl_ip = "20.0.11.1"
        self.scenario.context.ctnl.ul_teid = 0x1 
        self.scenario.context.ctnl.ul_ip = "20.1.11.2"
                
        utnl_dl_teid = 0x1 
        utnl_dl_ip = "20.0.11.1"
        utnl_ul_teid = 0x1 
        utnl_ul_ip = "20.1.11.1"
        utnl_uid = 5
        utnl_pri_uid = 5
                
        for i in range(0, 11):
            utnl = s_tunnel.S_Tunnel("User")
            utnl.dl_teid = utnl_dl_teid + 2*i 
            utnl.dl_ip = utnl_dl_ip
            utnl.ul_teid = utnl_ul_teid + 2*i 
            utnl.ul_ip = utnl_ul_ip
            utnl.uid = utnl_uid + i
            utnl.pri_uid = utnl_pri_uid
            self.scenario.context.add_utnl(utnl)
                        
        self.sgsn.ip_addr = "20.0.11.1"
        self.sgsn.ver = GTP_V2            
        self.ggsn.ip_addr = "20.1.11.2"
        self.ggsn.ver = GTP_V2
             
        if not self.scenario.create_context(self.sgsn, self.ggsn):
            print >> log, "**FAILURE**"
            return False

        show_title("2. update tunnel.")
        self.scenario.context.ctnl.dl_teid = 0x2
        self.scenario.context.ctnl.dl_ip = "20.0.11.2"                  
        for utnl in self.scenario.context.utnl:
            utnl.dl_teid = utnl.dl_teid + 1 
            utnl.dl_ip = "20.0.11.2"

        self.ho_sgsn.ip_addr = "20.0.11.2"
        self.ho_sgsn.ver = GTP_V2
        if not self.scenario.update_context(self.ho_sgsn, self.ggsn):
            print >> log, "**FAILURE**"
            return False

        show_title("3. delete tunnel.")
        if not self.scenario.delete_context(self.ho_sgsn, self.ggsn):
            print >> log, "**FAILURE**"
            return False

        print >> log, "***[PASS]***     "
        self.result = True

    def test_ut4(self):
        for gtp_ver in range(GTP_V0, GTP_V2 + 1):
            show_ut_title("GTPv%d - Conflict Tunnel Remote Process"%gtp_ver)
                        
            show_title("1. ctnl conflict.")
            context = s_tunnel.S_GtpCtxt()
            context.ctnl.dl_teid = 0x1
            context.ctnl.dl_ip = "20.0.11.1"
            context.ctnl.ul_teid = 0x1
            context.ctnl.ul_ip = "20.1.11.2"

            utnl = s_tunnel.S_Tunnel("User")
            utnl.dl_teid = 0x2
            utnl.dl_ip = "20.0.11.1"
            utnl.ul_teid = 0x2
            utnl.ul_ip = "20.1.11.1"
            utnl.uid = 5
            utnl.pri_uid = 5
            context.add_utnl(utnl)

            self.sgsn.ip_addr = "20.0.11.2"
            self.sgsn.ver = gtp_ver

            self.ggsn.ip_addr = "20.1.11.2"
            self.ggsn.ver = gtp_ver

            self.scenario.context = context
            if not self.scenario.create_context(self.sgsn, self.ggsn):
                print >> log, "**FAILURE**"
                return False
                                                
            context.ctnl.dl_ip = "20.0.11.2"
            if not self.scenario.create_context(self.sgsn, self.ggsn):
                print >> log, "**FAILURE**"
                return False
                        
            show_title("2. utnl conflict.")
            context.ctnl.dl_teid = 0x2
            context.ctnl.dl_ip = "20.0.11.2"
            context.ctnl.ul_teid = 0x3
            context.ctnl.ul_ip = "20.1.11.2"
            if not self.scenario.create_context(self.sgsn, self.ggsn):
                print >> log, "**FAILURE**"
                return False

            if not self.scenario.delete_context(self.sgsn, self.ggsn, 0):
                print >> log, "**FAILURE**"
                return False

        print >> log, "***[PASS]***     "
        self.result = True

    def test_ut5(self):
        show_ut_title("GTPv1 - Conflict in same context")
        self.scenario.context = s_tunnel.S_GtpCtxt()

        show_title("1. create primary tunnel.")
        self.scenario.context.ctnl.dl_teid = 0x1
        self.scenario.context.ctnl.dl_ip = "20.0.11.1"
        self.scenario.context.ctnl.ul_teid = 0x1
        self.scenario.context.ctnl.ul_ip = "20.1.11.2"
    
        utnl = s_tunnel.S_Tunnel("User")
        utnl.dl_teid = 0x1
        utnl.dl_ip = "20.0.11.1"
        utnl.ul_teid = 0x1
        utnl.ul_ip = "20.1.11.1"
        utnl.uid = 5
        utnl.pri_uid = 5      
        self.scenario.context.add_utnl(utnl)

        self.ggsn.ip_addr = "20.1.11.2"
        if not self.scenario.create_context(self.sgsn, self.ggsn):
            print >> log, "**FAILURE**"
            return False

        show_title("2. create secondary tunnels.")
        utnl = s_tunnel.S_Tunnel("User")
        utnl.dl_teid = self.scenario.context.utnl[0].dl_teid + 1
        utnl.dl_ip = self.scenario.context.utnl[0].dl_ip
        utnl.ul_teid = self.scenario.context.utnl[0].ul_teid + 1
        utnl.ul_ip = self.scenario.context.utnl[0].ul_ip
        utnl.uid = self.scenario.context.utnl[0].uid + 1
        utnl.pri_uid = self.scenario.context.utnl[0].pri_uid
            
        self.scenario.context.add_utnl(utnl)
        if not self.scenario.create_sec_context(self.sgsn, self.ggsn):
            print >> log, "**FAILURE**"
            return False
                
        show_title("3. create conflict secondary tunnels. to conflict secondary tunnel")
        self.scenario.context.utnl[1].uid = self.scenario.context.utnl[1].uid + 1
        
        if not self.scenario.create_sec_context(self.sgsn, self.ggsn):
            print >> log, "**FAILURE**"
            return False
               
        show_title("4. create conflict secondary tunnels.to conflict primary tunnel")
        self.scenario.context.utnl[1].uid = self.scenario.context.utnl[0].uid
        
        if self.scenario.create_sec_context(self.sgsn, self.ggsn):
            print >> log, "**FAILURE**"
            return False
 
        print >> log, "***[PASS]***     "
        self.result = True

    def test_ut6(self):
        show_ut_title("GTP - Handover between different version")
        self.scenario.context = s_tunnel.S_GtpCtxt()

        show_title("1. create gtpv0 tunnel.")
        self.scenario.context.ctnl.dl_teid = 0x2
        self.scenario.context.ctnl.dl_ip = "20.0.11.1"
        self.scenario.context.ctnl.ul_teid = 0x2
        self.scenario.context.ctnl.ul_ip = "20.1.11.1"

        utnl = s_tunnel.S_Tunnel("User")
        utnl.dl_teid = 0x1
        utnl.dl_ip = "20.0.11.1"
        utnl.ul_teid = 0x1
        utnl.ul_ip = "20.1.11.1"
        utnl.uid = 5
        utnl.pri_uid = 5
        self.scenario.context.add_utnl(utnl)

        self.sgsn.ip_addr = "20.0.11.2"
        self.sgsn.ver = GTP_V0

        self.ggsn.ip_addr = "20.1.11.2"
        self.ggsn.ver = GTP_V0

        if not self.scenario.create_context(self.sgsn, self.ggsn):
            print >> log, "**FAILURE**"
            return False
                        
        show_title("2. update tunnel from v0 to v1.")
        self.scenario.context.ctnl.dl_teid = 0x2
        self.scenario.context.ctnl.dl_ip = "20.0.11.2"

        self.scenario.context.utnl[0].dl_teid = 0x2
        self.scenario.context.utnl[0].dl_ip = "20.0.11.2"
        self.scenario.context.utnl[0].ul_teid = 0x2
        self.scenario.context.utnl[0].ul_ip = "20.1.11.2"

        self.ggsn.ip_addr = "20.1.11.1"
        self.ggsn.ver = GTP_V1
        self.ho_sgsn.ip_addr = "20.0.11.2"
        self.ho_sgsn.ver = GTP_V1
        if not self.scenario.update_context(self.ho_sgsn, self.ggsn, 0):
            print >> log, "**FAILURE**"
            return False

        show_title("3. update tunnel from v1 to v2.")
        self.scenario.context.ctnl.dl_teid = 0x3
        self.scenario.context.ctnl.dl_ip = "20.0.11.3"

        self.scenario.context.utnl[0].dl_teid = 0x3
        self.scenario.context.utnl[0].dl_ip = "20.0.11.3"

        self.ggsn.ip_addr = "20.1.11.1"
        self.ggsn.ver = GTP_V2
        self.ho_sgsn.ip_addr = "20.0.11.3"
        self.ho_sgsn.ver = GTP_V2
        if not self.scenario.update_context(self.ho_sgsn, self.ggsn, 0):
            print >> log, "**FAILURE**"
            return False
                
        show_title("4. update tunnel from v2 to v1.")
        self.scenario.context.ctnl.dl_teid = 0x4
        self.scenario.context.ctnl.dl_ip = "20.0.11.4"

        self.scenario.context.utnl[0].dl_teid = 0x4
        self.scenario.context.utnl[0].dl_ip = "20.0.11.4"

        self.ggsn.ip_addr = "20.1.11.1"
        self.ggsn.ver = GTP_V1
        self.ho_sgsn.ip_addr = "20.0.11.4"
        self.ho_sgsn.ver = GTP_V1
        if not self.scenario.update_context(self.ho_sgsn, self.ggsn, 0):
            print >> log, "**FAILURE**"
            return False

        self.scenario.clear_box()

        show_title("5. create gtpv0 tunnel (2nd time).")
        self.scenario.context.ctnl.dl_teid = 0x2
        self.scenario.context.ctnl.dl_ip = "20.0.11.1"
        self.scenario.context.ctnl.ul_teid = 0x2
        self.scenario.context.ctnl.ul_ip = "20.1.11.1"

        utnl = s_tunnel.S_Tunnel("User")
        utnl.dl_teid = 0x1
        utnl.dl_ip = "20.0.11.1"
        utnl.ul_teid = 0x1
        utnl.ul_ip = "20.1.11.1"
        utnl.uid = 5
        utnl.pri_uid = 5
        self.scenario.context.add_utnl(utnl)

        self.sgsn.ip_addr = "20.0.11.2"
        self.sgsn.ver = GTP_V1

        self.ggsn.ip_addr = "20.1.11.2"
        self.ggsn.ver = GTP_V1

        if not self.scenario.create_context(self.sgsn, self.ggsn):
            print >> log, "**FAILURE**"
            return False

        show_title("6. update tunnel from v0 to v2.")
        self.scenario.context.ctnl.dl_teid = 0x6
        self.scenario.context.ctnl.dl_ip = "20.0.11.6"

        self.scenario.context.utnl[0].dl_teid = 0x6
        self.scenario.context.utnl[0].dl_ip = "20.0.11.6"

        self.ggsn.ip_addr = "20.1.11.1"
        self.ggsn.ver = GTP_V2
        self.ho_sgsn.ip_addr = "20.0.11.6"
        self.ho_sgsn.ver = GTP_V2
        if not self.scenario.update_context(self.ho_sgsn, self.ggsn, 0):
            print >> log, "**FAILURE**"
            return False

        print >> log, "***[PASS]***     "
        self.result = True

    def test_ut7(self):
        show_ut_title("GTPv0 - GTP-U Signalling messages")
        self.sgsn.ip_addr = "20.0.2.13"
        self.sgsn.ver = GTP_V0
        self.ggsn.ip_addr = "20.1.12.12"
        self.ggsn.ver = GTP_V0

        if not self.scenario.echo_msg(self.sgsn, self.ggsn):
            print >> log, "**FAILURE**"
            self.scenario.dut.show_flow_session()
            return False
        self.scenario.dut.show_flow_session()

        show_ut_title("GTPv1 - GTP-U Signalling messages")
        self.sgsn.ip_addr = "20.0.2.11"
        self.sgsn.ver = GTP_V1_U 
        self.ggsn.ip_addr = "20.1.12.10"
        self.ggsn.ver = GTP_V1_U

        if not self.scenario.echo_msg(self.sgsn, self.ggsn):
            print >> log, "**FAILURE**"
            self.scenario.dut.show_flow_session()
            return False
        self.scenario.dut.show_flow_session()

        print >> log, "***[PASS]***     "
        self.result = True

    def test_ut8(self):
        show_ut_title("GTPv0 - GTP-U Data message distribution")

        show_title("1. create context")
        self.sgsn.ip_addr = "20.0.2.10"
        self.sgsn.ver = GTP_V0
        self.ggsn.ip_addr = "20.1.12.11"
        self.ggsn.ver = GTP_V0

        self.scenario.context = s_tunnel.S_GtpCtxt()
        self.scenario.context.ctnl.dl_teid = 0x2
        self.scenario.context.ctnl.dl_ip = "20.0.2.10"
        self.scenario.context.ctnl.ul_teid = 0x2
        self.scenario.context.ctnl.ul_ip = "20.1.12.11"

        utnl = s_tunnel.S_Tunnel("User")
        utnl.dl_teid = 0x2
        utnl.dl_ip = "20.0.2.10"
        utnl.ul_teid = 0x2
        utnl.ul_ip = "20.1.12.12"
        utnl.uid = 5
        utnl.pri_uid = 5
        self.scenario.context.add_utnl(utnl)

        if not self.scenario.create_context(self.sgsn, self.ggsn):
            print >> log, "**FAILURE**"
            return False
        self.scenario.dut.show_debug_info()
        #self.scenario.dut.clear_trace()

        show_title("2. send GTP-U packets.")

        self.sgsn_u.ip_addr = "20.0.2.10"
        self.sgsn_u.ver = GTP_V0
        self.ggsn_u.ip_addr = "20.1.12.12"
        self.ggsn_u.ver = GTP_V0

        if not self.scenario.send_data_traffic(self.sgsn_u, self.ggsn_u, 0):
            print >> log, "**FAILURE**"
            #self.scenario.dut.show_debug_info()
            return False

        if not self.scenario.delete_context(self.sgsn, self.ggsn, 0):
            print >> log, "**FAILURE**"
            return False

        self.scenario.dut.show_debug_info()

        print >> log, "***[PASS]***     "
        self.result = True

    def test_ut9(self):
        show_ut_title("GTPv1 - GTP-U Data message distribution")

        show_title("1. create context")
        self.sgsn.ip_addr = "20.0.2.10"
        self.sgsn.ver = GTP_V1
        self.ggsn.ip_addr = "20.1.12.11"
        self.ggsn.ver = GTP_V1

        self.scenario.context = s_tunnel.S_GtpCtxt()
        self.scenario.context.ctnl.dl_teid = 0x2 
        self.scenario.context.ctnl.dl_ip = "20.0.2.10"
        self.scenario.context.ctnl.ul_teid = 0x2 
        self.scenario.context.ctnl.ul_ip = "20.1.12.11"

        utnl = s_tunnel.S_Tunnel("User")
        utnl.dl_teid = 0x2 
        utnl.dl_ip = "20.0.2.10"
        utnl.ul_teid = 0x2 
        utnl.ul_ip = "20.1.12.11"
        utnl.uid = 5 
        utnl.pri_uid = 5 
        self.scenario.context.add_utnl(utnl)

        if not self.scenario.create_context(self.sgsn, self.ggsn):
            print >> log, "**FAILURE**"
            return False
        
        self.scenario.dut.show_debug_info()

        utnl = s_tunnel.S_Tunnel("User")
        utnl.dl_teid = 0x3
        utnl.dl_ip = "20.0.2.10"
        utnl.ul_teid = 0x3
        utnl.ul_ip = "20.1.12.12"
        utnl.uid = 6
        utnl.pri_uid = 5
        self.scenario.context.add_utnl(utnl)

        show_title("2. create secondary U")
        if not self.scenario.create_sec_context(self.sgsn, self.ggsn):
            print >> log, "**FAILURE**"
            return False
                                       
        self.sgsn_u.ip_addr = "20.0.2.10"
        self.sgsn_u.ver = GTP_V1_U
        self.ggsn_u.ip_addr = "20.1.12.11"
        self.ggsn_u.ver = GTP_V1_U
        if not self.scenario.send_data_traffic(self.sgsn_u, self.ggsn_u, 0):
            print >> log, "**FAILURE**"
            return False

        self.scenario.dut.show_tunnel()

        self.ggsn_u.ip_addr = "20.1.12.12"
                                        
        if not self.scenario.send_data_traffic(self.sgsn_u, self.ggsn_u, 1):
            print >> log, "**FAILURE**"
            return False

        self.scenario.dut.show_tunnel()
        if not self.scenario.delete_context(self.sgsn, self.ggsn, 1):
            print >> log, "**FAILURE**"
            return False

        if not self.scenario.delete_context(self.sgsn, self.ggsn, 0):
            print >> log, "**FAILURE**"
            return False

        self.scenario.dut.show_flow_session()

        print >> log, "***[PASS]***     "
        self.result = True

    def test_ut10(self):
        show_ut_title("GTPv2 - GTP-U Data message distribution")

        show_title("1. create context")
        self.sgsn.ip_addr = "20.0.2.10"
        self.sgsn.ver = GTP_V2
        self.ggsn.ip_addr = "20.1.12.11"
        self.ggsn.ver = GTP_V2

        self.scenario.context = s_tunnel.S_GtpCtxt()
        self.scenario.context.ctnl.dl_teid = 0x2 
        self.scenario.context.ctnl.dl_ip = "20.0.2.10"
        self.scenario.context.ctnl.ul_teid = 0x2 
        self.scenario.context.ctnl.ul_ip = "20.1.12.11"

        utnl = s_tunnel.S_Tunnel("User")
        utnl.dl_teid = 0x2 
        utnl.dl_ip = "20.0.2.10"
        utnl.ul_teid = 0x2 
        utnl.ul_ip = "20.1.12.11"
        utnl.uid = 5 
        utnl.pri_uid = 5 
        self.scenario.context.add_utnl(utnl)

        utnl = s_tunnel.S_Tunnel("User")
        utnl.dl_teid = 0x3
        utnl.dl_ip = "20.0.2.10"
        utnl.ul_teid = 0x3
        utnl.ul_ip = "20.1.12.12"
        utnl.uid = 6
        utnl.pri_uid = 5
        self.scenario.context.add_utnl(utnl)

        if not self.scenario.create_context(self.sgsn, self.ggsn):
            print >> log, "**FAILURE**"
            return False
                        
        self.sgsn_u.ip_addr = "20.0.2.10"
        self.sgsn_u.ver = GTP_V1_U
        self.ggsn_u.ip_addr = "20.1.12.11"
        self.ggsn_u.ver = GTP_V1_U
        if not self.scenario.send_data_traffic(self.sgsn_u, self.ggsn_u, 0):
            print >> log, "**FAILURE**"
            return False
                                        
        self.ggsn_u.ip_addr = "20.1.12.12"
        if not self.scenario.send_data_traffic(self.sgsn_u, self.ggsn_u, 1):
            print >> log, "**FAILURE**"
            return False

        if not self.scenario.delete_context(self.sgsn, self.ggsn, 0):
            print >> log, "**FAILURE**"
            return False

        self.scenario.dut.show_flow_session()

        print >> log, "***[PASS]***     "
        self.result = True

    def test_ut11(self):
        show_ut_title("GTPv1 - GTP-U Data message only")
        self.scenario.dut.set_config_cmd("delete security forwarding-process application-services enable-gtpu-distribution")
        self.scenario.dut.set_config_cmd("delete security gprs gtp profile gtp1 seq-number-validated")

        self.scenario.context = s_tunnel.S_GtpCtxt()
        utnl = s_tunnel.S_Tunnel("User")
        utnl.dl_teid = 0x2                   # downlink GTP-U traffic distributed by dl_teid
        utnl.dl_ip = "20.0.2.10"             # ip addr in ip header
        utnl.ul_teid = 0x2                   # uplink GTP-U traffic distributed by ul_teid
        utnl.ul_ip = "20.1.12.11"            # ip addr in ip header
        utnl.uid = 5
        utnl.pri_uid = 5
        self.scenario.context.add_utnl(utnl)

        self.sgsn_u.ip_addr = utnl.dl_ip   
        self.sgsn_u.ver = GTP_V1_U
        self.ggsn_u.ip_addr = utnl.ul_ip   
        self.ggsn_u.ver = GTP_V1_U

        for i in range(0, 100):
            utnl.dl_teid = utnl.dl_teid + 1
            utnl.ul_teid = utnl.ul_teid + 1
            if not self.scenario.send_data_traffic(self.sgsn_u, self.ggsn_u, 0):
                print >> log, "**FAILURE**"
                return False
            
        self.scenario.dut.show_flow_session()
        self.scenario.dut.set_config_cmd("set security forwarding-process application-services enable-gtpu-distribution")
        self.scenario.dut.set_config_cmd("set security gprs gtp profile gtp1 seq-number-validated")

        print >> log, "***[PASS]***     "
        self.result = True

def show_title(msg):
    print >> log, "\n\n******************************************"
    print >> log, msg
    print >> log, "******************************************"

def show_ut_title(msg):
    print >> log, "\n\n||||||||||||||||||||||||||||||||||||||||||"
    print >> log, "++++++++++++++++++++++++++++++++++++++++++"

    print >> log, msg

    print >> log, "++++++++++++++++++++++++++++++++++++++++++"
    print >> log, "||||||||||||||||||||||||||||||||||||||||||"

log = s_base_toolkit.S_Log(datetime.datetime.now().strftime("log/gtp-%Y-%m-%d_%H-%M-%S.log"))
if "__main__" == __name__:
    unittest.main()
