#!/usr/bin/python
import string, glob, os, sys, getopt
import datetime, time
import unittest
sys.path.append("gtp_basic_rod_srx5k")
import gtp_basic_rod_srx5k 

MAX_TEST_CASE_NUM = 12
def usage():
    print "Usage: %s [-h]|args "%sys.argv[0]      
    print "The following test cases are supported!"
    print "  TC1 ------ Remote Tunnel Process(msg&ctnl&utnl on different spu)"
    print "  TC2 ------ GTPv1 - Create Secondary PDP)"
    print "  TC3 ------ GTPv2 - Create Multiple PDP)"
    print "  TC4 ------ Conflict Tunnel Remote Process"
    print "  TC5 ------ GTPv1 - Conflict in same context"
    print "  TC6 ------ GTP - Handover between different version"
    print "  TC7 ------ GTPv1 - GTP-U Signalling messages"
    print "  TC8 ------ GTPv0 - GTP-U Data message distribution"
    print "  TC9 ------ GTPv1 - GTP-U Data message distribution"
    print "  TC10 ------ GTPv2 - GTP-U Data message distribution"
    print "  TC11 ------ GTPv1 - GTP-U Data message only"

def name_change(string):
    if string.lower() == "all":
        return gtp_basic_rod_srx5k.suite()
    else:
        for i in range(1, MAX_TEST_CASE_NUM):
            cur_str = "TC" + str(i)
            tc_str = "test_ut" + str(i)
            if string.lower() == cur_str.lower():
                return unittest.TestSuite(map(gtp_basic_rod_srx5k.GTP_BASIC, [tc_str]))
        print "Testcase is not defined yet!"
    sys.exit()

def param_op():
    opts, args = getopt.getopt(sys.argv[1:], "h")
    for opt, value in opts:
        if opt == "-h":
            usage()
            sys.exit()
    
    if len(sys.argv) == 1:
        print "At leaset one parameter (test case name) is required,..... Try %s -h"%sys.argv[0]
        sys.exit()
    elif len(sys.argv) > 2:
        print "how generous you are, but we need only one parameter :)"
        sys.exit()
    
    func_name = name_change(sys.argv[1])
    return func_name

def main():
#suite = rli21748_ut.suite()                                                             
    suite = param_op()
    unittest.TextTestRunner(verbosity=2).run(suite)

if __name__ == "__main__":
    main()


