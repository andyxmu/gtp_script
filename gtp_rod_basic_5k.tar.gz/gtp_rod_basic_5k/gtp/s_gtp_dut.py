#!/usr/bin/python
import string, glob, os, sys
import datetime, time
import unittest
sys.path.append("../../")
sys.path.append("../")
import s_gtp
import s_dut
import s_net_toolkit as s_net
import s_base_toolkit
import s_udp, s_ip, s_eth
import s_socket_daemon
import ipaddr
import ordered_dict
from struct import *
from ctypes import *

gear_cfg_file = "../../gear_cfg/vm01-rake.xml"

class Gtp_Dut(s_dut.Dut):
    def show_vty_cmd_all(self, cmd):
        print >> self.log, self.do_shell("srx-cprod.sh -s spu -c '%s'"%cmd)

    def show_vsrx_vty_cmd_all(self, cmd):
        print >> self.log, self.do_shell("cprod -A fpc0 -c '%s'"%cmd)

    def show_gsn(self):
        print >> self.log, self.enter_cli()
        print >> self.log, self.do_cli("show security gprs gtp gsn statistics | no-more")
        print >> self.log, self.exit_cli()
        self.show_vty_cmd_all('show usp gtp gsn content')

    def show_tunnel(self):
        self.show_vty_cmd_all("show usp gtp redir")
        print >> self.log, self.enter_cli()
        print >> self.log, self.do_cli("show security gprs gtp tunnels | no-more")
        print >> self.log, self.exit_cli()
        self.show_vty_cmd_all('show usp gtp tunnels')
        self.show_vty_cmd_all('show usp gtp tunnelc')
   
    def show_counter(self):
        print >> self.log, self.enter_cli()
        print >> self.log, self.do_cli("show security gprs gtp counters all | no-more")
        print >> self.log, self.exit_cli()

    def show_flow_session(self):
        print >> self.log, self.enter_cli()
        print >> self.log, self.do_cli("show security flow session | no-more")
        print >> self.log, self.exit_cli()
        self.show_vty_cmd_all('show usp flow session')

    def show_vty_counter(self):
        self.show_vty_cmd_all("show usp gtp counter summary")

    def clear_tunnel(self):
        print >> self.log, self.enter_cli()
        print >> self.log, self.do_cli("clear security gprs gtp tunnel all")
        print >> self.log, self.exit_cli()

    def clear_gsn(self):
        print >> self.log, self.enter_cli()
        print >> self.log, self.do_cli("clear security gprs gtp gsn all")
        print >> self.log, self.exit_cli()

    def clear_counter(self):
        print >> self.log, self.enter_cli()
        print >> self.log, self.do_cli("clear security gprs gtp counters all")
        print >> self.log, self.exit_cli()

    def clear_trace(self):
        print >> self.log, self.enter_cli()
        print >> self.log, self.do_cli("clear log gtp_trace")
        print >> self.log, self.do_cli("clear log flow_trace")
        print >> self.log, self.exit_cli()

    def clear_session(self):
        print >> self.log, self.enter_cli()
        print >> self.log, self.do_cli("clear security flow session")
        print >> self.log, self.exit_cli()

    def clear_env(self):
        self.clear_tunnel()
        self.clear_gsn()
        self.clear_counter()
        self.clear_trace()
        self.clear_session()

    def set_dbg_op(self, op, cluster = 0xff, spu_id = 0xff, pic = 0):
        self.set_vty_cmd("debug usp gtp db-opt %d"%op, cluster, spu_id, pic)

    def clear_dbg_op(self, cluster = 0xff, spu_id = 0xff, pic = 0):
        self.set_vty_cmd("undebug usp gtp db-opt", cluster, spu_id, pic)

    def show_debug_info(self):
        self.show_tunnel()
        self.show_flow_session()
        self.show_gsn()
        self.show_counter()
        #self.show_vty_counter(cluster)

    def set_vty_cmd(self, cmd, cluster = 0xff, spu_id = 0xff, pic = 0):
        if spu_id != 0xff:
            print >> self.log, self.enter_spu3(cluster, spc_id, pic)
            print >> self.log, self.do_spu(cmd)
            print >> self.log, self.exit_spu()
        else:
            self.show_vty_cmd_all(cmd) 

    def set_cli_cmd(self, cmd):
        print >> self.log, self.enter_cli()
        print >> self.log, self.do_cli(cmd)
        print >> self.log, self.exit_cli()

    def set_config_cmd(self, cmd):
        print >> self.log, self.enter_cli()
        print >> self.log, self.enter_configure()    
        print >> self.log, self.do_configure(cmd)
        print >> self.log, self.do_configure("commit")
        print >> self.log, self.exit_configure()
        print >> self.log, self.exit_cli()

port = {'gtp0_port':s_gtp.GTP0_PORT, 'gtp1c_port':s_gtp.GTP1C_PORT, 'gtp1u_port':s_gtp.GTP1U_PORT}
# layer 2
eth = [s_eth.S_Eth(), s_eth.S_Eth()]
# layer 3 
ip = [s_ip.S_Ip(), s_ip.S_Ip()]
# layer 4 - udp
udp = [s_udp.S_Udp(), s_udp.S_Udp()]
# application layer 
gtpv0 = (s_gtp.S_Gtpv0(), s_gtp.S_Gtpv0())
gtpv1 = (s_gtp.S_Gtpv1(), s_gtp.S_Gtpv1())
gtpv2 = (s_gtp.S_Gtpv2(), s_gtp.S_Gtpv2())
gtp_pg = s_gtp.S_Gtpv2()
gtp = (gtpv0, gtpv1, gtpv2)

# set security nat static rule-set RS from zone Zone_Other
# set security nat static rule-set RS rule RS_S_1 match destination-address 20.0.0.1/24
# set security nat static rule-set RS rule RS_S_1 then static-nat prefix 10.0.0.1/24
# set security nat static rule-set RS rule RS_D_1 match destination-address 20.0.10.1/24
# set security nat static rule-set RS rule RS_D_1 then static-nat prefix 10.0.10.1/24
nat_rule = [["20.0.0.255",   "10.0.0.255" ],  
            ["20.0.10.255",  "10.0.10.255"],
            ["", ""]]

show_packet_detail = False 

def send_gtp(direction, ver, ies, pdu_buf, pg_buf, to_pcap = False):
    eth_ = eth[direction]
    ip_ = ip[direction]
    udp_ = udp[direction]
    gtp_ = gtp[ver][direction]

    if ver == 0:
        ie = s_gtp.S_Gtpiev0()
    elif ver == 1:
        ie = s_gtp.S_Gtpiev1()
    elif ver == 2:
        ie = s_gtp.S_Gtpiev2()

    if pdu_buf == "":
        buf = ""
        for key in ies:
            print key
            t = key.rstrip("[0123456789]")
            buf += ie.pack(t, ies[key])
    else:
        buf = pdu_buf

    gtp_.set_payload(buf)
    udp_pl = gtp_.to_buffer()
    if pg_buf != "":
        udp_pl += pg_buf
    udp_.set_payload(udp_pl)
    ip_.set_payload(udp_.to_buffer())
    eth_.set_payload(ip_.to_buffer())
    if not to_pcap:
        sd.send(eth_)
    else:
        sd.send_to_pcap("gtp%d"%direction, eth_)

def verify_gtp(direction):
    if not sd.recv(eth[direction], 1):
        print "faliure:%s"%sd.errmsg
        return False

    if show_packet_detail:
        eth_ = s_eth.S_Eth()
        ip_ = s_ip.S_Ip()
        udp_ = s_udp.S_Udp()

        udp_.from_buffer(ip_.from_buffer(eth_.from_buffer(sd.buff)))

        eth_.dump()
        ip_.dump()
        udp_.dump()

    return True

def show_title(log, msg):
    print >> log, "******************************************"
    print >> log, msg
    print >> log, "******************************************"

def show_ut_title(log, msg):
    print >> log, "||||||||||||||||||||||||||||||||||||||||||"
    print >> log, "++++++++++++++++++++++++++++++++++++++++++"

    print >> log, msg
    
    print >> log, "++++++++++++++++++++++++++++++++++++++++++"
    print >> log, "||||||||||||||||||||||||||||||||||||||||||"

def setUp(dut):
    print >> log, "\n"
    dut.login("root", "Embe1mpls")

def tearDown(dut):
    print >> log, "\n"
    dut.logout()

def dev_clear(dut):
    setUp(dut)
    dut.clear_env()
    tearDown(dut)

def nat_ip_trans(ip, nat_rule):
    ip_val = int(ipaddr.IPAddress(ip))
    rule_id = 0
    while nat_rule[rule_id][0] != "":
        ip_val_0 = int(ipaddr.IPAddress(nat_rule[rule_id][0]))
        ip_val_1 = int(ipaddr.IPAddress(nat_rule[rule_id][1]))
        if (ip_val_0 & 0xFFFFFFL) == 0xFFFFFFL:
            mask = ~(0xFFFFFFL)
        else:
            if (ip_val_0 & 0xFFFFL) == 0xFFFFL:
                mask = ~(0xFFFFL)
            else:
                if (ip_val_0 & 0xFFL) == 0xFFL:
                    mask = ~(0xFFL)
                else:
                    mask = 0xFFFFFFFFL

        if (ip_val & mask) == (ip_val_0 & mask):
            ip_trans_val = (ip_val & (~mask) | ip_val_1 & mask)
            break
        else:
            if (ip_val & mask) == (ip_val_1 & mask):
                ip_trans_val = (ip_val & (~mask) | ip_val_0 & mask)
                break
        rule_id = rule_id + 1
    else:
        ip_trans_val = ip_val

    return str(ipaddr.IPv4Address(ip_trans_val))

def set_gtp_pdu(msg):
    inner_ip = s_ip.S_Ip()
    inner_udp = s_udp.S_Udp()
    data_buffer = "01234567"

    for buf_num in range(0, 708):
        data_buffer += pack("!H", 0x1)

    inner_ip.set_proto(s_ip.udp)
    inner_ip.set_ip(msg['in_src_ip'], msg['in_dst_ip'])
    inner_udp.set_port(msg['in_src_port'], msg['in_dst_port'])
        
    inner_udp.set_payload(data_buffer)
    inner_ip.set_payload(inner_udp.to_buffer())
    return inner_ip.to_buffer()

def set_v2_piggy_buf(gtp, ies):
    ie   = s_gtp.S_Gtpiev2()
    buf = ""
    for key in ies:
        print key
        t = key.rstrip("[0123456789]")
        buf += ie.pack(t, ies[key])

    gtp.set_payload(buf)
    return gtp.to_buffer()
 
def gtp_send_msg(src_int, dst_int, ver, msg, ies, ies_pg = 0):
    ip_ = ip[src_int]                                                
    udp_ = udp[src_int]                                              
    gtp_ = gtp[ver][src_int]
    pdu_buf = "" 
    pg_buf = ""
    
    src_prv = nat_ip_trans(msg['src_ip'], nat_rule)
    ip_.set_ip(src_prv, msg['dst_ip'])
    gtp_.set_msg_type(msg['msg_type'])
    if 'teid' in msg:
        gtp_.set_teid(msg['teid'])
    if 'tid' in msg:
        gtp_.set_tid(msg['tid'])
    if 'flabel' in msg:
        gtp_.set_flabel(msg['flabel'])
    if 'seq' in msg:
        gtp_.set_seq(msg['seq'])

    if 'cause' in msg:
        ies["GTPIE_CAUSE"] = pack("!B", msg['cause'])
    if 'recovery' in msg:
        ies["GTPIE_RECOVERY"] = msg['recovery']
    if 'utnl_id' in msg:
        ies["GTPIE_TEI_DI"] = pack("!I", msg['utnl_id'])
    if 'ctnl_id' in msg:
        ies["GTPIE_TEI_C"] = pack("!I", msg['ctnl_id'])
    if 'utnl_id2' in msg:
        ies["GTPIE_TEI_DII"] = pack("!BI", 5, msg['utnl_id2'])
    if 'teardown' in msg:
        ies["GTPIE_TEARDOWN"] = msg['teardown']
    if 'linked_nsapi' in msg:
        ies["GTPIE_NSAPI[0]"] = msg['nsapi']
        ies["GTPIE_NSAPI[1]"] = msg['linked_nsapi']
    elif 'nsapi' in msg:
        ies["GTPIE_NSAPI"] = msg['nsapi']
    if 'charging' in msg:
        ies["GTPIE_CHARGING_ID"] = pack("!I", msg['charging'])
    if 'euip' in msg:    
        pdp_type = 0xf121                                                                           
        pdp_addr = int(ipaddr.IPAddress(msg['euip']))
        eua_val = pack("!HI", pdp_type, pdp_addr)
        ies["GTPIE_EUA"] = eua_val
    if 'ctnl_ip' in msg:
        ies["GTPIE_GSN_ADDR[0]"] = s_net.ip_str2b(msg['ctnl_ip'])
    if 'utnl_ip' in msg:
        ies["GTPIE_GSN_ADDR[1]"] = s_net.ip_str2b(msg['utnl_ip'])
    if 'qos' in msg:
        ies["GTPIE_QOS_PROFILE"] = msg['qos']
    if 'flabel_c' in msg:
        ies["GTPIE_FL_C"] = pack("!H", msg['flabel_c'])
    if 'flabel_u' in msg:
        ies["GTPIE_FL_DI"] = pack("!H", msg['flabel_u'])

    if ver == 0:
        udp_.set_port(s_gtp.GTP0_PORT, s_gtp.GTP0_PORT)
    else:
        if msg['msg_type'] == 'GTP_GPDU':
            udp_.set_port(s_gtp.GTP1U_PORT, s_gtp.GTP1U_PORT)
        else:
            udp_.set_port(s_gtp.GTP1C_PORT, s_gtp.GTP1C_PORT)
    
    if msg['msg_type'] == 'GTP_GPDU':
        pdu_buf = set_gtp_pdu(msg)

    if ies_pg:
        pg_buf = set_v2_piggy_buf(gtp_pg, ies_pg)
 
    send_gtp(src_int, ver, ies, pdu_buf, pg_buf) 
    if not verify_gtp(dst_int):
        print "***[FAILURE]***"
        return False
    else:
        return True

def test_nat_trans():
    ip = "20.0.10.1"
    ip_str = nat_ip_trans(ip)
    print "%s"%ip_str 

sd = s_socket_daemon.S_Socket_Daemon(eth, s_ip.udp)

if "__main__" == __name__:
    unittest.main()
    #test_nat_trans()
