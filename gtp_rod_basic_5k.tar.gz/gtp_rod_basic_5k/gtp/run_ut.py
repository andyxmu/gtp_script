#!/usr/bin/python
import string, glob, os, sys
import datetime, time
import unittest
sys.path.append("nat")
import nat 

#suite = unittest.TestLoader().loadTestsFromTestCase(demo.Demo_UT)
suite = unittest.TestLoader().loadTestsFromTestCase(nat.Demo_UT)
unittest.TextTestRunner(verbosity=2).run(suite)



