#!/usr/bin/python
import string, glob, os, sys, re
sys.path.append("../")
import s_ip
import struct
import s_gsn
import xml.etree.ElementTree as et

rm_xmlns = re.compile(" xmlns.*>")
rm_junos = re.compile(" junos:")
def parse(xml_str):
    inner_xml = "%s"%rm_xmlns.sub(">", xml_str[xml_str.find("<rpc-reply") : len(xml_str)])
    inner_xml2 = "<root>\r\n%s\r\n</root>"%rm_junos.sub(" ", inner_xml)
    print inner_xml2
    root = et.fromstring(inner_xml2)
    xml_contexts = root.find("rpc-reply/gtp-information").findall("tunnel-information")
   
    context_list = []
    for xml_context in xml_contexts:
        if xml_context.find("tunnel-version") != None:
            context = None
            ctnl = S_Tunnel("Ctrl")
            ctnl.ctnl_from_xml(xml_context)
            utnl = S_Tunnel("User")
            utnl.utnl_from_xml(xml_context)
            for ctxt in context_list:
                 if ctnl.tnl_cmp(ctxt.ctnl):
                     context = ctxt
                     break
            if context == None:
                context = S_GtpCtxt()
                context.ctnl = ctnl
            context.from_xml(xml_context)
            context.add_utnl(utnl)
            if not context in context_list:
                context_list.append(context)
    return context_list 

class S_Tunnel(object):
    def __init__(self, t):
        self.t = t             # type
        self.dl_teid = 0 
        self.ul_teid = 0
        self.dl_ip   = ""
        self.ul_ip   = ""
        self.uid     = 0
        self.pri_uid = 0
        self.timeout = 0
        self.index   = 0       # tunnel index on box

    def ctnl_from_xml(self, xml_e):
        version = int(xml_e.find("tunnel-version").text)
        if version == 2:
            self.dl_teid = int("0x"+xml_e.find("tunnel-sgw-control-id").text, 16)
            self.dl_ip = xml_e.find("tunnel-sgw-control-ip").text
            self.ul_teid = int("0x"+xml_e.find("tunnel-peer-control-id").text, 16)
            self.ul_ip = xml_e.find("tunnel-peer-control-ip").text
        else:
            self.dl_teid = int("0x"+xml_e.find("tunnel-sgsn-control-id").text, 16)
            self.dl_ip = xml_e.find("tunnel-sgsn-control-ip").text
            self.ul_teid = int("0x"+xml_e.find("tunnel-ggsn-control-id").text, 16)
            self.ul_ip = xml_e.find("tunnel-ggsn-control-ip").text

    def utnl_from_xml(self, xml_e):
        version = int(xml_e.find("tunnel-version").text)       
        if version == 0:
            self.dl_teid = int("0x"+xml_e.find("tunnel-sgsn-user-id").text, 16)
            self.dl_ip = xml_e.find("tunnel-sgsn-user-ip").text
            self.ul_teid = int("0x"+xml_e.find("tunnel-ggsn-user-id").text, 16)
            self.ul_ip = xml_e.find("tunnel-ggsn-user-ip").text
            self.uid = int(xml_e.find("tunnel-sapi").text)
            self.pri_uid = self.uid
            self.timeout = int(xml_e.find("tunnel-timeout").text)
        elif version == 1:
            self.dl_teid = int("0x"+xml_e.find("tunnel-sgsn-user-id").text, 16)
            self.dl_ip = xml_e.find("tunnel-sgsn-user-ip").text
            self.ul_teid = int("0x"+xml_e.find("tunnel-ggsn-user-id").text, 16)
            self.ul_ip = xml_e.find("tunnel-ggsn-user-ip").text
            self.uid = int(xml_e.find("tunnel-sapi").text)
            self.pri_uid = int(xml_e.find("tunnel-linked-sapi").text)
            self.timeout = int(xml_e.find("tunnel-timeout").text)
        elif version == 2:
            self.dl_teid = int("0x"+xml_e.find("tunnel-sgw-user-id").text, 16)
            self.dl_ip = xml_e.find("tunnel-sgw-user-ip").text
            self.ul_teid = int("0x"+xml_e.find("tunnel-peer-user-id").text, 16)
            self.ul_ip = xml_e.find("tunnel-peer-user-ip").text
            self.uid = int(xml_e.find("tunnel-bearer_id").text)
            self.pri_uid = int(xml_e.find("tunnel-default-bearer_id").text)
            self.timeout = int(xml_e.find("tunnel-timeout").text)
                        
    def tnl_cmp(self, cmp_tnl):     
        if self.dl_teid != cmp_tnl.dl_teid or \
           self.ul_teid != cmp_tnl.ul_teid or \
           self.dl_ip != cmp_tnl.dl_ip or \
           self.ul_ip != cmp_tnl.ul_ip or \
          (self.t == "User" and (self.uid != cmp_tnl.uid or self.pri_uid != cmp_tnl.pri_uid)):
            print "Error: tnl information incorrect!"
            print "tnl1 %s \ntnl2 %s\n"%(self.to_string(), cmp_tnl.to_string())
            return False
        return True

    def to_string(self):
        msg = "%s: "%self.t
        msg += "%s/0x%08x -> %s/0x%08x"%(self.dl_ip, self.dl_teid, self.ul_ip, self.ul_teid)
        if self.t == "User":
            msg += " %d/%d timeout %d"%(self.uid, self.pri_uid, self.timeout)
        return msg

class S_GtpCtxt:
    def __init__(self):
        self.ctnl = S_Tunnel("Ctrl")
        self.utnl = []
        self.fwd_ctnl = S_Tunnel("Ctrl")
        self.fwd_utnl = []
        self.tid  = 0
        self.version = 0
        self.imsi = 0x123456789012345
        self.apn = "auto-ut.gprs.juniper.net"
        self.ue_ip = "1.1.1.1"
        self.utnl_num = 0
        self.pri_uid = 0

    def clean_up(self):
        self.utnl = []
        self.fwd_utnl = []
        self.utnl_num = 0 

    def add_utnl(self, utnl):
        if self.utnl_num == 0:
            self.pri_uid = utnl.uid
        self.utnl_num += 1
        self.utnl.append(utnl)

    def add_fwd_utnl(self, utnl):
        self.fwd_utnl.append(utnl)
 
    def del_utnl(self, uidx):
        self.utnl_num -= 1
        del self.utnl[uidx]

    def from_xml(self, xml_e):
        self.version = int(xml_e.find("tunnel-version").text)

    def to_string(self):
        msg = "GTPv%d %s (%d)\n"%(self.version, self.ctnl.to_string(), self.utnl_num)
        for i in range(0, self.utnl_num):
            msg += "      %s\n"%self.utnl[i].to_string()
        return msg

def context_compare(context1, context2):
    if context1.utnl_num != context2.utnl_num:
        print "Error: tunnel number incorrect!"
        print "context1 %s\n"%(context1.to_string())
        print "context2 %s\n"%(context2.to_string())
        return False

    if not context1.utnl_num:
        return True
            
    if not context1.ctnl.tnl_cmp(context2.ctnl):
        return False

    for i in range(0, context1.utnl_num):
        if not context1.utnl[i].tnl_cmp(context2.utnl[i]):
            return False

    return True

def context_list_compare(list1, list2):
    if len(list1) != len(list2):
        return False

    for ctxt1 in list1:
        for ctxt2 in list2:
            if ctxt1.ctnl.tnl_cmp(ctxt2.ctnl):
                break;
        if not context_compare(ctxt1, ctxt2):
            return False

    return True
 
