#!/usr/bin/python
import string, glob, os, sys, re
sys.path.append("../")
import struct
import xml.etree.ElementTree as et

rm_xmlns = re.compile(" xmlns.*>")

def parse(xml_str, cnt_type):
    inner_xml = "%s"%rm_xmlns.sub(">", xml_str[xml_str.find("<rpc-reply") : len(xml_str)])
    inner_xml2 = "<root>\r\n%s\r\n</root>"%inner_xml
    #print inner_xml2
    root = et.fromstring(inner_xml2)

    counter = gtp_counters[cnt_type]
    counter_xml = root.find("rpc-reply/gtp-show-counters/%s"%counter.name)
    counter.from_xml(counter_xml)
    #print counter.to_string()
    return counter


class S_Counter(object):
    def __init__(self, t):
        self.name = "" 
        self.ctr_cnt = {}
        self.ctr_name = {}
        self.ctr_val = {}

    def from_xml(self, xml_e):
        for i in range(0, self.ctr_cnt):
            self.ctr_val[i] = int(xml_e.find(self.ctr_name[i]).text)

    def to_string(self):
        msg = "%s (total %d): \n"%(self.name, self.ctr_cnt)
        for i in range(0, self.ctr_cnt):
            msg += "    %s    %d\n"%(self.ctr_name[i], self.ctr_val[i])
        return msg 
          
#------------------- data-packet counter---------------------
GTPU_V1_PKT_RCV                  =  0 
GTPU_V1_PKT_PASS                 =  1  
GTPU_V1_PKT_DROP                 =  2  
GTPU_V1_PKT_NO_TNL_DROP          =  3  
GTPU_V1_PKT_SEQ_CHECK_DROP       =  4  
GTPU_V1_PKT_END_USER_CHECK_DROP  =  5  
GTPU_V1_PKT_OTHER_CHECK_DROP     =  6  
GTPU_V0_PKT_RCV                  =  7  
GTPU_V0_PKT_PASS                 =  8  
GTPU_V0_PKT_DROP                 =  9  
GTPU_V0_PKT_NO_TNL_DROP          =  10 
GTPU_V0_PKT_SEQ_CHECK_DROP       =  11 
GTPU_V0_PKT_END_USER_CHECK_DROP  =  12 
GTPU_V0_PKT_OTHER_CHECK_DROP     =  13 
GTP_DATA_PKT_CTR_MAX             =  14

#------------------- message-brief counter---------------------
V0_CREATE_REQ_RCV               = 0
V0_CREATE_REQ_FWD               = 1
V0_CREATE_REQ_DRP               = 2
V0_CREATE_RSP_RCV               = 3
V0_CREATE_RSP_FWD               = 4
V0_CREATE_RSP_DRP               = 5
V0_UPDATE_REQ_RCV               = 6
V0_UPDATE_REQ_FWD               = 7
V0_UPDATE_REQ_DRP               = 8
V0_UPDATE_RSP_RCV               = 9
V0_UPDATE_RSP_FWD               = 10
V0_UPDATE_RSP_DRP               = 11
V0_DELETE_REQ_RCV               = 12
V0_DELETE_REQ_FWD               = 13
V0_DELETE_REQ_DRP               = 14
V0_DELETE_RSP_RCV               = 15
V0_DELETE_RSP_FWD               = 16
V0_DELETE_RSP_DRP               = 17
V0_CREATE_AA_REQ_RCV            = 18
V0_CREATE_AA_REQ_FWD            = 19
V0_CREATE_AA_REQ_DRP            = 20
V0_CREATE_AA_RSP_RCV            = 21
V0_CREATE_AA_RSP_FWD            = 22
V0_CREATE_AA_RSP_DRP            = 23
V0_DELETE_AA_REQ_RCV            = 24
V0_DELETE_AA_REQ_FWD            = 25
V0_DELETE_AA_REQ_DRP            = 26
V0_DELETE_AA_RSP_RCV            = 27
V0_DELETE_AA_RSP_FWD            = 28
V0_DELETE_AA_RSP_DRP            = 29
V0_SGSN_CONTEXT_REQ_RCV         = 30
V0_SGSN_CONTEXT_REQ_FWD         = 31
V0_SGSN_CONTEXT_REQ_DRP         = 32
V0_SGSN_CONTEXT_RSP_RCV         = 33
V0_SGSN_CONTEXT_RSP_FWD         = 34
V0_SGSN_CONTEXT_RSP_DRP         = 35
V0_SGSN_CONTEXT_ACK_RCV         = 36
V0_SGSN_CONTEXT_ACK_FWD         = 37
V0_SGSN_CONTEXT_ACK_DRP         = 38
V0_OTHERS_RCV                   = 39
V0_OTHERS_FWD                   = 40
V0_OTHERS_DRP                   = 41
V1_CREATE_REQ_RCV               = 42
V1_CREATE_REQ_FWD               = 43
V1_CREATE_REQ_DRP               = 44
V1_CREATE_RSP_RCV               = 45
V1_CREATE_RSP_FWD               = 46
V1_CREATE_RSP_DRP               = 47
V1_UPDATE_REQ_RCV               = 48
V1_UPDATE_REQ_FWD               = 49
V1_UPDATE_REQ_DRP               = 50
V1_UPDATE_RSP_RCV               = 51
V1_UPDATE_RSP_FWD               = 52
V1_UPDATE_RSP_DRP               = 53
V1_DELETE_REQ_RCV               = 54
V1_DELETE_REQ_FWD               = 55
V1_DELETE_REQ_DRP               = 56
V1_DELETE_RSP_RCV               = 57
V1_DELETE_RSP_FWD               = 58
V1_DELETE_RSP_DRP               = 59
V1_SGSN_CONTEXT_REQ_RCV         = 60
V1_SGSN_CONTEXT_REQ_FWD         = 61
V1_SGSN_CONTEXT_REQ_DRP         = 62
V1_SGSN_CONTEXT_RSP_RCV         = 63
V1_SGSN_CONTEXT_RSP_FWD         = 64
V1_SGSN_CONTEXT_RSP_DRP         = 65
V1_SGSN_CONTEXT_ACK_RCV         = 66
V1_SGSN_CONTEXT_ACK_FWD         = 67
V1_SGSN_CONTEXT_ACK_DRP         = 68
V1_FORWARD_RELOC_REQ_RCV        = 69
V1_FORWARD_RELOC_REQ_FWD        = 70
V1_FORWARD_RELOC_REQ_DRP        = 71
V1_FORWARD_RELOC_RSP_RCV        = 72
V1_FORWARD_RELOC_RSP_FWD        = 73
V1_FORWARD_RELOC_RSP_DRP        = 74
V1_OTHERS_RCV                   = 75
V1_OTHERS_FWD                   = 76
V1_OTHERS_DRP                   = 77
V2_CREATE_SESSION_REQ_RCV       = 78
V2_CREATE_SESSION_REQ_FWD       = 79
V2_CREATE_SESSION_REQ_DRP       = 80
V2_CREATE_SESSION_RSP_RCV       = 81
V2_CREATE_SESSION_RSP_FWD       = 82
V2_CREATE_SESSION_RSP_DRP       = 83
V2_DELETE_SESSION_REQ_RCV       = 84
V2_DELETE_SESSION_REQ_FWD       = 85
V2_DELETE_SESSION_REQ_DRP       = 86
V2_DELETE_SESSION_RSP_RCV       = 87
V2_DELETE_SESSION_RSP_FWD       = 88
V2_DELETE_SESSION_RSP_DRP       = 89
V2_CREATE_BEARER_REQ_RCV        = 90
V2_CREATE_BEARER_REQ_FWD        = 91
V2_CREATE_BEARER_REQ_DRP        = 92
V2_CREATE_BEARER_RSP_RCV        = 93
V2_CREATE_BEARER_RSP_FWD        = 94
V2_CREATE_BEARER_RSP_DRP        = 95
V2_MODIFY_BEARER_REQ_RCV        = 96
V2_MODIFY_BEARER_REQ_FWD        = 97
V2_MODIFY_BEARER_REQ_DRP        = 98
V2_MODIFY_BEARER_RSP_RCV        = 99
V2_MODIFY_BEARER_RSP_FWD        = 100
V2_MODIFY_BEARER_RSP_DRP        = 101
V2_DELETE_BEARER_REQ_RCV        = 102
V2_DELETE_BEARER_REQ_FWD        = 103
V2_DELETE_BEARER_REQ_DRP        = 104
V2_DELETE_BEARER_RSP_RCV        = 105
V2_DELETE_BEARER_RSP_FWD        = 106
V2_DELETE_BEARER_RSP_DRP        = 107
V2_CONTEXT_REQ_RCV              = 108
V2_CONTEXT_REQ_FWD              = 109
V2_CONTEXT_REQ_DRP              = 110
V2_CONTEXT_RSP_RCV              = 111
V2_CONTEXT_RSP_FWD              = 112
V2_CONTEXT_RSP_DRP              = 113
V2_CONTEXT_ACK_RCV              = 114
V2_CONTEXT_ACK_FWD              = 115
V2_CONTEXT_ACK_DRP              = 116
V2_FORWARD_RELOC_REQ_RCV        = 117
V2_FORWARD_RELOC_REQ_FWD        = 118
V2_FORWARD_RELOC_REQ_DRP        = 119
V2_FORWARD_RELOC_RSP_RCV        = 120
V2_FORWARD_RELOC_RSP_FWD        = 121
V2_FORWARD_RELOC_RSP_DRP        = 122
V2_CREATE_INDIR_FWD_TNL_REQ_RCV = 123
V2_CREATE_INDIR_FWD_TNL_REQ_FWD = 124
V2_CREATE_INDIR_FWD_TNL_REQ_DRP = 125
V2_CREATE_INDIR_FWD_TNL_RSP_RCV = 126
V2_CREATE_INDIR_FWD_TNL_RSP_FWD = 127
V2_CREATE_INDIR_FWD_TNL_RSP_DRP = 128
V2_OTHERS_RCV                   = 129
V2_OTHERS_FWD                   = 130
V2_OTHERS_DRP                   = 131
GTP_MSG_BRIEF_CTR_MAX           = 132

#------------------- ha counter---------------------
TOTAL_RECV                  = 0 
TOTAL_RECV_OK               = 1 
TOTAL_RECV_BAD_MSG          = 2 
TOTAL_RECV_UNKNOWN_TYPE     = 3 
TOTAL_RECV_UNKNOWN_VERSION  = 4 
TOTAL_SEND                  = 5 
TOTAL_SEND_OK               = 6 
TOTAL_SEND_FAIL             = 7 
TOTAL_ALLOC_MEMORY_FAIL     = 8 
TOTAL_UNDER_RESET           = 9 
GTP_HA_CTR_MAX              = 10

#------------------- request counter---------------------
ALLOCATE_REQUEST      = 0
FREE_REQUEST          = 1
ALLOCATE_REQUEST_FAIL = 2
REQUEST_HIT_ERROR     = 3
PENDING_TIMEOUT       = 4
GTP_REQ_CTR_MAX       = 5

#------------------- error counter -----------------
TOTAL                   = 0 
EXCEPTION               = 1 
GTP_HEADER              = 2 
LENGTH                  = 3 
IMSI                    = 4 
CHARGE_ID               = 5 
SEQUENCE                = 6 
APN                     = 7 
TRANSPORT               = 8 
GTP_IN_GTP              = 9 
LENGTH_SHORT            = 10
LENGTH_LONG             = 11
GSN_NOT_EXIST           = 12
RATE_LIMIT              = 13
RESPONSE_NOT_MATCH      = 14
RESPONSE_RETRANSMIT     = 15
MISSING_IE              = 16
UNEXPECT_IE             = 17
IE_TYPE                 = 18
IE_ORDER                = 19
IE_LENGTH               = 20
DUPLICATE_IE            = 21
NON_DIGIT               = 22
TID_NOT_0               = 23
TID_0                   = 24
TID_CONTROL             = 25
TID_DATA                = 26
CONTROL_IP              = 27
DATA_IP                 = 28
END_USER_IP             = 29
GGSN_IP                 = 30
MESSAGE_V0              = 31
MESSAGE_V1              = 32
MESSAGE_V2              = 33
MESSAGE_TYPE            = 34
NO_TUNNEL_0             = 35
NO_CONTROL_TUNNEL       = 36
NO_USER_TUNNEL          = 37
INVALID_TUNNEL_0        = 38
INVALID_CONTROL_TUNNEL  = 39
INVALID_USER_TUNNEL     = 40
CREATE_TUNNEL_0         = 41
CREATE_CONTROL_TUNNEL   = 42
CREATE_USER_TUNNEL      = 43
NO_REQUEST              = 44
NEW_REQUEST             = 45
NO_ACTION               = 46
NEW_ACTION              = 47
NOT_UNIQUE_TID          = 48
MISSING_TID             = 49
EBI_NOT_0               = 50
EBI_NOT_EXIST           = 51
BEARER_IE               = 52
DUP_JBUF                = 53
NEW_JMPI_COOKIE         = 54
SEND_JMPI_MSG           = 55
JMPI_TARGET_FAILED      = 56
NEW_RT_COOKIE           = 57
REINJECT                = 58
WRONG_SPU               = 59
UNDER_RESET             = 60
SRC_IP                  = 61
DST_IP                  = 62
V2_INVALID_EBI          = 63
ALL_UP                  = 64
INTERFACE               = 65
NEW_PATH                = 66
PATH_OVER_RATE          = 67
NEW_UTNL_KEY            = 68
NO_UTNL_KEY             = 69
END_USER                = 70
NEW_SYNC_ACTION         = 71
NSAPI                   = 72
CONFLICT_SYNC_ACTION    = 73
PRI_UID_NOT_EXIST       = 74
TOO_MANY_SAME_TYPE_IE   = 75
V2_LBI                  = 76
RM_CONFLICT_UTNL        = 77
CONFLICT_PRI_UTNL       = 78
CTNL_RECOVERY           = 79
LINK_CTNL_CONFLICT      = 80
LINK_UTNL_CONFLICT      = 81
LINK_TNL0_CONFLICT      = 82
V0_GGSN_IP_CHG          = 83
INVALID_PAYLOAD         = 84
WRONG_SPU_SINFO         = 85
WRONG_SPU_WING          = 86
WRONG_SPU_ANCHOR        = 87
GTP_ERROR_CTR_MAX       = 88

class Data_packet_cnt(S_Counter):
    def __init__(self):
        self.name = "data-packet"
        self.ctr_cnt = GTP_DATA_PKT_CTR_MAX
        self.ctr_name = {}
        self.ctr_val = {}

        self.ctr_name[GTPU_V1_PKT_RCV                ] = "gtpu_v1_pkt_rcv"
        self.ctr_name[GTPU_V1_PKT_PASS               ] = "gtpu_v1_pkt_pass"
        self.ctr_name[GTPU_V1_PKT_DROP               ] = "gtpu_v1_pkt_drop"
        self.ctr_name[GTPU_V1_PKT_NO_TNL_DROP        ] = "gtpu_v1_pkt_no_tnl_drop"
        self.ctr_name[GTPU_V1_PKT_SEQ_CHECK_DROP     ] = "gtpu_v1_pkt_seq_check_drop"
        self.ctr_name[GTPU_V1_PKT_END_USER_CHECK_DROP] = "gtpu_v1_pkt_end_user_check_drop"
        self.ctr_name[GTPU_V1_PKT_OTHER_CHECK_DROP   ] = "gtpu_v1_pkt_other_check_drop"
        self.ctr_name[GTPU_V0_PKT_RCV                ] = "gtpu_v0_pkt_rcv"
        self.ctr_name[GTPU_V0_PKT_PASS               ] = "gtpu_v0_pkt_pass"
        self.ctr_name[GTPU_V0_PKT_DROP               ] = "gtpu_v0_pkt_drop"
        self.ctr_name[GTPU_V0_PKT_NO_TNL_DROP        ] = "gtpu_v0_pkt_no_tnl_drop"
        self.ctr_name[GTPU_V0_PKT_SEQ_CHECK_DROP     ] = "gtpu_v0_pkt_seq_check_drop"
        self.ctr_name[GTPU_V0_PKT_END_USER_CHECK_DROP] = "gtpu_v0_pkt_end_user_check_drop"
        self.ctr_name[GTPU_V0_PKT_OTHER_CHECK_DROP   ] = "gtpu_v0_pkt_other_check_drop"

class Message_brief_cnt(S_Counter):
    def __init__(self):
        self.name = "message-brief"
        self.ctr_cnt = GTP_MSG_BRIEF_CTR_MAX
        self.ctr_name = {}
        self.ctr_val = {}

        self.ctr_name[V0_CREATE_REQ_RCV      ] = "v0-create-req-rcv"      
        self.ctr_name[V0_CREATE_REQ_FWD      ] = "v0-create-req-fwd"      
        self.ctr_name[V0_CREATE_REQ_DRP      ] = "v0-create-req-drp"      
        self.ctr_name[V0_CREATE_RSP_RCV      ] = "v0-create-rsp-rcv"      
        self.ctr_name[V0_CREATE_RSP_FWD      ] = "v0-create-rsp-fwd"      
        self.ctr_name[V0_CREATE_RSP_DRP      ] = "v0-create-rsp-drp"      
        self.ctr_name[V0_UPDATE_REQ_RCV      ] = "v0-update-req-rcv"      
        self.ctr_name[V0_UPDATE_REQ_FWD      ] = "v0-update-req-fwd"      
        self.ctr_name[V0_UPDATE_REQ_DRP      ] = "v0-update-req-drp"      
        self.ctr_name[V0_UPDATE_RSP_RCV      ] = "v0-update-rsp-rcv"      
        self.ctr_name[V0_UPDATE_RSP_FWD      ] = "v0-update-rsp-fwd"      
        self.ctr_name[V0_UPDATE_RSP_DRP      ] = "v0-update-rsp-drp"      
        self.ctr_name[V0_DELETE_REQ_RCV      ] = "v0-delete-req-rcv"      
        self.ctr_name[V0_DELETE_REQ_FWD      ] = "v0-delete-req-fwd"      
        self.ctr_name[V0_DELETE_REQ_DRP      ] = "v0-delete-req-drp"      
        self.ctr_name[V0_DELETE_RSP_RCV      ] = "v0-delete-rsp-rcv"      
        self.ctr_name[V0_DELETE_RSP_FWD      ] = "v0-delete-rsp-fwd"      
        self.ctr_name[V0_DELETE_RSP_DRP      ] = "v0-delete-rsp-drp"      
        self.ctr_name[V0_CREATE_AA_REQ_RCV   ] = "v0-create-aa-req-rcv"   
        self.ctr_name[V0_CREATE_AA_REQ_FWD   ] = "v0-create-aa-req-fwd"   
        self.ctr_name[V0_CREATE_AA_REQ_DRP   ] = "v0-create-aa-req-drp"   
        self.ctr_name[V0_CREATE_AA_RSP_RCV   ] = "v0-create-aa-rsp-rcv"   
        self.ctr_name[V0_CREATE_AA_RSP_FWD   ] = "v0-create-aa-rsp-fwd"   
        self.ctr_name[V0_CREATE_AA_RSP_DRP   ] = "v0-create-aa-rsp-drp"   
        self.ctr_name[V0_DELETE_AA_REQ_RCV   ] = "v0-delete-aa-req-rcv"   
        self.ctr_name[V0_DELETE_AA_REQ_FWD   ] = "v0-delete-aa-req-fwd"   
        self.ctr_name[V0_DELETE_AA_REQ_DRP   ] = "v0-delete-aa-req-drp"   
        self.ctr_name[V0_DELETE_AA_RSP_RCV   ] = "v0-delete-aa-rsp-rcv"   
        self.ctr_name[V0_DELETE_AA_RSP_FWD   ] = "v0-delete-aa-rsp-fwd"   
        self.ctr_name[V0_DELETE_AA_RSP_DRP   ] = "v0-delete-aa-rsp-drp"   
        self.ctr_name[V0_SGSN_CONTEXT_REQ_RCV] = "v0-sgsn-context-req-rcv"
        self.ctr_name[V0_SGSN_CONTEXT_REQ_FWD] = "v0-sgsn-context-req-fwd"
        self.ctr_name[V0_SGSN_CONTEXT_REQ_DRP] = "v0-sgsn-context-req-drp"
        self.ctr_name[V0_SGSN_CONTEXT_RSP_RCV] = "v0-sgsn-context-rsp-rcv"
        self.ctr_name[V0_SGSN_CONTEXT_RSP_FWD] = "v0-sgsn-context-rsp-fwd"
        self.ctr_name[V0_SGSN_CONTEXT_RSP_DRP] = "v0-sgsn-context-rsp-drp"
        self.ctr_name[V0_SGSN_CONTEXT_ACK_RCV] = "v0-sgsn-context-ack-rcv"
        self.ctr_name[V0_SGSN_CONTEXT_ACK_FWD] = "v0-sgsn-context-ack-fwd"
        self.ctr_name[V0_SGSN_CONTEXT_ACK_DRP] = "v0-sgsn-context-ack-drp"
        self.ctr_name[V0_OTHERS_RCV          ] = "v0-others-rcv"          
        self.ctr_name[V0_OTHERS_FWD          ] = "v0-others-fwd"          
        self.ctr_name[V0_OTHERS_DRP          ] = "v0-others-drp"          
        self.ctr_name[V1_CREATE_REQ_RCV        ] = "v1-create-req-rcv"       
        self.ctr_name[V1_CREATE_REQ_FWD        ] = "v1-create-req-fwd"       
        self.ctr_name[V1_CREATE_REQ_DRP        ] = "v1-create-req-drp"       
        self.ctr_name[V1_CREATE_RSP_RCV        ] = "v1-create-rsp-rcv"       
        self.ctr_name[V1_CREATE_RSP_FWD        ] = "v1-create-rsp-fwd"       
        self.ctr_name[V1_CREATE_RSP_DRP        ] = "v1-create-rsp-drp"       
        self.ctr_name[V1_UPDATE_REQ_RCV        ] = "v1-update-req-rcv"       
        self.ctr_name[V1_UPDATE_REQ_FWD        ] = "v1-update-req-fwd"       
        self.ctr_name[V1_UPDATE_REQ_DRP        ] = "v1-update-req-drp"       
        self.ctr_name[V1_UPDATE_RSP_RCV        ] = "v1-update-rsp-rcv"       
        self.ctr_name[V1_UPDATE_RSP_FWD        ] = "v1-update-rsp-fwd"       
        self.ctr_name[V1_UPDATE_RSP_DRP        ] = "v1-update-rsp-drp"       
        self.ctr_name[V1_DELETE_REQ_RCV        ] = "v1-delete-req-rcv"       
        self.ctr_name[V1_DELETE_REQ_FWD        ] = "v1-delete-req-fwd"       
        self.ctr_name[V1_DELETE_REQ_DRP        ] = "v1-delete-req-drp"       
        self.ctr_name[V1_DELETE_RSP_RCV        ] = "v1-delete-rsp-rcv"       
        self.ctr_name[V1_DELETE_RSP_FWD        ] = "v1-delete-rsp-fwd"       
        self.ctr_name[V1_DELETE_RSP_DRP        ] = "v1-delete-rsp-drp"       
        self.ctr_name[V1_SGSN_CONTEXT_REQ_RCV  ] = "v1-sgsn-context-req-rcv" 
        self.ctr_name[V1_SGSN_CONTEXT_REQ_FWD  ] = "v1-sgsn-context-req-fwd" 
        self.ctr_name[V1_SGSN_CONTEXT_REQ_DRP  ] = "v1-sgsn-context-req-drp" 
        self.ctr_name[V1_SGSN_CONTEXT_RSP_RCV  ] = "v1-sgsn-context-rsp-rcv" 
        self.ctr_name[V1_SGSN_CONTEXT_RSP_FWD  ] = "v1-sgsn-context-rsp-fwd" 
        self.ctr_name[V1_SGSN_CONTEXT_RSP_DRP  ] = "v1-sgsn-context-rsp-drp" 
        self.ctr_name[V1_SGSN_CONTEXT_ACK_RCV  ] = "v1-sgsn-context-ack-rcv" 
        self.ctr_name[V1_SGSN_CONTEXT_ACK_FWD  ] = "v1-sgsn-context-ack-fwd" 
        self.ctr_name[V1_SGSN_CONTEXT_ACK_DRP  ] = "v1-sgsn-context-ack-drp" 
        self.ctr_name[V1_FORWARD_RELOC_REQ_RCV ] = "v1-forward-reloc-req-rcv"
        self.ctr_name[V1_FORWARD_RELOC_REQ_FWD ] = "v1-forward-reloc-req-fwd"
        self.ctr_name[V1_FORWARD_RELOC_REQ_DRP ] = "v1-forward-reloc-req-drp"
        self.ctr_name[V1_FORWARD_RELOC_RSP_RCV ] = "v1-forward-reloc-rsp-rcv"
        self.ctr_name[V1_FORWARD_RELOC_RSP_FWD ] = "v1-forward-reloc-rsp-fwd"
        self.ctr_name[V1_FORWARD_RELOC_RSP_DRP ] = "v1-forward-reloc-rsp-drp"
        self.ctr_name[V1_OTHERS_RCV            ] = "v1-others-rcv"           
        self.ctr_name[V1_OTHERS_FWD            ] = "v1-others-fwd"           
        self.ctr_name[V1_OTHERS_DRP            ] = "v1-others-drp"           
        self.ctr_name[V2_CREATE_SESSION_REQ_RCV      ] = "v2-create-session-req-rcv"      
        self.ctr_name[V2_CREATE_SESSION_REQ_FWD      ] = "v2-create-session-req-fwd"      
        self.ctr_name[V2_CREATE_SESSION_REQ_DRP      ] = "v2-create-session-req-drp"      
        self.ctr_name[V2_CREATE_SESSION_RSP_RCV      ] = "v2-create-session-rsp-rcv"      
        self.ctr_name[V2_CREATE_SESSION_RSP_FWD      ] = "v2-create-session-rsp-fwd"      
        self.ctr_name[V2_CREATE_SESSION_RSP_DRP      ] = "v2-create-session-rsp-drp"      
        self.ctr_name[V2_DELETE_SESSION_REQ_RCV      ] = "v2-delete-session-req-rcv"      
        self.ctr_name[V2_DELETE_SESSION_REQ_FWD      ] = "v2-delete-session-req-fwd"      
        self.ctr_name[V2_DELETE_SESSION_REQ_DRP      ] = "v2-delete-session-req-drp"      
        self.ctr_name[V2_DELETE_SESSION_RSP_RCV      ] = "v2-delete-session-rsp-rcv"      
        self.ctr_name[V2_DELETE_SESSION_RSP_FWD      ] = "v2-delete-session-rsp-fwd"      
        self.ctr_name[V2_DELETE_SESSION_RSP_DRP      ] = "v2-delete-session-rsp-drp"      
        self.ctr_name[V2_CREATE_BEARER_REQ_RCV       ] = "v2-create-bearer-req-rcv"       
        self.ctr_name[V2_CREATE_BEARER_REQ_FWD       ] = "v2-create-bearer-req-fwd"       
        self.ctr_name[V2_CREATE_BEARER_REQ_DRP       ] = "v2-create-bearer-req-drp"       
        self.ctr_name[V2_CREATE_BEARER_RSP_RCV       ] = "v2-create-bearer-rsp-rcv"       
        self.ctr_name[V2_CREATE_BEARER_RSP_FWD       ] = "v2-create-bearer-rsp-fwd"       
        self.ctr_name[V2_CREATE_BEARER_RSP_DRP       ] = "v2-create-bearer-rsp-drp"       
        self.ctr_name[V2_MODIFY_BEARER_REQ_RCV       ] = "v2-modify-bearer-req-rcv"       
        self.ctr_name[V2_MODIFY_BEARER_REQ_FWD       ] = "v2-modify-bearer-req-fwd"       
        self.ctr_name[V2_MODIFY_BEARER_REQ_DRP       ] = "v2-modify-bearer-req-drp"       
        self.ctr_name[V2_MODIFY_BEARER_RSP_RCV       ] = "v2-modify-bearer-rsp-rcv"       
        self.ctr_name[V2_MODIFY_BEARER_RSP_FWD       ] = "v2-modify-bearer-rsp-fwd"       
        self.ctr_name[V2_MODIFY_BEARER_RSP_DRP       ] = "v2-modify-bearer-rsp-drp"       
        self.ctr_name[V2_DELETE_BEARER_REQ_RCV       ] = "v2-delete-bearer-req-rcv"       
        self.ctr_name[V2_DELETE_BEARER_REQ_FWD       ] = "v2-delete-bearer-req-fwd"       
        self.ctr_name[V2_DELETE_BEARER_REQ_DRP       ] = "v2-delete-bearer-req-drp"       
        self.ctr_name[V2_DELETE_BEARER_RSP_RCV       ] = "v2-delete-bearer-rsp-rcv"       
        self.ctr_name[V2_DELETE_BEARER_RSP_FWD       ] = "v2-delete-bearer-rsp-fwd"       
        self.ctr_name[V2_DELETE_BEARER_RSP_DRP       ] = "v2-delete-bearer-rsp-drp"       
        self.ctr_name[V2_CONTEXT_REQ_RCV             ] = "v2-context-req-rcv"             
        self.ctr_name[V2_CONTEXT_REQ_FWD             ] = "v2-context-req-fwd"             
        self.ctr_name[V2_CONTEXT_REQ_DRP             ] = "v2-context-req-drp"             
        self.ctr_name[V2_CONTEXT_RSP_RCV             ] = "v2-context-rsp-rcv"             
        self.ctr_name[V2_CONTEXT_RSP_FWD             ] = "v2-context-rsp-fwd"             
        self.ctr_name[V2_CONTEXT_RSP_DRP             ] = "v2-context-rsp-drp"             
        self.ctr_name[V2_CONTEXT_ACK_RCV             ] = "v2-context-ack-rcv"             
        self.ctr_name[V2_CONTEXT_ACK_FWD             ] = "v2-context-ack-fwd"             
        self.ctr_name[V2_CONTEXT_ACK_DRP             ] = "v2-context-ack-drp"             
        self.ctr_name[V2_FORWARD_RELOC_REQ_RCV       ] = "v2-forward-reloc-req-rcv"       
        self.ctr_name[V2_FORWARD_RELOC_REQ_FWD       ] = "v2-forward-reloc-req-fwd"       
        self.ctr_name[V2_FORWARD_RELOC_REQ_DRP       ] = "v2-forward-reloc-req-drp"       
        self.ctr_name[V2_FORWARD_RELOC_RSP_RCV       ] = "v2-forward-reloc-rsp-rcv"       
        self.ctr_name[V2_FORWARD_RELOC_RSP_FWD       ] = "v2-forward-reloc-rsp-fwd"       
        self.ctr_name[V2_FORWARD_RELOC_RSP_DRP       ] = "v2-forward-reloc-rsp-drp"       
        self.ctr_name[V2_CREATE_INDIR_FWD_TNL_REQ_RCV] = "v2-create-indir-fwd-tnl-req-rcv"
        self.ctr_name[V2_CREATE_INDIR_FWD_TNL_REQ_FWD] = "v2-create-indir-fwd-tnl-req-fwd"
        self.ctr_name[V2_CREATE_INDIR_FWD_TNL_REQ_DRP] = "v2-create-indir-fwd-tnl-req-drp"
        self.ctr_name[V2_CREATE_INDIR_FWD_TNL_RSP_RCV] = "v2-create-indir-fwd-tnl-rsp-rcv"
        self.ctr_name[V2_CREATE_INDIR_FWD_TNL_RSP_FWD] = "v2-create-indir-fwd-tnl-rsp-fwd"
        self.ctr_name[V2_CREATE_INDIR_FWD_TNL_RSP_DRP] = "v2-create-indir-fwd-tnl-rsp-drp"
        self.ctr_name[V2_OTHERS_RCV                  ] = "v2-others-rcv"                  
        self.ctr_name[V2_OTHERS_FWD                  ] = "v2-others-fwd"                  
        self.ctr_name[V2_OTHERS_DRP                  ] = "v2-others-drp"                  

class HA_cnt(S_Counter):
    def __init__(self):
        self.name = "ha"
        self.ctr_cnt = GTP_HA_CTR_MAX
        self.ctr_name = {}
        self.ctr_val = {}

        self.ctr_name[TOTAL_RECV                ] = "total-recv"               
        self.ctr_name[TOTAL_RECV_OK             ] = "total-recv-ok"
        self.ctr_name[TOTAL_RECV_BAD_MSG        ] = "total-recv-bad-msg"
        self.ctr_name[TOTAL_RECV_UNKNOWN_TYPE   ] = "total-recv-unknown-type"
        self.ctr_name[TOTAL_RECV_UNKNOWN_VERSION] = "total-recv-unknown-version"
        self.ctr_name[TOTAL_SEND                ] = "total-send"
        self.ctr_name[TOTAL_SEND_OK             ] = "total-send-ok"
        self.ctr_name[TOTAL_SEND_FAIL           ] = "total-send-fail"
        self.ctr_name[TOTAL_ALLOC_MEMORY_FAIL   ] = "total-alloc-memory-fail"
        self.ctr_name[TOTAL_UNDER_RESET         ] = "total-under-reset"

class Request_cnt(S_Counter):
    def __init__(self):
        self.name = "request"
        self.ctr_cnt = GTP_REQ_CTR_MAX
        self.ctr_name = {}
        self.ctr_val = {}

        self.ctr_name[ALLOCATE_REQUEST     ] = "allocate-request"
        self.ctr_name[FREE_REQUEST         ] = "free-request"
        self.ctr_name[ALLOCATE_REQUEST_FAIL] = "allocate-request-fail"
        self.ctr_name[REQUEST_HIT_ERROR    ] = "request-hit-error"
        self.ctr_name[PENDING_TIMEOUT      ] = "pending-timeout"

class Error_cnt(S_Counter):
    def __init__(self):
        self.name = "error"
        self.ctr_cnt = GTP_ERROR_CTR_MAX
        self.ctr_name = {}
        self.ctr_val = {}

        self.ctr_name[TOTAL                 ] = "total"
        self.ctr_name[EXCEPTION             ] = "exception"
        self.ctr_name[GTP_HEADER            ] = "gtp-header"   
        self.ctr_name[LENGTH                ] = "length"      
        self.ctr_name[IMSI                  ] = "imsi"
        self.ctr_name[CHARGE_ID             ] = "charge-id"
        self.ctr_name[SEQUENCE              ] = "sequence"
        self.ctr_name[APN                   ] = "apn"
        self.ctr_name[TRANSPORT             ] = "transport"
        self.ctr_name[GTP_IN_GTP            ] = "gtp-in-gtp"
        self.ctr_name[LENGTH_SHORT          ] = "length-short"
        self.ctr_name[LENGTH_LONG           ] = "length-long"
        self.ctr_name[GSN_NOT_EXIST         ] = "gsn-not-exist"
        self.ctr_name[RATE_LIMIT            ] = "rate-limit"
        self.ctr_name[RESPONSE_NOT_MATCH    ] = "response-not-match"
        self.ctr_name[RESPONSE_RETRANSMIT   ] = "response-retransmit"
        self.ctr_name[MISSING_IE            ] = "missing-ie"
        self.ctr_name[UNEXPECT_IE           ] = "unexpect-ie"
        self.ctr_name[IE_TYPE               ] = "ie-type"
        self.ctr_name[IE_ORDER              ] = "ie-order"
        self.ctr_name[IE_LENGTH             ] = "ie-length"
        self.ctr_name[DUPLICATE_IE          ] = "duplicate-ie"
        self.ctr_name[NON_DIGIT             ] = "non-digit"
        self.ctr_name[TID_NOT_0             ] = "tid-not-0"
        self.ctr_name[TID_0                 ] = "tid-0"
        self.ctr_name[TID_CONTROL           ] = "tid-control"
        self.ctr_name[TID_DATA              ] = "tid-data"
        self.ctr_name[CONTROL_IP            ] = "control-ip"
        self.ctr_name[DATA_IP               ] = "data-ip"
        self.ctr_name[END_USER_IP           ] = "end-user-ip"
        self.ctr_name[GGSN_IP               ] = "ggsn-ip"
        self.ctr_name[MESSAGE_V0            ] = "message-v0"
        self.ctr_name[MESSAGE_V1            ] = "message-v1"
        self.ctr_name[MESSAGE_V2            ] = "message-v2"
        self.ctr_name[MESSAGE_TYPE          ] = "message-type"
        self.ctr_name[NO_TUNNEL_0           ] = "no-tunnel-0"
        self.ctr_name[NO_CONTROL_TUNNEL     ] = "no-control-tunnel"
        self.ctr_name[NO_USER_TUNNEL        ] = "no-user-tunnel"
        self.ctr_name[INVALID_TUNNEL_0      ] = "invalid-tunnel-0"
        self.ctr_name[INVALID_CONTROL_TUNNEL] = "invalid-control-tunnel"
        self.ctr_name[INVALID_USER_TUNNEL   ] = "invalid-user-tunnel"
        self.ctr_name[CREATE_TUNNEL_0       ] = "create-tunnel-0"
        self.ctr_name[CREATE_CONTROL_TUNNEL ] = "create-control-tunnel"
        self.ctr_name[CREATE_USER_TUNNEL    ] = "create-user-tunnel"
        self.ctr_name[NO_REQUEST            ] = "no-request"
        self.ctr_name[NEW_REQUEST           ] = "new-request"
        self.ctr_name[NO_ACTION             ] = "no-action"
        self.ctr_name[NEW_ACTION            ] = "new-action"
        self.ctr_name[NOT_UNIQUE_TID        ] = "not-unique-tid"
        self.ctr_name[MISSING_TID           ] = "missing-tid"
        self.ctr_name[EBI_NOT_0             ] = "ebi-not-0"
        self.ctr_name[EBI_NOT_EXIST         ] = "ebi-not-exist"
        self.ctr_name[BEARER_IE             ] = "bearer-ie"
        self.ctr_name[DUP_JBUF              ] = "dup-jbuf"
        self.ctr_name[NEW_JMPI_COOKIE       ] = "new-jmpi-cookie"
        self.ctr_name[SEND_JMPI_MSG         ] = "send-jmpi-msg"
        self.ctr_name[JMPI_TARGET_FAILED    ] = "jmpi-target-failed"
        self.ctr_name[NEW_RT_COOKIE         ] = "new-rt-cookie"
        self.ctr_name[REINJECT              ] = "reinject"
        self.ctr_name[WRONG_SPU             ] = "wrong-spu"
        self.ctr_name[UNDER_RESET           ] = "under-reset"
        self.ctr_name[SRC_IP                ] = "src-ip"
        self.ctr_name[DST_IP                ] = "dst-ip"
        self.ctr_name[V2_INVALID_EBI        ] = "v2-invalid-ebi"
        self.ctr_name[ALL_UP                ] = "all-up"
        self.ctr_name[INTERFACE             ] = "interface"
        self.ctr_name[NEW_PATH              ] = "new_path"
        self.ctr_name[PATH_OVER_RATE        ] = "path_over_rate"
        self.ctr_name[NEW_UTNL_KEY          ] = "new_utnl_key"
        self.ctr_name[NO_UTNL_KEY           ] = "no_utnl_key"
        self.ctr_name[END_USER              ] = "end_user"
        self.ctr_name[NEW_SYNC_ACTION       ] = "new_sync_action"
        self.ctr_name[NSAPI                 ] = "nsapi"
        self.ctr_name[CONFLICT_SYNC_ACTION  ] = "conflict_sync_action"
        self.ctr_name[PRI_UID_NOT_EXIST     ] = "pri_uid_not_exist"
        self.ctr_name[TOO_MANY_SAME_TYPE_IE ] = "too_many_same_type_ie"
        self.ctr_name[V2_LBI                ] = "v2_lbi"
        self.ctr_name[RM_CONFLICT_UTNL      ] = "rm_conflict_utnl"
        self.ctr_name[CONFLICT_PRI_UTNL     ] = "conflict_pri_utnl"
        self.ctr_name[CTNL_RECOVERY         ] = "ctnl_recovery"
        self.ctr_name[LINK_CTNL_CONFLICT    ] = "link_ctnl_conflict"
        self.ctr_name[LINK_UTNL_CONFLICT    ] = "link_utnl_conflict"
        self.ctr_name[LINK_TNL0_CONFLICT    ] = "link_tnl0_conflict"
        self.ctr_name[V0_GGSN_IP_CHG        ] = "v0_ggsn_ip_chg"
        self.ctr_name[INVALID_PAYLOAD       ] = "invalid_payload"
        self.ctr_name[WRONG_SPU_SINFO       ] = "wrong_spu_sinfo"
        self.ctr_name[WRONG_SPU_WING        ] = "wrong_spu_wing"
        self.ctr_name[WRONG_SPU_ANCHOR      ] = "wrong_spu_anchor"

DATA_PACKET_CNT   = 0
MESSAGE_BRIEF_CNT = 1
HA_CNT            = 2
REQ_CNT           = 3
ERROR_CNT         = 4
gtp_counters = [Data_packet_cnt(), Message_brief_cnt(), HA_cnt(), Request_cnt(), Error_cnt()]

def get_gtp_counter(dut, cnt_type):
    dut.enter_cli()
    info = dut.do_cli("show security gprs gtp counter %s | display xml | no-more"%gtp_counters[cnt_type].name)
    counter = parse(info, cnt_type)
    dut.exit_cli()
    return counter

test_string = "\
<rpc-reply xmlns:junos='http://xml.juniper.net/junos/15.1I0/junos'>\n\
    <gtp-show-counters xmlns='http://xml.juniper.net/junos/15.1I0/junos-gtp'>\n\
        <data-packet>\n\
            <gtpu_v1_pkt_rcv>0</gtpu_v1_pkt_rcv>\n\
            <gtpu_v1_pkt_pass>0</gtpu_v1_pkt_pass>\n\
            <gtpu_v1_pkt_drop>0</gtpu_v1_pkt_drop>\n\
            <gtpu_v1_pkt_no_tnl_drop>0</gtpu_v1_pkt_no_tnl_drop>\n\
            <gtpu_v1_pkt_seq_check_drop>0</gtpu_v1_pkt_seq_check_drop>\n\
            <gtpu_v1_pkt_end_user_check_drop>0</gtpu_v1_pkt_end_user_check_drop>\n\
            <gtpu_v1_pkt_other_check_drop>0</gtpu_v1_pkt_other_check_drop>\n\
            <gtpu_v0_pkt_rcv>0</gtpu_v0_pkt_rcv>\n\
            <gtpu_v0_pkt_pass>0</gtpu_v0_pkt_pass>\n\
            <gtpu_v0_pkt_drop>0</gtpu_v0_pkt_drop>\n\
            <gtpu_v0_pkt_no_tnl_drop>0</gtpu_v0_pkt_no_tnl_drop>\n\
            <gtpu_v0_pkt_seq_check_drop>0</gtpu_v0_pkt_seq_check_drop>\n\
            <gtpu_v0_pkt_end_user_check_drop>0</gtpu_v0_pkt_end_user_check_drop>\n\
            <gtpu_v0_pkt_other_check_drop>0</gtpu_v0_pkt_other_check_drop>\n\
        </data-packet>\n\
    </gtp-show-counters>\n\
    <cli>\n\
        <banner></banner>\n\
    </cli>\n\
</rpc-reply>\n"

def main():
    obj = parse(test_string, DATA_PACKET_CNT)
    print obj.to_string()
 
if "__main__" == __name__:
    main()  
