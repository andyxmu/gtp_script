import string, glob, os, sys
sys.path.append("../")
import s_net_toolkit as s_net
import datetime
import s_eth, s_ip, s_udp
import ipaddr
import ordered_dict
from struct import *

TV_FORMAT = ["!H", "!HB", "!HH", "!HL", "!HQ"]

GTP0_PORT = 3386
GTP1C_PORT = 2123
GTP1U_PORT = 2152
IS_TLV = True

#-------------------TLV--------------------------------------------
#   0                   1                   2                   3
#   0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
#  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
#  |        Type                   |      Length                   |
#  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
#  |                        Value                                  |
#  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
def pack_v(m_value):
    fmt = "!%ds"%len(m_value)
    return pack(fmt, m_value)

def pack_lv(m_value):
    fmt = "!B%ds"%len(m_value)
    return pack(fmt, len(m_value), m_value)

def pack_tlv(m_type, m_value):
    fmt = "!BH%ds"%len(m_value)
                     # type  len           value
    return pack(fmt, m_type, len(m_value), m_value)

def unpack_tlv(buf):
    t = unpack_from("!B", buf[0:1])[0]
    l = unpack_from("!H", buf[1:3])[0]
    v = buf[3:l]
    return (t, v, IS_TLV)

def pack_tvn(m_type, m_value, n):
    fmt = "!B%ds"%n
    return pack(fmt, m_type, m_value)

def unpack_tvn(buf, n): 
    t = unpack_from("!B", buf[0:1])[0]
    v = buf[1:1 + n]
    return (t, v, not IS_TLV)


def pack_tv1(m_type, m_value):
    return pack_tvn(m_type, m_value, 1)

def pack_tv2(m_type, m_value):
    return pack_tvn(m_type, m_value, 2)

def pack_tv3(m_type, m_value):
    return pack_tvn(m_type, m_value, 3)

def pack_tv4(m_type, m_value):
    return pack_tvn(m_type, m_value, 4)

def pack_tv5(m_type, m_value):
    return pack_tvn(m_type, m_value, 5)

def pack_tv6(m_type, m_value):
    return pack_tvn(m_type, m_value, 6)

def pack_tv7(m_type, m_value):
    return pack_tvn(m_type, m_value, 7)

def pack_tv8(m_type, m_value):
    return pack_tvn(m_type, m_value, 8)

def pack_tv28(m_type, m_value):
    return pack_tvn(m_type, m_value, 28)

def unpack_tv1(buf):
    return unpack_tvn(buf, 1)

def unpack_tv2(buf):
    return unpack_tvn(buf, 2)

def unpack_tv3(buf):
    return unpack_tvn(buf, 3)

def unpack_tv4(buf):
    return unpack_tvn(buf, 4)

def unpack_tv5(buf):
    return unpack_tvn(buf, 5)

def unpack_tv6(buf):
    return unpack_tvn(buf, 6)
 
def unpack_tv7(buf):
    return unpack_tvn(buf, 7)

def unpack_tv8(buf):
    return unpack_tvn(buf, 8)

def unpack_tv28(buf):
    return unpack_tvn(buf, 28)


class S_Gtpiev1:
    def __init__(self):
        self.GTPIE = {}
        self.GTPIE_OP = {}


        # GTP Information elements from 29.060 v3.9.0 7.7 Information Elements
        # Also covers version 0. Note that version 0 6: QOS Profile was superceded
        # by 135: QOS Profile in version 1 
        
        self.GTPIE[1] = "GTPIE_CAUSE"	                # Cause 1
        self.GTPIE[2] = "GTPIE_IMSI"	                # International Mobile Subscriber Identity 8
        self.GTPIE[3] = "GTPIE_RAI"	                # Routing Area Identity (RAI) 8
        self.GTPIE[4] = "GTPIE_TLLI"	                # Temporary Logical Link Identity (TLLI) 4
        self.GTPIE[5] = "GTPIE_P_TMSI"	                # Packet TMSI (P-TMSI) 4
        self.GTPIE[6] = "GTPIE_QOS_PROFILE0"	        # Quality of Service Profile GTP version 0 3
        # 6-7 SPARE *//* 6 is QoS Profile vers 0
        self.GTPIE[8] = "GTPIE_REORDER"	                # Reordering Required 1
        self.GTPIE[9] = "GTPIE_AUTH_TRIPLET"	        # Authentication Triplet 28
        # 10 SPARE
        self.GTPIE[11] = "GTPIE_MAP_CAUSE"	        # MAP Cause 1
        self.GTPIE[12] = "GTPIE_P_TMSI_S"	        # P-TMSI Signature 3
        self.GTPIE[13] = "GTPIE_MS_VALIDATED"	    # MS Validated 1
        self.GTPIE[14] = "GTPIE_RECOVERY"	    # Recovery 1
        self.GTPIE[15] = "GTPIE_SELECTION_MODE"	    # Selection Mode 1
        self.GTPIE[16] = "GTPIE_FL_DI"	            # Flow Label Data I 2
        self.GTPIE[16] = "GTPIE_TEI_DI"	            # Tunnel Endpoint Identifier Data I 4
        self.GTPIE[17] = "GTPIE_TEI_C"	            # Tunnel Endpoint Identifier Control Plane 4
        #self.GTPIE[17] = "GTPIE_FL_C"	            # Flow Label Signalling 2
        self.GTPIE[18] = "GTPIE_TEI_DII"	    # Tunnel Endpoint Identifier Data II 5
        self.GTPIE[19] = "GTPIE_TEARDOWN"	    # Teardown Ind 1
        self.GTPIE[20] = "GTPIE_NSAPI"	            # NSAPI 1
        self.GTPIE[21] = "GTPIE_RANAP_CAUSE"	    # RANAP Cause 1
        self.GTPIE[22] = "GTPIE_RAB_CONTEXT"	    # RAB Context 7
        self.GTPIE[23] = "GTPIE_RP_SMS"	            # Radio Priority SMS 1
        self.GTPIE[24] = "GTPIE_RP"	            # Radio Priority 1
        self.GTPIE[25] = "GTPIE_PFI"	            # Packet Flow Id 2
        self.GTPIE[26] = "GTPIE_CHARGING_C"	    # Charging Characteristics 2
        self.GTPIE[27] = "GTPIE_TRACE_REF"	    # Trace Reference 2
        self.GTPIE[28] = "GTPIE_TRACE_TYPE"	    # Trace Type 2
        self.GTPIE[29] = "GTPIE_MS_NOT_REACH"	    # MS Not Reachable Reason 1
        # 30-116 UNUSED
        # 117-126 Reserved for the GPRS charging protocol (see GTP' in GSM 12.15)
        self.GTPIE[127] = "GTPIE_CHARGING_ID"	    # Charging ID 4
        self.GTPIE[128] = "GTPIE_EUA"	            # End User Address
        self.GTPIE[129] = "GTPIE_MM_CONTEXT"	    # MM Context
        self.GTPIE[130] = "GTPIE_PDP_CONTEXT"	    # PDP Context
        self.GTPIE[131] = "GTPIE_APN"	            # Access Point Name
        self.GTPIE[132] = "GTPIE_PCO"	            # Protocol Configuration Options
        self.GTPIE[133] = "GTPIE_GSN_ADDR"	    # GSN Address
        self.GTPIE[134] = "GTPIE_MSISDN"	    # MS International PSTN/ISDN Number
        self.GTPIE[135] = "GTPIE_QOS_PROFILE"	    # Quality of Service Profile
        self.GTPIE[136] = "GTPIE_AUTH_QUINTUP"	    # Authentication Quintuplet
        self.GTPIE[137] = "GTPIE_TFT"	            # Traffic Flow Template
        self.GTPIE[138] = "GTPIE_TARGET_ID"	    # Target Identification
        self.GTPIE[139] = "GTPIE_UTRAN_TRANS"	    # UTRAN Transparent Container
        self.GTPIE[140] = "GTPIE_RAB_SETUP"	    # RAB Setup Information
        self.GTPIE[141] = "GTPIE_EXT_HEADER_T"	    # Extension Header Type List
        self.GTPIE[142] = "GTPIE_TRIGGER_ID"	    # Trigger Id
        self.GTPIE[143] = "GTPIE_OMC_ID"	    # OMC Identity
        self.GTPIE[151] = "GTPIE_RAT_TYPE"	    # Radio Access Technology Type
        self.GTPIE[152] = "GTPIE_USER_LOC"	    # User Location Information 
        self.GTPIE[153] = "GTPIE_MS_TZ"	            # MS Time Zone
        self.GTPIE[154] = "GTPIE_IMEI_SV"	    # IMEI Software Version
        # 239-250 Reserved for the GPRS charging protocol (see GTP' in GSM 12.15)
        self.GTPIE[251] = "GTPIE_CHARGING_ADDR"	    # Charging Gateway Address
        # 252-254 Reserved for the GPRS charging protocol (see GTP' in GSM 12.15)
        self.GTPIE[255] = "GTPIE_PRIVATE"	    # Private Extension

        self.GTPIE_ID= {}

        for key in self.GTPIE:
            self.GTPIE_ID[self.GTPIE[key]] = key


        # TV GTPIE types with value length 1
    	self.GTPIE_OP["GTPIE_CAUSE"] = \
        self.GTPIE_OP["GTPIE_REORDER"] = \
        self.GTPIE_OP["GTPIE_MAP_CAUSE"] = \
        self.GTPIE_OP["GTPIE_MS_VALIDATED"] = \
        self.GTPIE_OP["GTPIE_RECOVERY"] = \
        self.GTPIE_OP["GTPIE_SELECTION_MODE"] = \
        self.GTPIE_OP["GTPIE_TEARDOWN"] = \
        self.GTPIE_OP["GTPIE_NSAPI"] = \
        self.GTPIE_OP["GTPIE_RANAP_CAUSE"] = \
        self.GTPIE_OP["GTPIE_RP_SMS"] = \
        self.GTPIE_OP["GTPIE_RP"] = \
        self.GTPIE_OP["GTPIE_MS_NOT_REACH"] = (pack_tv1, unpack_tv1)


        # TV GTPIE types with value length 2
        self.GTPIE_OP["GTPIE_PFI"] = \
        self.GTPIE_OP["GTPIE_CHARGING_C"] = \
        self.GTPIE_OP["GTPIE_TRACE_REF"] = \
        self.GTPIE_OP["GTPIE_TRACE_TYPE"] = (pack_tv2, unpack_tv2)

	# TV GTPIE types with value length 3
        self.GTPIE_OP["GTPIE_QOS_PROFILE0"] = \
        self.GTPIE_OP["GTPIE_P_TMSI_S"] = (pack_tv3, unpack_tv3) 

        # TV GTPIE types with value length 4
        self.GTPIE_OP["GTPIE_CHARGING_ID"] = \
        self.GTPIE_OP["GTPIE_TLLI"] = \
        self.GTPIE_OP["GTPIE_P_TMSI"] = \
        self.GTPIE_OP["GTPIE_TEI_DI"] = \
        self.GTPIE_OP["GTPIE_TEI_C"] = (pack_tv4, unpack_tv4)

        # TV GTPIE types with value length 5
        self.GTPIE_OP["GTPIE_TEI_DII"] = (pack_tv5, unpack_tv5)

        # TV GTPIE types with value length 6
        self.GTPIE_OP["GTPIE_RAI"] = (pack_tv6, unpack_tv6)

        # TV GTPIE types with value length 7
        self.GTPIE_OP["GTPIE_RAB_CONTEXT"] = (pack_tv7, unpack_tv7)

        # TV GTPIE types with value length 8
        self.GTPIE_OP["GTPIE_IMSI"] = (pack_tv8, unpack_tv8)

        # TV GTPIE types with value length 28
        self.GTPIE_OP["GTPIE_AUTH_TRIPLET"] = (pack_tv28, unpack_tv28)

        # GTP extension header
        self.GTPIE_OP["GTPIE_EXT_HEADER_T"] = "Do not support!!"

        # TLV GTPIE types with variable length 
        self.GTPIE_OP["GTPIE_EUA"] = \
        self.GTPIE_OP["GTPIE_MM_CONTEXT"] = \
        self.GTPIE_OP["GTPIE_PDP_CONTEXT"] = \
        self.GTPIE_OP["GTPIE_APN"] = \
        self.GTPIE_OP["GTPIE_PCO"] = \
        self.GTPIE_OP["GTPIE_GSN_ADDR"] = \
        self.GTPIE_OP["GTPIE_MSISDN"] = \
        self.GTPIE_OP["GTPIE_QOS_PROFILE"] = \
        self.GTPIE_OP["GTPIE_AUTH_QUINTUP"] = \
        self.GTPIE_OP["GTPIE_TFT"] = \
        self.GTPIE_OP["GTPIE_TARGET_ID"] = \
        self.GTPIE_OP["GTPIE_UTRAN_TRANS"] = \
        self.GTPIE_OP["GTPIE_RAB_SETUP"] = \
        self.GTPIE_OP["GTPIE_TRIGGER_ID"] = \
        self.GTPIE_OP["GTPIE_OMC_ID"] = \
        self.GTPIE_OP["GTPIE_CHARGING_ADDR"] = \
        self.GTPIE_OP["GTPIE_PRIVATE"] = \
        self.GTPIE_OP["GTPIE_MS_TZ"] = (pack_tlv, unpack_tlv)

    def pack(self, t, v):
        if "str" != type(t).__name__:
            print "Please use string as type, not a digital."
            return ""
        return self.GTPIE_OP[t][0](self.GTPIE_ID[t], v)

    def unpack(self, buf):
        t = unpack_from("!B", buf[0:1])[0]
        return self.GTPIE_OP[self.GTPIE[t]][1](buf)

    def unpack_all_ie(self, buf):
        ies = {}
        for i in range(0, len(buf)):
            (t, v, is_tlv) = self.unpack(buf[i:])
            if is_tlv:
                i += len(v) + 3
            else:
                i += len(v) + 1
            ies[t] = v
        return ies
            
# Descriptions from 3GPP 29060
class S_Gtpv1:
    def __init__(self):
        self.MSG_TYPE = {}
        # GTP version 1 message type definitions. Also covers version 0 except *
        # for anonymous PDP context which was superceded in version 1 */

        # 0 For future use.
        self.MSG_TYPE["GTP_ECHO_REQ"] = 1	        # Echo Request
        self.MSG_TYPE["GTP_ECHO_RSP"] = 2	        # Echo Response
        self.MSG_TYPE["GTP_NOT_SUPPORTED"] = 3	        # Version Not Supported
        self.MSG_TYPE["GTP_ALIVE_REQ"] = 4	        # Node Alive Request
        self.MSG_TYPE["GTP_ALIVE_RSP"] = 5	        # Node Alive Response
        self.MSG_TYPE["GTP_REDIR_REQ"] = 6	        # Redirection Request
        self.MSG_TYPE["GTP_REDIR_RSP"] = 7	        # Redirection Response
        # 8-15 For future use.
        self.MSG_TYPE["GTP_CREATE_PDP_REQ"] = 16	# Create PDP Context Request
        self.MSG_TYPE["GTP_CREATE_PDP_RSP"] = 17	# Create PDP Context Response
        self.MSG_TYPE["GTP_UPDATE_PDP_REQ"] = 18	# Update PDP Context Request
        self.MSG_TYPE["GTP_UPDATE_PDP_RSP"] = 19	# Update PDP Context Response
        self.MSG_TYPE["GTP_DELETE_PDP_REQ"] = 20	# Delete PDP Context Request
        self.MSG_TYPE["GTP_DELETE_PDP_RSP"] = 21	# Delete PDP Context Response
        # 22-25 For future use. In version GTP 1 anonomous PDP context
        self.MSG_TYPE["GTP_ERROR"] = 26	                # Error Indication
        self.MSG_TYPE["GTP_PDU_NOT_REQ"] = 27	        # PDU Notification Request
        self.MSG_TYPE["GTP_PDU_NOT_RSP"] = 28	        # PDU Notification Response
        self.MSG_TYPE["GTP_PDU_NOT_REJ_REQ"] = 29	# PDU Notification Reject Request
        self.MSG_TYPE["GTP_PDU_NOT_REJ_RSP"] = 30	# PDU Notification Reject Response
        self.MSG_TYPE["GTP_SUPP_EXT_HEADER"] = 31	# Supported Extension Headers Notification
        self.MSG_TYPE["GTP_SND_ROUTE_REQ"] = 32	        # Send Routeing Information for GPRS Request
        self.MSG_TYPE["GTP_SND_ROUTE_RSP"] = 33	        # Send Routeing Information for GPRS Response
        self.MSG_TYPE["GTP_FAILURE_REQ"] = 34	        # Failure Report Request
        self.MSG_TYPE["GTP_FAILURE_RSP"] = 35	        # Failure Report Response
        self.MSG_TYPE["GTP_MS_PRESENT_REQ"] = 36	# Note MS GPRS Present Request
        self.MSG_TYPE["GTP_MS_PRESENT_RSP"] = 37	# Note MS GPRS Present Response
        # 38-47 For future use.
        self.MSG_TYPE["GTP_IDEN_REQ"] = 48	        # Identification Request
        self.MSG_TYPE["GTP_IDEN_RSP"] = 49	        # Identification Response
        self.MSG_TYPE["GTP_SGSN_CONTEXT_REQ"] = 50	# SGSN Context Request
        self.MSG_TYPE["GTP_SGSN_CONTEXT_RSP"] = 51	# SGSN Context Response
        self.MSG_TYPE["GTP_SGSN_CONTEXT_ACK"] = 52	# SGSN Context Acknowledge
        self.MSG_TYPE["GTP_FWD_RELOC_REQ"] = 53	        # Forward Relocation Request
        self.MSG_TYPE["GTP_FWD_RELOC_RSP"] = 54	        # Forward Relocation Response
        self.MSG_TYPE["GTP_FWD_RELOC_COMPL"] = 55	# Forward Relocation Complete
        self.MSG_TYPE["GTP_RELOC_CANCEL_REQ"] = 56	# Relocation Cancel Request
        self.MSG_TYPE["GTP_RELOC_CANCEL_RSP"] = 57	# Relocation Cancel Response
        self.MSG_TYPE["GTP_FWD_SRNS"] = 58	        # Forward SRNS Context
        self.MSG_TYPE["GTP_FWD_RELOC_ACK"] = 59	        # Forward Relocation Complete Acknowledge
        self.MSG_TYPE["GTP_FWD_SRNS_ACK"] = 60	        # Forward SRNS Context Acknowledge
        # 61-239 For future use.
        self.MSG_TYPE["GTP_DATA_TRAN_REQ"] = 240	# Data Record Transfer Request
        self.MSG_TYPE["GTP_DATA_TRAN_RSP"] = 241	# Data Record Transfer Response
        # 242-254 For future use.
        self.MSG_TYPE["GTP_GPDU"] = 255	        # G-PDU

        # 01 bitfield, with typical values
        #    001..... Version: 1
	#    ...1.... Protocol Type: GTP=1, GTP'=0
	#    ....0... Spare = 0
	#    .....0.. Extension header flag: 0
	#    ......0. Sequence number flag: 0
	#    .......0 PN: N-PDU Number flag
        self.set_flags(1, 0, 1, 0)
        self.msg_type = \
            self.MSG_TYPE["GTP_CREATE_PDP_REQ"];    # 02 Message type. T-PDU = 0xff
        #self.length = 0;	                    # 03 Length (of IP packet or signalling) 
        self.teid = 0x11111;		            # 05 - 08 Tunnel Endpoint ID 
        self.seq = 0;		# 10 Sequence Number 
	self.npdu = 0;		# 11 N-PDU Number 
	self.next_hdr_type = 0;	# 12 Next extension header type. Empty = 0 
        self.payload = ""
        
    def set_seq(self, seq):
        self.seq = seq

    def set_npdu(self, npdu):
        self.npdu = npdu

    def set_next_hdr_type(self, next_hdr_type):
        self.next_hdr_type = next_hdr_type

    def set_teid(self, teid):
        self.teid = teid

    def set_msg_type(self, msg_type):
        self.msg_type = self.MSG_TYPE[msg_type]

    # set to 1 or zero
    def set_flags(self, PT, E, S, PN):
        self.flags = 0x20
        if 1 == PT:
            self.flags += 16
        if 1 == E:
            self.flags += 4
        if 1 == S:
            self.flags += 2
        if 1== PN:
            self.flags += 1

    def is_long_hdr(self):
        return (self.flags & 0x7) != 0
    
    def get_version(self):
        return 1

    def create_pdp_req(self):
        ies = ordered_dict.OrderedDict() 
        ies["GTPIE_IMSI"] = "\x24\x00\x11\x32\x54\x76\x00\xf0" 
        ies["GTPIE_RECOVERY"] = "\x0a"
        ies["GTPIE_SELECTION_MODE"] = "\x00"
        ies["GTPIE_TEI_DI"] = pack("!I", 0x1) 
        ies["GTPIE_TEI_C"] = pack("!I", 0x1) 
        ies["GTPIE_NSAPI"] = "\x05"
        ies["GTPIE_EUA"] = "\xf1\x21\x01\x01\x01\x01"
        ies["GTPIE_APN"] = "\x08\x6a\x61\x77\x61\x6c\x6e\x65\x74\x03\x63\x6f\x6d\x04\x73\x61\x30\x30" #"jawalnet.com.sa00" #"auto-ut.gprs.juniper.net"
        ies["GTPIE_GSN_ADDR[0]"] = s_net.ip_str2b("172.1.1.1") # control ip
        ies["GTPIE_GSN_ADDR[1]"] = s_net.ip_str2b("172.1.1.1") # data ip
        ies["GTPIE_MSISDN"] = "\x91\x81\x19\x70\x83\x90\xf9"
        ies["GTPIE_QOS_PROFILE"] = "\x01\x09\x11\x01\x29\x01\x01\x01\x11\x05\x01\x01"
        return ies

    def create_pdp_rsp(self):
        ies =  ordered_dict.OrderedDict()
        ies["GTPIE_CAUSE"] = pack("!B", 128)
        ies["GTPIE_RECOVERY"] = "\x01"
        ies["GTPIE_TEI_DI"] = pack("!I", 0x1)
        ies["GTPIE_TEI_C"] = pack("!I", 0x1)
        ies["GTPIE_CHARGING_ID"] = pack("!I", 1)
        ies["GTPIE_EUA"] = "\xf1\x21\x01\x01\x01\x01"
        ies["GTPIE_GSN_ADDR[0]"] = s_net.ip_str2b("172.16.1.1")
        ies["GTPIE_GSN_ADDR[1]"] = s_net.ip_str2b("172.16.1.1")
        ies["GTPIE_QOS_PROFILE"] = "\x01\x09\x11\x01\x29\x01\x01\x01\x11\x05\x01\x01"
        return ies

    def create_sec_pdp_req(self):
        ies = ordered_dict.OrderedDict() 
        ies["GTPIE_TEI_DI"] = pack("!I", 0x1)
        ies["GTPIE_NSAPI[0]"] = "\x06"
        ies["GTPIE_NSAPI[1]"] = "\x05"
        ies["GTPIE_GSN_ADDR[0]"] = s_net.ip_str2b("172.1.1.1") # control ip
        ies["GTPIE_GSN_ADDR[1]"] = s_net.ip_str2b("172.1.1.1") # data ip
        ies["GTPIE_QOS_PROFILE"] = "\x01\x09\x11\x01\x29\x01\x01\x01\x11\x05\x01\x01"
        ies["GTPIE_TFT"] = "\x21\x00\x00\x11\x10\x03\x00\x00\x08\xff\xff\xff\xff\x30\x11\x40\x00\x00\x50\x07\xd3"
        return ies

    def create_sec_pdp_rsp(self):
        ies = ordered_dict.OrderedDict() 
        ies["GTPIE_CAUSE"] = pack("!B", 128)
        ies["GTPIE_TEI_DI"] = pack("!I", 0x1)
        ies["GTPIE_CHARGING_ID"] = pack("!I", 1)
        ies["GTPIE_GSN_ADDR[0]"] = s_net.ip_str2b("172.16.1.1")
        ies["GTPIE_GSN_ADDR[1]"] = s_net.ip_str2b("172.16.1.1")
        ies["GTPIE_QOS_PROFILE"] = "\x01\x09\x11\x01\x29\x01\x01\x01\x11\x05\x01\x01"
        return ies

    def update_pdp_req(self):
        ies = ordered_dict.OrderedDict() 
        ies["GTPIE_RECOVERY"] = "\x01"
        ies["GTPIE_TEI_DI"] = pack("!I", 0x2)
        ies["GTPIE_TEI_C"] = pack("!I", 0x2)
        ies["GTPIE_NSAPI"] = "\x05"
        ies["GTPIE_GSN_ADDR[0]"] = s_net.ip_str2b("172.1.1.2") # control ip
        ies["GTPIE_GSN_ADDR[1]"] = s_net.ip_str2b("172.1.1.2") # data ip
        ies["GTPIE_QOS_PROFILE"] = "\x01\x09\x11\x01\x29\x01\x01\x01\x11\x05\x01\x01"    
        return ies

    def update_pdp_rsp(self):
        ies = ordered_dict.OrderedDict() 
        ies["GTPIE_CAUSE"] = pack("!B", 128)
        ies["GTPIE_RECOVERY"] = "\x01"
        ies["GTPIE_TEI_DI"] = pack("!I", 0x1)
        ies["GTPIE_TEI_C"] = pack("!I", 0x1)
        ies["GTPIE_CHARGING_ID"] = pack("!I", 1)
        ies["GTPIE_GSN_ADDR[0]"] = s_net.ip_str2b("172.16.1.1") # control ip
        ies["GTPIE_GSN_ADDR[1]"] = s_net.ip_str2b("172.16.1.1") # data ip
        ies["GTPIE_QOS_PROFILE"] = "\x01\x09\x11\x01\x29\x01\x01\x01\x11\x05\x01\x01" 
        return ies

    def delete_pdp_req(self):
        ies = ordered_dict.OrderedDict() 
        ies["GTPIE_TEARDOWN"] = "\xfe"
        ies["GTPIE_NSAPI"] = "\x05"
        return ies

    def delete_pdp_rsp(self):
        ies = ordered_dict.OrderedDict() 
        ies["GTPIE_CAUSE"] = pack("!B", 128)
        ies["GTPIE_MS_TZ"] = "\xab\x02"
        return ies

    def sgsn_context_req(self):
        ies = ordered_dict.OrderedDict()
        ies["GTPIE_RAI"] = "\x03\x02\x15\x27\x10\x0a"
        ies["GTPIE_P_TMSI"] = "\xcf\x10\x1c\x0e"
        ies["GTPIE_P_TMSI_S"] = "\xa6\x4a\x25"
        ies["GTPIE_MS_VALIDATED"] = pack("!B", 0xfe)
        ies["GTPIE_TEI_C"] = pack("!I", 1) # control teid
        ies["GTPIE_GSN_ADDR"] = s_net.ip_str2b("172.1.1.2") # control ip
        return ies

    def sgsn_context_rsp(self):
        ies = ordered_dict.OrderedDict()
        ies["GTPIE_CAUSE"] = pack("!B", 128)
        ies["GTPIE_IMSI"] = pack("!Q", 123456789012345)
        ies["GTPIE_TEI_C"] = pack("!I", 0x9b)
        ies["GTPIE_PFI"] = "\x05\x08"
        ies["GTPIE_CHARGING_C"] = "\x00\x00"
        ies["GTPIE_MM_CONTEXT"] = ""
        ies["GTPIE_PDP_CONTEXT[0]"] = ""
        return ies

    def sgsn_context_ack(self):
        ies = ordered_dict.OrderedDict()
        ies["GTPIE_CAUSE"] = pack("!B", 128)
        ies["GTPIE_TEI_DII[0]"] = pack("!BI", 5, 0x1)
        return ies

    def forward_reloc_req(self, pdp_num = 1):
        ies = ordered_dict.OrderedDict()
        ies["GTPIE_IMSI"] = pack("!Q", 123456789012345)
        ies["GTPIE_TEI_C"] = pack("!I", 0x1)
        ies["GTPIE_RANAP_CAUSE"] = ""
        ies["GTPIE_MM_CONTEXT"] = ""
        for i in range(0, pdp_num):
            key = "GTPIE_PDP_CONTEXT[%d]"%i
            ies[key] = ""
        ies["GTPIE_GSN_ADDR"] = s_net.ip_str2b("172.1.1.2") # control ip
        ies["GTPIE_TARGET_ID"] = ""
        ies["GTPIE_UTRAN_TRANS"] = ""
        return ies

    def forward_reloc_rsp(self):
        ies = ordered_dict.OrderedDict()
        ies["GTPIE_CAUSE"] = pack("!B", 128)
        ies["GTPIE_TEI_C"] = pack("!I", 0x1)
        ies["GTPIE_TEI_DII[0]"] = pack("!BI", 5, 0x1)
        ies["GTPIE_GSN_ADDR[0]"] = s_net.ip_str2b("172.1.1.2") # control ip
        ies["GTPIE_GSN_ADDR[1]"] = s_net.ip_str2b("172.1.1.2") # user ip
        return ies

    def echo_req(self):
        ies = ordered_dict.OrderedDict()
        ies["GTPIE_RECOVERY"] = "\x01"
        return ies

    def echo_rsp(self):
        ies = ordered_dict.OrderedDict()
        ies["GTPIE_RECOVERY"] = "\x01"
        return ies

    def set_payload(self, payload):
        self.payload = payload
        self.payload_len = len(payload)

    def to_buffer(self):
        if self.is_long_hdr():
            return pack("!BBHIHBB", self.flags, self.msg_type, self.payload_len + 4, self.teid, self.seq,  self.npdu, self.next_hdr_type) + self.payload 
        return pack("!BBHI", self.flags, self.msg_type, len(self.payload), self.teid) + self.payload 

    def from_buffer(self, buf):
        self.flags = pack_from("B", buf[0:1])
        if self.is_long_hdr():
            self.msg_type = pack_from("B", buf[1:2])
            payload_len = pack_from("!H", buf[2:4]) - 4
            self.teid = pack_from("!I", buf[4:8])
            self.seq = pack_from("!H", buf[8:10])
            self.npdu = pack_from("B", buf[11:12])
            self.next_hdr_type = pack_from("B", buf[12:13])
            self.payload = buf[13:13 + payload_len]
            return self.payload

        self.msg_type = pack_from("B", buf[1:2])
        payload_len = pack_from("!H", buf[2:4]) - 4
        self.teid = pack_from("!I", buf[4:8])
        self.payload = buf[8: 8 + payload_len]
        return self.payload

class S_Gtpiev0:                                                                                                  
    def __init__(self):                                                                                         
        self.GTPIE = {}                                                                                         
        self.GTPIE_OP = {}                                                                                                                                                                                                     
                                                                                                                
        # GTP Information elements from TS 09.60 v6.9.0 7.9 Information Elements                                                                                                       
                                                                                                                
        self.GTPIE[1] = "GTPIE_CAUSE"                   # Cause 1                                               
        self.GTPIE[2] = "GTPIE_IMSI"                    # International Mobile Subscriber Identity 8            
        self.GTPIE[3] = "GTPIE_RAI"                     # Routing Area Identity (RAI) 6                         
        self.GTPIE[4] = "GTPIE_TLLI"                    # Temporary Logical Link Identity (TLLI) 4              
        self.GTPIE[5] = "GTPIE_P_TMSI"                  # Packet TMSI (P-TMSI) 4                                
        self.GTPIE[6] = "GTPIE_QOS_PROFILE"            # Quality of Service Profile GTP version 0 3            
        # 6-7 SPARE                                                                 
        self.GTPIE[8] = "GTPIE_REORDER"                 # Reordering Required 1                                 
        self.GTPIE[9] = "GTPIE_AUTH_TRIPLET"            # Authentication Triplet 28                             
        # 10 SPARE                                                                                              
        self.GTPIE[11] = "GTPIE_MAP_CAUSE"              # MAP Cause 1                                           
        self.GTPIE[12] = "GTPIE_P_TMSI_S"               # P-TMSI Signature 3                                    
        self.GTPIE[13] = "GTPIE_MS_VALIDATED"           # MS Validated 1                                            
        self.GTPIE[14] = "GTPIE_RECOVERY"               # Recovery 1                                                
        self.GTPIE[15] = "GTPIE_SELECTION_MODE"         # Selection Mode 1                                          
        self.GTPIE[16] = "GTPIE_FL_DI"                  # Flow Label Data I 2                                       
        self.GTPIE[17] = "GTPIE_FL_C"                   # Flow Label Signalling 2                                   
        self.GTPIE[18] = "GTPIE_FL_DII"                 # Flow Label Data II 3                      
        self.GTPIE[19] = "GTPIE_MS_NOT_REACH"           # MS Not reachable reason  1                                                                                                                     
        # 20-126 Reserved                                 
        self.GTPIE[127] = "GTPIE_CHARGING_ID"           # Charging ID 4                                             
        self.GTPIE[128] = "GTPIE_EUA"                   # End User Address                                          
        self.GTPIE[129] = "GTPIE_MM_CONTEXT"            # MM Context                                                
        self.GTPIE[130] = "GTPIE_PDP_CONTEXT"           # PDP Context                                               
        self.GTPIE[131] = "GTPIE_APN"                   # Access Point Name                                         
        self.GTPIE[132] = "GTPIE_PCO"                   # Protocol Configuration Options                            
        self.GTPIE[133] = "GTPIE_GSN_ADDR"              # GSN Address                                               
        self.GTPIE[134] = "GTPIE_MSISDN"                # MS International PSTN/ISDN Number                         
        # 135-254 Reserved                              
        self.GTPIE[255] = "GTPIE_PRIVATE"               # Private Extension

        self.GTPIE_ID = {}

        for key in self.GTPIE:
            self.GTPIE_ID[self.GTPIE[key]] = key
        
        # TV GTPIE types with value length 1
        self.GTPIE_OP["GTPIE_CAUSE"] = \
        self.GTPIE_OP["GTPIE_REORDER"] = \
        self.GTPIE_OP["GTPIE_MAP_CAUSE"] = \
        self.GTPIE_OP["GTPIE_MS_VALIDATED"] = \
        self.GTPIE_OP["GTPIE_RECOVERY"] = \
        self.GTPIE_OP["GTPIE_SELECTION_MODE"] = \
        self.GTPIE_OP["GTPIE_MS_NOT_REACH"] = (pack_tv1, unpack_tv1)


        # TV GTPIE types with value length 2
        self.GTPIE_OP["GTPIE_FL_DI"] = \
        self.GTPIE_OP["GTPIE_FL_C"] = (pack_tv2, unpack_tv2)

        # TV GTPIE types with value length 3
        self.GTPIE_OP["GTPIE_QOS_PROFILE"] = \
        self.GTPIE_OP["GTPIE_P_TMSI_S"] = \
        self.GTPIE_OP["GTPIE_FL_DII"] = (pack_tv3, unpack_tv3)

        # TV GTPIE types with value length 4
        self.GTPIE_OP["GTPIE_CHARGING_ID"] = \
        self.GTPIE_OP["GTPIE_TLLI"] = \
        self.GTPIE_OP["GTPIE_P_TMSI"] = (pack_tv4, unpack_tv4)

        # TV GTPIE types with value length 6
        self.GTPIE_OP["GTPIE_RAI"] = (pack_tv6, unpack_tv6)

        # TV GTPIE types with value length 8
        self.GTPIE_OP["GTPIE_IMSI"] = (pack_tv8, unpack_tv8)

        # TV GTPIE types with value length 28
        self.GTPIE_OP["GTPIE_AUTH_TRIPLET"] = (pack_tv28, unpack_tv28)
        
        # TLV GTPIE types with variable length 
        self.GTPIE_OP["GTPIE_EUA"] = \
        self.GTPIE_OP["GTPIE_MM_CONTEXT"] = \
        self.GTPIE_OP["GTPIE_PDP_CONTEXT"] = \
        self.GTPIE_OP["GTPIE_APN"] = \
        self.GTPIE_OP["GTPIE_PCO"] = \
        self.GTPIE_OP["GTPIE_GSN_ADDR"] = \
        self.GTPIE_OP["GTPIE_MSISDN"] = \
        self.GTPIE_OP["GTPIE_PRIVATE"] = (pack_tlv, unpack_tlv)

    def pack(self, t, v):
        if "str" != type(t).__name__:
            print "Please use string as type, not a digital."
            return ""
        return self.GTPIE_OP[t][0](self.GTPIE_ID[t], v)

    def unpack(self, buf):
        t = unpack_from("!B", buf[0:1])[0]
        return self.GTPIE_OP[self.GTPIE[t]][1](buf)

    def unpack_all_ie(self, buf):
        ies = {}
        for i in range(0, len(buf)):
            (t, v, is_tlv) = self.unpack(buf[i:])
            if is_tlv:
                i += len(v) + 3
            else:
                i += len(v) + 1
            ies[t] = v
        return ies

class S_Gtpv0:
    def __init__(self):
        self.MSG_TYPE = {}
        # GTP version 0 message type definitions. 

        # 0 For future use.
        self.MSG_TYPE["GTP_ECHO_REQ"] = 1               # Echo Request
        self.MSG_TYPE["GTP_ECHO_RSP"] = 2               # Echo Response
        self.MSG_TYPE["GTP_NOT_SUPPORTED"] = 3          # Version Not Supported
        # 4-15 For future use.
        self.MSG_TYPE["GTP_CREATE_PDP_REQ"] = 16        # Create PDP Context Request
        self.MSG_TYPE["GTP_CREATE_PDP_RSP"] = 17        # Create PDP Context Response
        self.MSG_TYPE["GTP_UPDATE_PDP_REQ"] = 18        # Update PDP Context Request
        self.MSG_TYPE["GTP_UPDATE_PDP_RSP"] = 19        # Update PDP Context Response
        self.MSG_TYPE["GTP_DELETE_PDP_REQ"] = 20        # Delete PDP Context Request
        self.MSG_TYPE["GTP_DELETE_PDP_RSP"] = 21        # Delete PDP Context Response
        self.MSG_TYPE["GTP_CREATE_AA_PDP_REQ"] = 22        # Create PDP Context Request
        self.MSG_TYPE["GTP_CREATE_AA_PDP_RSP"] = 23        # Create PDP Context Response
        self.MSG_TYPE["GTP_DELETE_AA_PDP_REQ"] = 24        # Delete PDP Context Request
        self.MSG_TYPE["GTP_DELETE_AA_PDP_RSP"] = 25        # Delete PDP Context Response
        self.MSG_TYPE["GTP_ERROR"] = 26                 # Error Indication
        self.MSG_TYPE["GTP_PDU_NOT_REQ"] = 27           # PDU Notification Request
        self.MSG_TYPE["GTP_PDU_NOT_RSP"] = 28           # PDU Notification Response
        self.MSG_TYPE["GTP_PDU_NOT_REJ_REQ"] = 29       # PDU Notification Reject Request
        self.MSG_TYPE["GTP_PDU_NOT_REJ_RSP"] = 30       # PDU Notification Reject Response
        # 31 For future use
        self.MSG_TYPE["GTP_SND_ROUTE_REQ"] = 32         # Send Routeing Information for GPRS Request
        self.MSG_TYPE["GTP_SND_ROUTE_RSP"] = 33         # Send Routeing Information for GPRS Response
        self.MSG_TYPE["GTP_FAILURE_REQ"] = 34           # Failure Report Request
        self.MSG_TYPE["GTP_FAILURE_RSP"] = 35           # Failure Report Response
        self.MSG_TYPE["GTP_MS_PRESENT_REQ"] = 36        # Note MS GPRS Present Request
        self.MSG_TYPE["GTP_MS_PRESENT_RSP"] = 37        # Note MS GPRS Present Response
        # 38-47 For future use.
        self.MSG_TYPE["GTP_IDEN_REQ"] = 48              # Identification Request
        self.MSG_TYPE["GTP_IDEN_RSP"] = 49              # Identification Response
        self.MSG_TYPE["GTP_SGSN_CONTEXT_REQ"] = 50      # SGSN Context Request
        self.MSG_TYPE["GTP_SGSN_CONTEXT_RSP"] = 51      # SGSN Context Response
        self.MSG_TYPE["GTP_SGSN_CONTEXT_ACK"] = 52      # SGSN Context Ack
        # 53-254 For future use.
        self.MSG_TYPE["GTP_GPDU"] = 255         # G-PDU
    
            # 01 bitfield, with typical values
        #    000..... Version: 0
        #    ...1.... Protocol Type: GTP=1, GTP'=0
        #    ....111. Reserved = 7
        #    .......0 Is SNDCP N-PDU included?: no
        self.set_flags(0)
        self.msg_type = \
            self.MSG_TYPE["GTP_CREATE_PDP_REQ"];    # 02 Message type. T-PDU = 0xff
        #self.length = 0;                           # 03 - 04 Length (of IP packet or signalling) 
        self.seq = 0;                               # 05 - 06 Sequence Number 
        self.flabel = 0;                              # 07 - 08 Flow Label
        self.npdu = 0xffff;                           # 09 N-PDU Number 
        self.spare = 0xffff;                          # 10 - 12 Spare
        self.tid_low = 0x05054201;                    # 13 - 20 TID 
        self.tid_high = 0x2151705f;
        self.payload = ""
        
    def set_flags(self, SNN):
        self.flags = 0x1e
        if 1 == SNN:
            self.flags += 1

    def set_seq(self, seq):
        self.seq = seq

    def set_flabel(self, flabel):
        self.flabel = flabel

    def set_npdu(self, npdu):
        self.npdu = npdu

    def set_tid(self, tid):
        self.tid_low = tid >> 32
        self.tid_high = tid & 0xffffffff 

    def set_msg_type(self, msg_type):
        self.msg_type = self.MSG_TYPE[msg_type]

    def get_version(self):
        return 1
       
    def create_pdp_req(self):
        ies = ordered_dict.OrderedDict() 
        ies["GTPIE_QOS_PROFILE"] = "\x09\x11\x01"
        ies["GTPIE_RECOVERY"] = "\x0a"
        ies["GTPIE_SELECTION_MODE"] = "\x00"
        ies["GTPIE_FL_DI"] = pack("!H", 0x1)
        ies["GTPIE_FL_C"] = pack("!H", 0x1)
        ies["GTPIE_EUA"] = "\xf1\x21\x01\x01\x01\x01"
        ies["GTPIE_APN"] = "\x08\x6a\x61\x77\x61\x6c\x6e\x65\x74\x03\x63\x6f\x6d\x04\x73\x61\x30\x30" #"jawalnet.com.sa00" #"auto-ut.gprs.juniper.net"
        ies["GTPIE_GSN_ADDR[0]"] = s_net.ip_str2b("172.1.1.1") # control ip
        ies["GTPIE_GSN_ADDR[1]"] = s_net.ip_str2b("172.1.1.1") # data ip
        ies["GTPIE_MSISDN"] = "\x91\x81\x19\x70\x83\x90\xf9"
        return ies

    def create_pdp_rsp(self):
        ies = ordered_dict.OrderedDict()
        ies["GTPIE_CAUSE"] = pack("!B", 128)
        ies["GTPIE_QOS_PROFILE"] = "\x09\x11\x01"
        ies["GTPIE_REORDER"] = "\xff"
        ies["GTPIE_RECOVERY"] = "\x01"
        ies["GTPIE_FL_DI"] = pack("!H", 0x81)
        ies["GTPIE_FL_C"] = pack("!H", 0x80)
        ies["GTPIE_CHARGING_ID"] = pack("!I", 1)
        ies["GTPIE_EUA"] = "\xf1\x21\x01\x01\x01\x01"
        ies["GTPIE_GSN_ADDR[0]"] = s_net.ip_str2b("172.16.1.1")
        ies["GTPIE_GSN_ADDR[1]"] = s_net.ip_str2b("172.16.1.1")
        return ies

    def update_pdp_req(self):
        ies = ordered_dict.OrderedDict()
        ies["GTPIE_QOS_PROFILE"] = "\x09\x11\x01"
        ies["GTPIE_RECOVERY"] = "\x01"
        ies["GTPIE_FL_DI"] = pack("!H", 0x2)
        ies["GTPIE_FL_C"] = pack("!H", 0x1)
        ies["GTPIE_GSN_ADDR[0]"] = s_net.ip_str2b("172.1.1.2") # control ip
        ies["GTPIE_GSN_ADDR[1]"] = s_net.ip_str2b("172.1.1.2") # data ip
        return ies 

    def update_pdp_rsp(self):
        ies = ordered_dict.OrderedDict()
        ies["GTPIE_CAUSE"] = pack("!B", 128)
        ies["GTPIE_QOS_PROFILE"] = "\x09\x11\x01"
        ies["GTPIE_RECOVERY"] = "\x01"
        ies["GTPIE_FL_DI"] = pack("!H", 0x81)
        ies["GTPIE_FL_C"] = pack("!H", 0x80)
        ies["GTPIE_CHARGING_ID"] = pack("!I", 1)
        ies["GTPIE_GSN_ADDR[0]"] = s_net.ip_str2b("172.16.1.1") # control ip
        ies["GTPIE_GSN_ADDR[1]"] = s_net.ip_str2b("172.16.1.1") # data ip
        return ies

    def delete_pdp_req(self):
        ies = ordered_dict.OrderedDict()
        return ies  
        
    def delete_pdp_rsp(self):
        ies = ordered_dict.OrderedDict()
        ies["GTPIE_CAUSE"] = pack("!B", 128)
        return ies

    def sgsn_context_req(self):
        ies = ordered_dict.OrderedDict()
        ies["GTPIE_RAI"] = "\x03\x02\x15\x27\x10\x0a"
        ies["GTPIE_TLLI"] = "\xcf\x10\x1c\x0e"
        ies["GTPIE_P_TMSI_S"] = "\xa6\x4a\x25"
        ies["GTPIE_MS_VALIDATED"] = pack("!B", 0xfe)
        ies["GTPIE_FL_C"] = pack("!H", 0x0001) # new sgsn control flow label
        return ies

    def sgsn_context_rsp(self):
        ies = ordered_dict.OrderedDict()
        ies["GTPIE_CAUSE"] = pack("!B", 128)
        ies["GTPIE_IMSI"] = "\x05\x05\x42\x01\x21\x51\x70\x0f" 
        ies["GTPIE_FL_C"] = pack("!H", 0x0001)
        ies["GTPIE_MM_CONTEXT"] = ""
        return ies

    def sgsn_context_ack(self, pdp_num = 1):
        ies = ordered_dict.OrderedDict()
        ies["GTPIE_CAUSE"] = pack("!B", 128)
        for i in range(0, pdp_num):
            key = "GTPIE_FL_DII[%d]"%i
            ies[key] = pack("!H", 0x0001) # new sgsn user flow label
        ies["GTPIE_GSN_ADDR"] = s_net.ip_str2b("172.1.1.2") # new sgsn user ip
        return ies

    def echo_req(self):
        ies = ordered_dict.OrderedDict()
        return ies
    
    def echo_rsp(self):
        ies = ordered_dict.OrderedDict()
        ies["GTPIE_RECOVERY"] = "\x01"
        return ies

    def set_payload(self, payload):
        self.payload = payload
        self.payload_len = len(payload)

    def to_buffer(self):
        return pack("!BBHHHHHII", self.flags, self.msg_type, len(self.payload), self.seq, self.flabel, self.npdu, self.spare, self.tid_low, self.tid_high) + self.payload

    def from_buffer(self, buf):
        self.flags = pack_from("B", buf[0:1])
        self.msg_type = pack_from("B", buf[1:2])
        payload_len = pack_from("!H", buf[2:4]) - 4
        self.tid = pack_from("!I", buf[13:20])
        self.payload = buf[20: 20 + payload_len]
        return self.payload

class S_Gtpv1pdp:
    def __init__(self):
        self.nsapi = 5;
        self.sapi  = 3;
        self.qos_sub = "";
        self.qos_req = "";
        self.qos_neg = "";
        self.seq_down = 0;
        self.seq_up = 0;
        self.send_pdu_num = 255;
        self.recv_pdu_num = 255;
        self.up_teic = 0x72003dc2;
        self.up_teiu = 0x84203d50;
        self.pdp_id = 5;
        self.pdp_org = 0xf1;
        self.pdp_type = 0x21;
        self.pdp_addr = "10.208.21.48";
        self.ggsn_c = "96.23.3.197";
        self.ggsn_u = "96.23.3.197";
        self.apn = "apn.test1.mnc510.mcc302.gprs";
        self.sgsn_o = "96.23.3.4"
        self.content = ""
        
    def set_nsapi(self, nsapi):
        self.nsapi = nsapi
        
    def set_sapi(self, sapi):
        self.sapi = sapi
        
    def set_seq(self, seq_down, seq_up):
        self.seq_down = seq_down
        self.seq_up = seq_up
        
    def set_pdu_num(self, send, recv):
        self.send_pdu_num = send
        self.recv_pdu_num = recv
        
    def set_teic(self, teic):
        self.up_teic = teic
    
    def set_teiu(self, teiu):
        self.up_teiu = teiu

    def set_pdp_id(self, pdp_id):
        self.pdp_id = pdp_id

    def set_pdp_org(self, pdp_org):
        self.pdp_org = pdp_org

    def set_pdp_type(self, pdp_type):
        self.pdp_type = pdp_type

    def set_pdp_addr(self, pdp_addr):
        self.pdp_addr = pdp_addr

    def set_ggsnc(self, ggsnc):
        self.ggsn_c = ggsnc

    def set_ggsnu(self, ggsnu):
        self.ggsn_u = ggsnu

    def set_apn(self, apn):
        self.apn = apn

    def set_sgsn_o(self, sgsn_o):
        self.sgsn_o = sgsn_o

    def set_content(self, content):
        self.content = content
        self.content_len = len(content)

    def to_buffer(self):
        return pack("!BB", self.nsapi, self.sapi) + pack_lv(self.qos_sub) + pack_lv(self.qos_req) + pack_lv(self.qos_neg) +\
               pack("!HHBBIIBBB", self.seq_down, self.seq_up, self.send_pdu_num, self.recv_pdu_num, self.up_teic, \
                self.up_teiu, self.pdp_id, self.pdp_org, self.pdp_type) + pack_lv(s_net.ip_str2b(self.pdp_addr)) +\
               pack_lv(s_net.ip_str2b(self.ggsn_c)) + pack_lv(s_net.ip_str2b(self.ggsn_u)) + pack_lv(self.apn) + pack_lv(s_net.ip_str2b(self.sgsn_o))

class S_Gtpv0pdp:
    def __init__(self):
        self.nsapi = 5;
        self.sapi  = 3;
        self.qos_sub = "\x01\x02\x03";
        self.qos_req = "\x01\x02\x03";
        self.qos_neg = "\x01\x02\x03";
        self.seq_down = 0;
        self.seq_up = 0;
        self.send_pdu_num = 255;
        self.recv_pdu_num = 255;
        self.up_flc = 0x3dc2;
        self.pdp_org = 0xf1;
        self.pdp_type = 0x21;
        self.pdp_addr = "10.208.21.48";
        self.ggsn_c = "96.23.3.197";
        self.apn = "apn.test1.mnc510.mcc302.gprs";
        self.content = ""

    def set_nsapi(self, nsapi):
        self.nsapi = nsapi

    def set_sapi(self, sapi):
        self.sapi = sapi

    def set_seq(self, seq_down, seq_up):
        self.seq_down = seq_down
        self.seq_up = seq_up
        
    def set_pdu_num(self, send, recv):
        self.send_pdu_num = send
        self.recv_pdu_num = recv

    def set_up_flc(self, up_flc):
        self.up_flc = up_flc

    def set_pdp_org(self, pdp_org):
        self.pdp_org = pdp_org

    def set_pdp_type(self, pdp_type):
        self.pdp_type = pdp_type

    def set_pdp_addr(self, pdp_addr):
        self.pdp_addr = pdp_addr

    def set_ggsnc(self, ggsnc):
        self.ggsn_c = ggsnc

    def set_apn(self, apn):
        self.apn = apn
        
    def set_content(self, content):
        self.content = content
        self.content_len = len(content)

    def to_buffer(self):
        return pack("!BB", self.nsapi, self.sapi) + pack_v(self.qos_sub) + pack_v(self.qos_req) + pack_v(self.qos_neg) +\
               pack("!HHBBHBB", self.seq_down, self.seq_up, self.send_pdu_num, self.recv_pdu_num, self.up_flc, \
                self.pdp_org, self.pdp_type) + pack_lv(s_net.ip_str2b(self.pdp_addr)) +\
               pack_lv(s_net.ip_str2b(self.ggsn_c)) + pack_lv(self.apn)


#-----------------------TLIV----------------------------------------
#  0                   1                   2                   3
#  0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
#  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
#  |      Type     |              Length           | Spare | Instan|
#  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
#  |                      Value                                    |
#  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+ 
def pack_tliv(m_type, m_ins, m_value):
    fmt = "!BHB%ds"%len(m_value)
                     # type  len          instance  value
    return pack(fmt, m_type, len(m_value), m_ins, m_value)

def pack_tl0v(m_type, m_value):
    return pack_tliv(m_type, 0, m_value)

def pack_tl1v(m_type, m_value):
    return pack_tliv(m_type, 1, m_value)

def pack_tl2v(m_type, m_value):
    return pack_tliv(m_type, 2, m_value)

def pack_tl3v(m_type, m_value):
    return pack_tliv(m_type, 3, m_value)

def pack_tl4v(m_type, m_value):
    return pack_tliv(m_type, 4, m_value)

def pack_tl5v(m_type, m_value):
    return pack_tliv(m_type, 5, m_value)

def pack_tl6v(m_type, m_value):
    return pack_tliv(m_type, 6, m_value)
    
def pack_tl7v(m_type, m_value):
    return pack_tliv(m_type, 7, m_value)

def unpack_tliv(buf):
    t = unpack_from("!B", buf[0:1])[0]
    l = unpack_from("!H", buf[1:3])[0]
    i = unpack_from("!B", buf[3:4])[0]
    v = buf[4:l + 4]
    return (t, i, v, IS_TLV)

# GTPv2 interface type
S1_END_U           = 0    #S1-U eNodeB GTP-U interface
S1_SGW_U           = 1    #S1-U SGW GTP-U interface
S12_RNC_U          = 2    #S12 RNC GTP-U interface
S12_SGW_U          = 3    #S12 SGW GTP-U interface
S58_SGW_U          = 4    #S5/S8 SGW GTP-U interface
S58_PGW_U          = 5    #S5/S8 PGW GTP-U interface
S58_SGW_C          = 6    #S5/S8 SGW GTP-C interface
S58_PGW_C          = 7    #S5/S8 PGW GTP-C interface
S58_SGW_PMIPV6     = 8    #S5/S8 SGW PMIPv6 interface (the 32 bit GRE key is encoded in 32 bit TEID field 
                          #and since alternate CoA is not used the control plane and user plane addresses are the same for PMIPv6)
S58_PGW_PMIPV6     = 9    #S5/S8 PGW PMIPv6 interface (the 32 bit GRE key is encoded in 32 bit TEID field 
                          #and the control plane and user plane addresses are the same for PMIPv6)
S11_MME_C          = 10   #S11 MME GTP-C interface
S11_SGW_C          = 11   #S11/S4 SGW GTP-C interface
S4_SGW_C           = 11
S10_MME_C          = 12   #S10 MME GTP-C interface
S3_MME_C           = 13   #S3 MME GTP-C interface
S3_SGSN_C          = 14   #S3 SGSN GTP-C interface
S4_SGSN_U          = 15   #S4 SGSN GTP-U interface
S4_SGW_U           = 16   #S4 SGW GTP-U interface
S4_SGSN_C          = 17   #S4 SGSN GTP-C interface
S16_SGSN_C         = 18   #S16 SGSN GTP-C interface
END_U_DL_FWD       = 19   #eNodeB GTP-U interface for DL data forwarding
END_U_UL_FWD       = 20   #eNodeB GTP-U interface for UL data forwarding
RNC_U_FWD          = 21   #RNC GTP-U interface for data forwarding
SGSN_U_FWD         = 22   #SGSN GTP-U interface for data forwarding
SGW_U_FWD          = 23   #SGW GTP-U interface for data forwarding

class S_Gtpiev2:
    def __init__(self):
        self.GTPIE = {}
        self.GTPIE_OP = {}

        # GTP Information elements from 29.274 v8.2.0 Information Elements
    
        self.GTPIE[1] = "GTPIE_IMSI"                    # International Mobile Subscriber Identity 8
        self.GTPIE[2] = "GTPIE_CAUSE"                   # Cause 1
        self.GTPIE[3] = "GTPIE_RECOVERY"                # Recovery 1
        # 4-50  Reserved for S101 interface
        # 51-70 Reserved for Sv interface
        self.GTPIE[71] = "GTPIE_APN"                    # Access Point Name
        self.GTPIE[72] = "GTPIE_AMBR"                   # Aggregate Maximum Bit Rate
        self.GTPIE[73] = "GTPIE_EBI"                    # EPS Bearer ID
        self.GTPIE[74] = "GTPIE_IPA"                    # IP Address
        self.GTPIE[75] = "GTPIE_MEI"                    # Mobile Equipment Identity
        self.GTPIE[76] = "GTPIE_MSISDN"                 # MS International PSTN/ISDN Number
        self.GTPIE[77] = "GTPIE_INDICAT"                # Indication
        self.GTPIE[78] = "GTPIE_PCO"                    # Protocol Configuration Options
        self.GTPIE[79] = "GTPIE_PAA"                    # PDN Address Allocation
        self.GTPIE[80] = "GTPIE_BEAR_QOS"               # Bearer Level Quality of Service (Bearer QoS)                  
        self.GTPIE[81] = "GTPIE_FLOW_QOS"               # Flow Quality of Service (Flow QoS)                            
        self.GTPIE[82] = "GTPIE_RAT_TYPE"               # RAT Type                                                      
        self.GTPIE[83] = "GTPIE_SERV_NET"               # Serving Network                                               
        self.GTPIE[84] = "GTPIE_BEAR_TFT"               # EPS Bearer Level Traffic Flow Template (Bearer TFT)           
        self.GTPIE[85] = "GTPIE_TAD"                    # Traffic Aggregation Description (TAD)                         
        self.GTPIE[86] = "GTPIE_ULI"                    # User Location Information (ULI)                               
        self.GTPIE[87] = "GTPIE_F_TEID"                 # Fully Qualified Tunnel Endpoint Identifier (F-TEID)           
        self.GTPIE[88] = "GTPIE_TMSI"                   # TMSI                                                          
        self.GTPIE[89] = "GTPIE_GLO_CN"                 # Global CN-Id                                                  
        self.GTPIE[90] = "GTPIE_S103PDF"                # S103 PDN Data Forwarding Info (S103PDF)                       
        self.GTPIE[91] = "GTPIE_S1UDF"                  # S1-U Data Forwarding Info (S1UDF)                             
        self.GTPIE[92] = "GTPIE_DELAY"                  # Delay Value                                                   
        self.GTPIE[93] = "GTPIE_BEAR_CTXT"              # Bearer Context                                                
        self.GTPIE[94] = "GTPIE_CHARGING_ID"            # Charging ID                                                   
        self.GTPIE[95] = "GTPIE_CHARGING_C"             # Charging Characteristics                                      
        self.GTPIE[96] = "GTPIE_TRACE_INFO"             # Trace Information                                             
        self.GTPIE[97] = "GTPIE_BEAR_FLAG"              # Bearer Flags                                                  
        self.GTPIE[98] = "GTPIE_PAGING_CAUSE"           # Paging Cause                                                  
        self.GTPIE[99] = "GTPIE_PDN_TYPE"               # PDN Type                                                      
        self.GTPIE[100] = "GTPIE_PTI"                   # Procedure Transaction ID                                      
        self.GTPIE[101] = "GTPIE_DRX_PARA"              # DRX Parameter                                                 
        self.GTPIE[102] = "GTPIE_UE_CAPABILITY"         # UE Network Capability                                         
        self.GTPIE[103] = "GTPIE_MM_CONTEXT_1N"          # MM Context (GSM Key and Triplets)                             
        self.GTPIE[104] = "GTPIE_MM_CONTEXT_2N"          # MM Context (UMTS Key, Used Cipher and Quintuplets)            
        self.GTPIE[105] = "GTPIE_MM_CONTEXT_3N"          # MM Context (GSM Key, Used Cipher and Quintuplets)             
        self.GTPIE[106] = "GTPIE_MM_CONTEXT_4N"          # MM Context (UMTS Key and Quintuplets)                         
        self.GTPIE[107] = "GTPIE_MM_CONTEXT_5N"          # MM Context (EPS Security Context, Quadruplets and Quintuplets)
        self.GTPIE[108] = "GTPIE_MM_CONTEXT_6N"          # MM Context (UMTS Key, Quadruplets and Quintuplets)            
        self.GTPIE[109] = "GTPIE_PDN_CONN"              # PDN Connection                                                
        self.GTPIE[110] = "GTPIE_PDN_NUM"               # PDU Numbers                                                   
        self.GTPIE[111] = "GTPIE_P_TMSI"                # P-TMSI                                                        
        self.GTPIE[112] = "GTPIE_P_TMSI_S"              # P-TMSI Signature                                              
        self.GTPIE[113] = "GTPIE_HOP_CNT"               # Hop Counter                                                   
        self.GTPIE[114] = "GTPIE_UE_TIME_ZONE"          # UE Time Zone                                                  
        self.GTPIE[115] = "GTPIE_TRACE_REF"             # Trace Reference                                               
        self.GTPIE[116] = "GTPIE_COMPL_REQ"             # Complete Request Message                                      
        self.GTPIE[117] = "GTPIE_GUTI"                  # GUTI                                                          
        self.GTPIE[118] = "GTPIE_F_CONT"                # F-Container                                                   
        self.GTPIE[119] = "GTPIE_F_CAUSE"               # F-Cause                                                       
        self.GTPIE[120] = "GTPIE_SELECT_PLMN"           # Selected PLMN ID                                              
        self.GTPIE[121] = "GTPIE_TARGET_ID"             # Target Identification                                         
        self.GTPIE[122] = "GTPIE_NSAPI"                 # NSAPI                                                         
        self.GTPIE[123] = "GTPIE_PFI"                   # Packet Flow ID                                                
        self.GTPIE[124] = "GTPIE_RAB_CONTEXT"           # RAB Context                                                   
        self.GTPIE[125] = "GTPIE_SRC_RNC_CTEXT"         # Source RNC PDCP Context Info                                  
        self.GTPIE[126] = "GTPIE_UDP_SRC_PORT"          # UDP Source Port Number                                        
        self.GTPIE[127] = "GTPIE_APN_RESTR"             # APN Restriction                                               
        self.GTPIE[128] = "GTPIE_SELECTION_MODE"        # Selection Mode                                                
        self.GTPIE[129] = "GTPIE_SRC_ID"                # Source Identification                                         
        self.GTPIE[130] = "GTPIE_BEAR_CTRL_MODE"        # Bearer Control Mode                                           
        self.GTPIE[131] = "GTPIE_CHANGE_REPORT_ACT"     # Change Reporting Action                                       
        self.GTPIE[132] = "GTPIE_FQ_CSID"               # Fully Qualified PDN Connection Set Identifier (FQ-CSID)       
        self.GTPIE[133] = "GTPIE_CHANNEL_NEED"          # Channel needed                                                
        self.GTPIE[134] = "GTPIE_EMLPP_PRIO"            # eMLPP Priority                    
        self.GTPIE[135] = "GTPIE_NODE_TYPE"             # Node Type                         
        self.GTPIE[136] = "GTPIE_FQDN"                  # Fully Qualified Domain Name (FQDN)
        self.GTPIE[137] = "GTPIE_TI"                    # Transaction Identifier (TI)       
        # 138-254 For future use
        self.GTPIE[255] = "GTPIE_PRIVATE"               # Private Extension

        self.GTPIE_ID= {}

        for key in self.GTPIE:
            self.GTPIE_ID[self.GTPIE[key]] = key

        self.GTPIE_ID["GTPIE_F_TEID_1_INS"] = \
        self.GTPIE_ID["GTPIE_F_TEID_2_INS"] = \
        self.GTPIE_ID["GTPIE_F_TEID_3_INS"] = \
        self.GTPIE_ID["GTPIE_F_TEID_4_INS"] = \
        self.GTPIE_ID["GTPIE_F_TEID_5_INS"] = \
        self.GTPIE_ID["GTPIE_F_TEID_6_INS"] = \
        self.GTPIE_ID["GTPIE_F_TEID_7_INS"] = self.GTPIE_ID["GTPIE_F_TEID"]

        self.GTPIE_ID["GTPIE_BEAR_CTXT_1_INS"] = \
        self.GTPIE_ID["GTPIE_BEAR_CTXT_2_INS"] = self.GTPIE_ID["GTPIE_BEAR_CTXT"]

        self.GTPIE_ID["GTPIE_FQ_CSID_1_INS"] = \
        self.GTPIE_ID["GTPIE_FQ_CSID_2_INS"] = self.GTPIE_ID["GTPIE_FQ_CSID"]

        self.GTPIE_ID["GTPIE_F_CONT_1_INS"] = \
        self.GTPIE_ID["GTPIE_F_CONT_2_INS"] = self.GTPIE_ID["GTPIE_F_CONT"]

        self.GTPIE_ID["GTPIE_F_CAUSE_1_INS"] = \
        self.GTPIE_ID["GTPIE_F_CAUSE_2_INS"] = self.GTPIE_ID["GTPIE_F_CAUSE"]

        self.GTPIE_ID["GTPIE_EBI_1_INS"] = self.GTPIE_ID["GTPIE_EBI"]
        self.GTPIE_ID["GTPIE_IPA_1_INS"] = self.GTPIE_ID["GTPIE_IPA"]

        # TLIV GTPIE types 
        self.GTPIE_OP["GTPIE_IMSI"] = \
        self.GTPIE_OP["GTPIE_CAUSE"] = \
        self.GTPIE_OP["GTPIE_RECOVERY"] = \
        self.GTPIE_OP["GTPIE_APN"] = \
        self.GTPIE_OP["GTPIE_AMBR"] = \
        self.GTPIE_OP["GTPIE_EBI"] = \
        self.GTPIE_OP["GTPIE_IPA"] = \
        self.GTPIE_OP["GTPIE_MEI"] = \
        self.GTPIE_OP["GTPIE_MSISDN"] = \
        self.GTPIE_OP["GTPIE_INDICAT"] = \
        self.GTPIE_OP["GTPIE_ULI"] = \
        self.GTPIE_OP["GTPIE_F_TEID"] = \
        self.GTPIE_OP["GTPIE_PCO"] = \
        self.GTPIE_OP["GTPIE_RAT_TYPE"] = \
        self.GTPIE_OP["GTPIE_SERV_NET"] = \
        self.GTPIE_OP["GTPIE_BEAR_TFT"] = \
        self.GTPIE_OP["GTPIE_TAD"] = \
        self.GTPIE_OP["GTPIE_TMSI"] = \
        self.GTPIE_OP["GTPIE_GLO_CN"] = \
        self.GTPIE_OP["GTPIE_DELAY"] = \
        self.GTPIE_OP["GTPIE_CHARGING_ID"] = \
        self.GTPIE_OP["GTPIE_CHARGING_C"] = \
        self.GTPIE_OP["GTPIE_BEAR_FLAG"] = \
        self.GTPIE_OP["GTPIE_PAGING_CAUSE"] = \
        self.GTPIE_OP["GTPIE_PDN_TYPE"] = \
        self.GTPIE_OP["GTPIE_PTI"] = \
        self.GTPIE_OP["GTPIE_DRX_PARA"] = \
        self.GTPIE_OP["GTPIE_UE_CAPABILITY"] = \
        self.GTPIE_OP["GTPIE_P_TMSI"] = \
        self.GTPIE_OP["GTPIE_P_TMSI_S"] = \
        self.GTPIE_OP["GTPIE_HOP_CNT"] = \
        self.GTPIE_OP["GTPIE_F_CONT"] = \
        self.GTPIE_OP["GTPIE_F_CAUSE"] = \
        self.GTPIE_OP["GTPIE_SELECT_PLMN"] = \
        self.GTPIE_OP["GTPIE_NSAPI"] = \
        self.GTPIE_OP["GTPIE_RAB_CONTEXT"] = \
        self.GTPIE_OP["GTPIE_SRC_RNC_CTEXT"] = \
        self.GTPIE_OP["GTPIE_UDP_SRC_PORT"] = \
        self.GTPIE_OP["GTPIE_APN_RESTR"] = \
        self.GTPIE_OP["GTPIE_SELECTION_MODE"] = \
        self.GTPIE_OP["GTPIE_BEAR_CTRL_MODE"] = \
        self.GTPIE_OP["GTPIE_CHANGE_REPORT_ACT"] = \
        self.GTPIE_OP["GTPIE_CHANNEL_NEED"] = \
        self.GTPIE_OP["GTPIE_EMLPP_PRIO"] = \
        self.GTPIE_OP["GTPIE_NODE_TYPE"] = \
        self.GTPIE_OP["GTPIE_FQDN"] = \
        self.GTPIE_OP["GTPIE_TI"] = \
        self.GTPIE_OP["GTPIE_PRIVATE"] = \
        self.GTPIE_OP["GTPIE_PAA"] = \
        self.GTPIE_OP["GTPIE_BEAR_QOS"] = \
        self.GTPIE_OP["GTPIE_BEAR_CTXT"] = \
        self.GTPIE_OP["GTPIE_FLOW_QOS"    ] = \
        self.GTPIE_OP["GTPIE_S103PDF"     ] = \
        self.GTPIE_OP["GTPIE_S1UDF"       ] = \
        self.GTPIE_OP["GTPIE_TRACE_INFO"  ] = \
        self.GTPIE_OP["GTPIE_MM_CONTEXT_1N"] = \
        self.GTPIE_OP["GTPIE_MM_CONTEXT_2N"] = \
        self.GTPIE_OP["GTPIE_MM_CONTEXT_3N"] = \
        self.GTPIE_OP["GTPIE_MM_CONTEXT_4N"] = \
        self.GTPIE_OP["GTPIE_MM_CONTEXT_5N"] = \
        self.GTPIE_OP["GTPIE_MM_CONTEXT_6N"] = \
        self.GTPIE_OP["GTPIE_PDN_CONN"    ] = \
        self.GTPIE_OP["GTPIE_PDN_NUM"     ] = \
        self.GTPIE_OP["GTPIE_UE_TIME_ZONE"] = \
        self.GTPIE_OP["GTPIE_TRACE_REF"   ] = \
        self.GTPIE_OP["GTPIE_COMPL_REQ"   ] = \
        self.GTPIE_OP["GTPIE_GUTI"        ] = \
        self.GTPIE_OP["GTPIE_TARGET_ID"   ] = \
        self.GTPIE_OP["GTPIE_PFI"         ] = \
        self.GTPIE_OP["GTPIE_SRC_ID"      ] = \
        self.GTPIE_OP["GTPIE_FQ_CSID"     ] = (pack_tl0v, unpack_tliv)

        self.GTPIE_OP["GTPIE_F_TEID_1_INS"] = \
        self.GTPIE_OP["GTPIE_BEAR_CTXT_1_INS"] = \
        self.GTPIE_OP["GTPIE_FQ_CSID_1_INS"] = \
        self.GTPIE_OP["GTPIE_EBI_1_INS"] = \
        self.GTPIE_OP["GTPIE_F_CONT_1_INS"] = \
        self.GTPIE_OP["GTPIE_F_CAUSE_1_INS"] = \
        self.GTPIE_OP["GTPIE_IPA_1_INS"] = (pack_tl1v, unpack_tliv)
        
        self.GTPIE_OP["GTPIE_F_TEID_2_INS"] = \
        self.GTPIE_OP["GTPIE_BEAR_CTXT_2_INS"] = \
        self.GTPIE_OP["GTPIE_FQ_CSID_2_INS"] = \
        self.GTPIE_OP["GTPIE_F_CONT_2_INS"] = \
        self.GTPIE_OP["GTPIE_F_CAUSE_2_INS"] = (pack_tl2v, unpack_tliv)
        
        self.GTPIE_OP["GTPIE_F_TEID_3_INS"] = (pack_tl3v, unpack_tliv)
        self.GTPIE_OP["GTPIE_F_TEID_4_INS"] = (pack_tl4v, unpack_tliv)
        self.GTPIE_OP["GTPIE_F_TEID_5_INS"] = (pack_tl5v, unpack_tliv)
        self.GTPIE_OP["GTPIE_F_TEID_6_INS"] = (pack_tl6v, unpack_tliv)
        self.GTPIE_OP["GTPIE_F_TEID_7_INS"] = (pack_tl7v, unpack_tliv)
    
    def pack_f_teid_v4(self, if_type, teid, ip_addr):   
        f_type = 128 + if_type
        return pack("!BII", f_type, teid, ip_addr)
    
    def pack_paa(self, ip_addr):
        ip_type = 0x1
        return pack("!BI", ip_type, ip_addr)

    def pack_bearer_ctxt(self, cause, ebi, f_teid0 = 0, f_teid1 = 0, f_teid2 = 0, f_teid3 = 0, f_teid4 = 0, f_teid5 = 0, f_teid6 = 0, f_teid7 = 0):
        ies = ""
        ies += self.pack("GTPIE_EBI", pack("!B", ebi))
        if cause:
            ies += self.pack("GTPIE_CAUSE", pack("!B", cause))
        ie_qos = "\x04\x01\x00\x00\x00\x00\x01\x00\x00\x00\x00\x01\x00\x00\x00\x00\x01\x00\x00\x00\x00\x01"
        ies += self.pack("GTPIE_BEAR_QOS", ie_qos)
        ie_tft = "\x23\x20\xff\x00\x21\xff\x00\x22\xff\x00"
        ies += self.pack("GTPIE_BEAR_TFT", ie_tft)
        if f_teid0:
            ies += self.pack("GTPIE_F_TEID", f_teid0)
        if f_teid1:
            ies += self.pack("GTPIE_F_TEID_1_INS", f_teid1)
        if f_teid2:
            ies += self.pack("GTPIE_F_TEID_2_INS", f_teid2)
        if f_teid3:
            ies += self.pack("GTPIE_F_TEID_3_INS", f_teid3)
        if f_teid4:
            ies += self.pack("GTPIE_F_TEID_4_INS", f_teid4)
        if f_teid5:
            ies += self.pack("GTPIE_F_TEID_5_INS", f_teid5)
        if f_teid6:
            ies += self.pack("GTPIE_F_TEID_6_INS", f_teid6)
        if f_teid7:
            ies += self.pack("GTPIE_F_TEID_7_INS", f_teid7)
        return ies
    
    def pack_bearer_del(self, ebi, cause = 0):
        ies = ""
        ies += self.pack("GTPIE_EBI", pack("!B", ebi))
        if cause:
            ies += self.pack("GTPIE_CAUSE", pack("!B", cause))
        return ies

    def pack_pdn_conn(self, msg):
        ies = ""
        if 'apn' in msg:
            apn = msg['apn']
        else:
            apn = "auto-ut.gprs.juniper.net"
        if 'euip_v4' in msg:
            ip_addr = int(ipaddr.IPAddress(msg['euip_v4']))
        else:
            ip_addr = int(ipaddr.IPAddress('1.1.1.1'))
        if 'lbi' in msg:
            lbi = msg['lbi']
        else:
            lbi = 5
        if 'fteid_pgw' in msg:
            fteid_pgw = msg['fteid_pgw']
        bear_ctxt = {}
        if 'bear_cnt' in msg:
            bear_cnt = msg['bear_cnt']
            bear_ctxt = msg['bear_ctxt']
        else:
            bear_ctxt[0] = self.pack_bearer_ctxt(0, 5, self.pack_f_teid_v4(S4_SGW_U, 0x1, int(ipaddr.IPAddress("2.0.0.5"))))

        if 'ambr' in msg:
            ambr = msg['ambr']
        else:
            ambr = "\x00\x00\x12\x34\x00\x00\x56\x78"
        ies += self.pack("GTPIE_APN", pack("!B%ds"%len(apn), len(apn), apn))
        ies += self.pack("GTPIE_IPA", pack("!I", ip_addr))
        ies += self.pack("GTPIE_EBI", pack("!B", lbi))
        ies += self.pack("GTPIE_F_TEID", fteid_pgw)
        for i in range(0, bear_cnt):
            ies += self.pack("GTPIE_BEAR_CTXT", bear_ctxt[i])
        ies += self.pack("GTPIE_AMBR", ambr)
        return ies

    def pack(self, t, v):
        if "str" != type(t).__name__:
            print "Please use string as type, not a digital."
            return ""
        return self.GTPIE_OP[t][0](self.GTPIE_ID[t], v)

    def unpack(self, buf):
        t = unpack_from("!B", buf[0:1])[0]
        return self.GTPIE_OP[self.GTPIE[t]][1](buf)

    def unpack_all_ie(self, buf):
        ies = {}
        for i in range(0, len(buf)):
            (t, v, is_tlv) = self.unpack(buf[i:])
            if is_tlv:
                i += len(v) + 3
            else:
                i += len(v) + 1
            ies[t] = v
        return ies

class S_Gtpv2:
    def __init__(self):
        self.MSG_TYPE = {}
        # GTP version 2 message type definitions. 
        
        # 0 For future use.
        self.MSG_TYPE["GTP_ECHO_REQ"] = 1               # Echo Request
        self.MSG_TYPE["GTP_ECHO_RSP"] = 2               # Echo Response
        self.MSG_TYPE["GTP_NOT_SUPPORTED"] = 3          # Version Not Supported
        # 4-24 For S101 interface  TS 29.276.
        # 25-31 For Sv interface  TS 29.280
        # 32-37 SGSN/MME to PGW (S4/S11, S5/S8)
        self.MSG_TYPE["GTP_CREATE_SESS_REQ"] = 32        # Create Session Request
        self.MSG_TYPE["GTP_CREATE_SESS_RSP"] = 33        # Create Session Response
        self.MSG_TYPE["GTP_MODIFY_BEAR_REQ"] = 34        # Modify Bearer Request
        self.MSG_TYPE["GTP_MODIFY_BEAR_RSP"] = 35        # Modify Bearer Response
        self.MSG_TYPE["GTP_DELETE_SESS_REQ"] = 36        # Delete Session Request
        self.MSG_TYPE["GTP_DELETE_SESS_RSP"] = 37        # Delete Session Response
        # 38-39 SGSN to PGW (S4, S5/S8)
        self.MSG_TYPE["GTP_CHGE_NOTIF_REQ"] = 38         # Change Notification Request
        self.MSG_TYPE["GTP_CHGE_NOTIF_RSP"] = 39         # Change Notification Response
        # 40-63 For future use. 
        # 64-73 Messages without explicit response
        self.MSG_TYPE["GTP_MODIFY_BEAR_CMD"] = 64        # Modify Bearer Command
        self.MSG_TYPE["GTP_MODIFY_BEAR_FAIL"] = 65       # Modify Bearer Failure Indication
        self.MSG_TYPE["GTP_DELETE_BEAR_CMD"] = 66        # Delete Bearer Command
        self.MSG_TYPE["GTP_DELETE_BEAR_FAIL"] = 67       # Delete Bearer Failure Indication
        self.MSG_TYPE["GTP_BEAR_RES_CMD"] = 68           # Bearer Resource Command
        self.MSG_TYPE["GTP_BEAR_RES_FAIL"] = 69          # Bearer Resource Failure Indication
        self.MSG_TYPE["GTP_DL_DATA_NOTIF_FAIL"] = 70     # Downlink Data Notification Failure Indication
        self.MSG_TYPE["GTP_TRACE_SESS_ACTV"] = 71        # Trace Session Activation
        self.MSG_TYPE["GTP_TRACE_SESS_DEACTV"] = 72      # Trace Session Deactivation
        self.MSG_TYPE["GTP_STOP_PAGEING"] = 73           # Stop Paging Indication
        # 74-94 For future use.
        # 95-100 PGW to SGSN/MME (S5/S8, S4/S11)
        self.MSG_TYPE["GTP_CREATE_BEAR_REQ"] = 95        # Create Bearer Request
        self.MSG_TYPE["GTP_CREATE_BEAR_RSP"] = 96        # Create Bearer Response
        self.MSG_TYPE["GTP_UPDATE_BEAR_REQ"] = 97        # Update Bearer Request
        self.MSG_TYPE["GTP_UPDATE_BEAR_RSP"] = 98        # Update Bearer Response
        self.MSG_TYPE["GTP_DELETE_BEAR_REQ"] = 99        # Delete Bearer Request
        self.MSG_TYPE["GTP_DELETE_BEAR_RSP"] = 100       # Delete Bearer Response
        # 101-102 PGW to MME, MME to PGW, sgw to PGW, SGW to MME (S5/S8, S11)
        self.MSG_TYPE["GTP_DELETE_PDN_CON_REQ"] = 101    # Delete PDN Connection Set Request
        self.MSG_TYPE["GTP_DELETE_PDN_CON_RSP"] = 102    # Delete PDN Connection Set Response
        # 103-127 For future use.
        # 128-141 MME to MME, SGSN to MME, MME to SGSN, SGSN to SGSN (S3/10/S16)
        self.MSG_TYPE["GTP_IDEN_REQ"] = 128              # Identification Request
        self.MSG_TYPE["GTP_IDEN_RSP"] = 129              # Identification Response
        self.MSG_TYPE["GTP_SGSN_CONTEXT_REQ"] = 130      # SGSN Context Request
        self.MSG_TYPE["GTP_SGSN_CONTEXT_RSP"] = 131      # SGSN Context Response
        self.MSG_TYPE["GTP_SGSN_CONTEXT_ACK"] = 132      # SGSN Context Acknowledge
        self.MSG_TYPE["GTP_FWD_RELOC_REQ"] = 133         # Forward Relocation Request
        self.MSG_TYPE["GTP_FWD_RELOC_RSP"] = 134         # Forward Relocation Response
        self.MSG_TYPE["GTP_FWD_RELOC_COMPL_NOTIF"] = 135 # Forward Relocation Complete Notification
        self.MSG_TYPE["GTP_FWD_RELOC_COMPL_ACK"] = 136   # Forward Relocation Complete Acknowledge
        self.MSG_TYPE["GTP_FWD_ACCSS_CTEX_NOTIF"] = 137  # Forward Access Context Notification
        self.MSG_TYPE["GTP_FWD_ACCSS_CTEX_ACK"] = 138    # Forward Access Context Acknowledge
        self.MSG_TYPE["GTP_RELOC_CANCEL_REQ"] = 139      # Relocation Cancel Request
        self.MSG_TYPE["GTP_RELOC_CANCEL_RSP"] = 140      # Relocation Cancel Response
        self.MSG_TYPE["GTP_CONF_TRANS_TNL"] = 141        # Configuration Transfer Tunnel
        # 142-148 For future use.
        # 149-152 SGSN to MME, MME to SGSN (S3)
        self.MSG_TYPE["GTP_DETACH_NOTIF"] = 149          # Detach Notification
        self.MSG_TYPE["GTP_DETACH_ACK"] = 150            # Detach Acknowledge
        self.MSG_TYPE["GTP_CS_PAGING"] = 151             # CS Paging Indication
        self.MSG_TYPE["GTP_RAN_INFO_RELAY"] = 152        # RAN Information Relay       
        # 153-159 For future use.
        # 160-171 MME to SGW (S11)
        self.MSG_TYPE["GTP_CREATE_FWD_TNL_REQ"] = 160    # Create Forwarding Tunnel Request                
        self.MSG_TYPE["GTP_CREATE_FWD_TNL_RSP"] = 161    # Create Forwarding Tunnel Response               
        self.MSG_TYPE["GTP_SUSPEND_NOTIF"] = 162         # Suspend Notification                            
        self.MSG_TYPE["GTP_SUSPEND_ACK"] = 163           # Suspend Acknowledge                             
        self.MSG_TYPE["GTP_RESUME_NOTIF"] = 164          # Resume Notification                             
        self.MSG_TYPE["GTP_RESUME_ACK"] = 165            # Resume Acknowledge                              
        self.MSG_TYPE["GTP_CREATE_INDIRECT_D_FWD_TNL_REQ"] = 166   # Create Indirect Data Forwarding Tunnel Request  
        self.MSG_TYPE["GTP_CREATE_INDIRECT_D_FWD_TNL_RSP"] = 167   # Create Indirect Data Forwarding Tunnel Response 
        self.MSG_TYPE["GTP_DELETE_INDIRECT_D_FWD_TNL_REQ"] = 168   # Delete Indirect Data Forwarding Tunnel Request     
        self.MSG_TYPE["GTP_DELETE_INDIRECT_D_FWD_TNL_RSP"] = 169   # Delete Indirect Data Forwarding Tunnel Response    
        self.MSG_TYPE["GTP_REL_ACCESS_BEAR_REQ"] = 170   # Release Access Bearers Request                       
        self.MSG_TYPE["GTP_REL_ACCESS_BEAR_RSP"] = 171   # Release Access Bearers Response                      
        # 172-175 For future use.
        # 176-177 SGW to SGSN/MME (S4/S11)
        self.MSG_TYPE["GTP_DL_DATA_NOTIF"] = 176         # Downlink Data Notification
        self.MSG_TYPE["GTP_DL_DATA_NOTIF_ACK"] = 177     # Downlink Data Notification Acknowledge
        # 178 SGW to SGSN (S4)
        self.MSG_TYPE["GTP_UPDATE_BEAR_COMPL"] = 178     # Update Bearer Complete
        # 179-191 For future use.
        
        # Other 192-255 For future use.

        # 01 bitfield, with typical values
        #    010..... Version: 2
        #    ...0.... Piggybacking flag (P): 0  
        #    ....1... TEID flag (T): 1
        #    .....000 Spare
        self.set_flags(0, 1)
        self.msg_type = \
            self.MSG_TYPE["GTP_CREATE_SESS_REQ"];    # 02 Message type. T-PDU = 0xff
        #self.length = 0;                           # 03 Length (of IP packet or signalling) 
        self.teid = 0x11111;                        # 05 - 08 Tunnel Endpoint ID 
        self.seq = 0;           # 09 - 11 (or 05 - 07) Sequence Number  
        self.payload = ""
        self.ie = S_Gtpiev2()

    def set_seq(self, seq):
        self.seq = seq << 8

    def set_teid(self, teid):
        self.teid = teid

    def set_msg_type(self, msg_type):
        self.msg_type = self.MSG_TYPE[msg_type]

    # set to 1 or zero
    def set_flags(self, P, T):
        self.flags = 0x40
        if 1 == P:
            self.flags += 16
        if 1 == T:
            self.flags += 8

    def is_long_hdr(self):
        return (self.flags & 0x8) != 0

    def get_version(self):
        return 2

    def create_sess_req(self):
        ies = ordered_dict.OrderedDict()
        ies["GTPIE_IMSI"] = "\x24\x00\x11\x32\x54\x76\x00\xf0" #pack("!Q", 420011234567000) #123456789012345)
        ies["GTPIE_ULI"] = "\x18\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
        ies["GTPIE_SERV_NET"] = "\x00\x00\x00"
        ies["GTPIE_RAT_TYPE"] = "\x06"
        ies["GTPIE_INDICAT"] = "\x00\x00\x00"
        ies["GTPIE_F_TEID"] = self.ie.pack_f_teid_v4(S58_SGW_C, 0x1, int(ipaddr.IPAddress("2.0.0.5")))
        ies["GTPIE_APN"] = "\x08\x6a\x61\x77\x61\x6c\x6e\x65\x74\x03\x63\x6f\x6d\x04\x73\x61\x30\x30"
        ies["GTPIE_SELECTION_MODE"] = "\x00\x00"
        ies["GTPIE_PDN_TYPE"] = "\x01"
        ies["GTPIE_RECOVERY"] = "\x01"
        ies["GTPIE_PAA"] = self.ie.pack_paa(int(ipaddr.IPAddress("10.208.1.1")))
        ies["GTPIE_BEAR_CTXT[0]"] = self.ie.pack_bearer_ctxt(0, 5, 0, 0, \
                                    self.ie.pack_f_teid_v4(S58_SGW_U, 0x1, int(ipaddr.IPAddress("2.0.0.6"))), 0, 0)
        return ies

    def create_sess_rsp(self):
        ies = ordered_dict.OrderedDict()
        ies["GTPIE_CAUSE"] = pack("!B", 16)
        ies["GTPIE_F_TEID"] = self.ie.pack_f_teid_v4(S58_PGW_C, 0x1, int(ipaddr.IPAddress("3.0.0.6")))
        ies["GTPIE_PAA"] = self.ie.pack_paa(int(ipaddr.IPAddress("10.208.1.1")))
        ies["GTPIE_RECOVERY"] = "\x01"
        ies["GTPIE_BEAR_CTXT[0]"] = self.ie.pack_bearer_ctxt(16, 5, 0, 0, \
                                    self.ie.pack_f_teid_v4(S58_PGW_U, 0x1, int(ipaddr.IPAddress("3.0.0.6"))), 0, 0)
        return ies

    def create_sess_req_s4(self):
        ies = ordered_dict.OrderedDict()
        ies["GTPIE_IMSI"] = pack("!Q", 123456789012345)
        ies["GTPIE_ULI"] = "\x18\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
        ies["GTPIE_SERV_NET"] = "\x00\x00\x00"
        ies["GTPIE_RAT_TYPE"] = "\x06"
        ies["GTPIE_INDICAT"] = "\x00\x00\x00"
        ies["GTPIE_F_TEID"] = self.ie.pack_f_teid_v4(S4_SGSN_C, 0x1, int(ipaddr.IPAddress("2.0.0.5")))
        ies["GTPIE_F_TEID_1_INS"] = self.ie.pack_f_teid_v4(S58_PGW_C, 0x1, int(ipaddr.IPAddress("3.0.0.5")))
        apn = "auto-ut.gprs.juniper.net"
        ies["GTPIE_APN"] = pack("!B%ds"%len(apn), len(apn), apn)
        ies["GTPIE_PDN_TYPE"] = "\x01"
        ies["GTPIE_BEAR_CTXT[0]"] = self.ie.pack_bearer_ctxt(0, 5, 0, 0, \
                                    self.ie.pack_f_teid_v4(S4_SGSN_U, 0x1, int(ipaddr.IPAddress("2.0.0.6"))), 0, 0)
        return ies

    def create_sess_rsp_s4(self):
        ies = ordered_dict.OrderedDict()
        ies["GTPIE_CAUSE"] = pack("!B", 16) 
        ies["GTPIE_F_TEID"] = self.ie.pack_f_teid_v4(S4_SGSN_C, 0x1, int(ipaddr.IPAddress("3.0.0.6")))
        ies["GTPIE_F_TEID_1_INS"] = self.ie.pack_f_teid_v4(S4_SGW_C, 0x1, int(ipaddr.IPAddress("3.0.0.5")))
        ies["GTPIE_PAA"] = self.ie.pack_paa(int(ipaddr.IPAddress("10.208.1.1")))
        ies["GTPIE_BEAR_CTXT[0]"] = self.ie.pack_bearer_ctxt(16, 5, 0, 0, \
                                    self.ie.pack_f_teid_v4(S4_SGW_U, 0x1, int(ipaddr.IPAddress("3.0.0.6"))), 0, 0)
        return ies

    def create_bear_req(self):
        ies = ordered_dict.OrderedDict()
        ies["GTPIE_EBI"] = pack("!B", 5)
        ies["GTPIE_BEAR_CTXT[0]"] = self.ie.pack_bearer_ctxt(0, 0, 0, \
                                    self.ie.pack_f_teid_v4(5, 0x3, int(ipaddr.IPAddress("3.0.0.6"))), 0, 0, 0)
        return ies

    def create_bear_rsp(self):
        ies = ordered_dict.OrderedDict()
        ies["GTPIE_CAUSE"] = pack("!B", 16)
        ies["GTPIE_BEAR_CTXT[0]"] = self.ie.pack_bearer_ctxt(16, 6,\
                                                    0, 0, \
                                                    self.ie.pack_f_teid_v4(4, 0x2, int(ipaddr.IPAddress("2.0.0.6"))),\
                                                    self.ie.pack_f_teid_v4(5, 0x3, int(ipaddr.IPAddress("3.0.0.6"))), 0) 
        return ies

    def modify_bear_req(self):
        ies = ordered_dict.OrderedDict()
        ies["GTPIE_F_TEID"] = self.ie.pack_f_teid_v4(S58_SGW_C, 0x1, int(ipaddr.IPAddress("2.0.0.7")))
        ies["GTPIE_BEAR_CTXT[0]"] = self.ie.pack_bearer_ctxt(0, 5, 0, \
                                    self.ie.pack_f_teid_v4(S58_SGW_U, 0x2, int(ipaddr.IPAddress("2.0.0.7"))), 0, 0)
        return ies

    def modify_bear_rsp(self):
        ies = ordered_dict.OrderedDict()
        ies["GTPIE_CAUSE"] = pack("!B", 16)
        ies["GTPIE_EBI"] = pack("!B", 5)
        ies["GTPIE_BEAR_CTXT[0]"] = self.ie.pack_bearer_ctxt(16, 5, 0, 0, 
                                    self.ie.pack_f_teid_v4(5, 0x1, int(ipaddr.IPAddress("3.0.0.6"))), 0, 0)
        return ies

    def delete_sess_req(self):
        ies = ordered_dict.OrderedDict()
        ies["GTPIE_CAUSE"] = pack("!B", 16)
        ies["GTPIE_EBI"] = pack("!B", 5)
        return ies

    def delete_sess_rsp(self):
        ies = ordered_dict.OrderedDict()
        ies["GTPIE_CAUSE"] = pack("!B", 16)
        return ies

    def delete_bear_req(self):
        ies = ordered_dict.OrderedDict()
        ies["GTPIE_EBI_1_INS[0]"] = pack("!B", 5)
        return ies

    def delete_bear_rsp(self):
        ies = ordered_dict.OrderedDict()
        ies["GTPIE_CAUSE"] = pack("!B", 16)
        ies["GTPIE_BEAR_CTXT[0]"] = self.ie.pack_bearer_del(5, 16)
        return ies

    def context_req(self):
        ies = ordered_dict.OrderedDict()
        ies["GTPIE_IMSI"] = "\x03\x52\x01\x02\x00\x00\x18\xf4"
        ies["GTPIE_ULI"] = "\x04\x03\x02\x15\x27\x10\x0a"
        ies["GTPIE_P_TMSI"] = "\xcf\x10\x1c\x0e"
        ies["GTPIE_P_TMSI_S"] = "\xa6\x4a\x25"
        ies["GTPIE_F_TEID"] = self.ie.pack_f_teid_v4(s_gtp.S4_SGSN_C, 0x1, \
                                        int(ipaddr.IPAddress("2.0.0.5"))) # new MME/SGSN control teid & ip
        return ies

    def context_rsp(self):
        ies = ordered_dict.OrderedDict()
        ies["GTPIE_CAUSE"] = pack("!B", 16)
        ies["GTPIE_IMSI"] = "\x03\x52\x01\x02\x00\x00\x18\xf4"
        ies["GTPIE_MM_CONTEXT_1N"] = "\x00\x01"
        ies["GTPIE_F_TEID"] = self.ie.pack_f_teid_v4(s_gtp.S4_SGSN_C, 0x1, \
                                        int(ipaddr.IPAddress("2.0.0.6")))           # old MME/SGSN control teid & ip
        ies["GTPIE_F_TEID_1_INS"] = self.ie.pack_f_teid_v4(s_gtp.S4_SGW_C, 0x1, \
                                        int(ipaddr.IPAddress("3.0.0.6")))           # SGW control teid & ip
        return ies

    def context_ack(self):
        ies = ordered_dict.OrderedDict()
        ies["GTPIE_CAUSE"] = pack("!B", 16)
        ies["GTPIE_INDICAT"] = pack("!BB", 0x01, 0x00)
        return ies

    def forward_reloc_req(self):
        ies = ordered_dict.OrderedDict()
        ies["GTPIE_IMSI"] = "\x03\x52\x01\x02\x00\x00\x18\xf4"
        ies["GTPIE_F_TEID"] = self.ie.pack_f_teid_v4(s_gtp.S4_SGSN_C, 0x1, \
                                        int(ipaddr.IPAddress("2.0.0.6")))           # old MME/SGSN control teid & ip
        ies["GTPIE_F_TEID_1_INS"] = self.ie.pack_f_teid_v4(s_gtp.S4_SGW_C, 0x1, \
                                        int(ipaddr.IPAddress("3.0.0.6")))           # SGW control teid & ip
        ies["GTPIE_MM_CONTEXT_1N"] = "\x00\x01"
        return ies

    def forward_reloc_rsp(self):
        ies = ordered_dict.OrderedDict()
        ies["GTPIE_CAUSE"] = pack("!B", 16)
        ies["GTPIE_F_TEID"] = self.ie.pack_f_teid_v4(s_gtp.S4_SGSN_C, 0x1, \
                                        int(ipaddr.IPAddress("2.0.0.5"))) # new MME/SGSN control teid & ip
        ies["GTPIE_INDICAT"] = pack("!BB", 0x01, 0x00)
        return ies

    def create_indir_data_fwd_tnl_req(self):
        ies = ordered_dict.OrderedDict()
        return ies

    def create_indir_data_fwd_tnl_rsp(self):
        ies = ordered_dict.OrderedDict()
        ies["GTPIE_CAUSE"] = pack("!B", 16)
        return ies

    def echo_req(self):
        ies = ordered_dict.OrderedDict()
        return ies

    def echo_rsp(self):
        ies = ordered_dict.OrderedDict()
        ies["GTPIE_RECOVERY"] = "\x01"
        return ies

    def set_payload(self, payload):
        self.payload = payload
        self.payload_len = len(payload) + 4

    def to_buffer(self):
        if self.is_long_hdr():
            return pack("!BBHII", self.flags, self.msg_type, self.payload_len + 4, self.teid, self.seq) + self.payload
        return pack("!BBHI", self.flags, self.msg_type, len(self.payload), self.seq) + self.payload

    def from_buffer(self, buf):
        self.flags = pack_from("B", buf[0:1])
        if self.is_long_hdr():
            self.msg_type = pack_from("B", buf[1:2])
            payload_len = pack_from("!H", buf[2:4]) - 8
            self.teid = pack_from("!I", buf[4:8])
            self.seq = pack_from("!I", buf[8:12]) >> 8
            self.payload = buf[12:12 + payload_len]
            return self.payload

        self.msg_type = pack_from("B", buf[1:2])
        payload_len = pack_from("!H", buf[2:4]) - 4
        self.seq = pack_from("!I", buf[4:8]) >> 8
        self.payload = buf[8: 8 + payload_len]
        return self.payload

def test_ie():
    ie = S_Gtpie()
    buf = ie.pack(15, "a23")
    print repr(buf)
    (t, l, v) = ie.unpack(buf)
    print "%d, %d, %s"%(t, l, repr(v))

def main():
    eth = s_eth.S_Eth()
    ip = s_ip.S_Ip()
    udp = s_udp.S_Udp()
    gtp = S_Gtpv1()
    ie = S_Gtpiev1()
    
    eth.set_mac("0x00:0x10:0xdb:0xb9:0x8f:0x65", "0x00:0x50:0x56:0x97:0x17:0x7e")
    ip.set_ip("1.1.1.1", "2.2.2.2")
    ip.set_proto(s_ip.udp)
    udp.set_port(GTP1C_PORT, GTP1C_PORT)

    gtp.set_flags(1, 0, 1, 0)
    gtp.set_msg_type("GTP_CREATE_PDP_REQ")
    gtp.set_teid(0)
    gtp.set_seq(0x1234)

    ies = ""
    ies += ie.pack("GTPIE_IMSI", pack("!Q", 123456789012345))
    ies += ie.pack("GTPIE_RECOVERY", "\x0a")
    ies += ie.pack("GTPIE_TEI_DI", pack("!I", 0xdddd0))
    ies += ie.pack("GTPIE_TEI_C", pack("!I", 0xcccc0))
    ies += ie.pack("GTPIE_NSAPI", "\x0d")
    ies += ie.pack("GTPIE_EUA", "\xf1\x21")
    ies += ie.pack("GTPIE_APN", "auto-ut.gprs.juniper.net")
    ies += ie.pack("GTPIE_GSN_ADDR", s_net.ip_str2b("1.1.1.2"))
    ies += ie.pack("GTPIE_GSN_ADDR", s_net.ip_str2b("1.1.1.3"))
    ies += ie.pack("GTPIE_MSISDN", "\x91\x81\x19\x70\x83\x90\xf9")
    ies += ie.pack("GTPIE_QOS_PROFILE", "\x01\x09\x11\x01\x29\x01\x01\x01\x11\x05\x01\x01")

    gtp.set_payload(ies)
    udp.set_payload(gtp.to_buffer())
    ip.set_payload(udp.to_buffer())
    eth.set_payload(ip.to_buffer())
    buf = eth.to_buffer()
    s_net.buff2pcap(buf, "gtp_req")

    gtp_rsp = S_Gtpv1()

    gtp_rsp.set_flags(1, 0, 1, 0)
    gtp_rsp.set_msg_type("GTP_CREATE_PDP_RSP")
    gtp_rsp.set_teid(0xcccc0)
    gtp_rsp.set_seq(0x1234)

    ies = ""
    ies += ie.pack("GTPIE_CAUSE", pack("!B", 128))
    ies += ie.pack("GTPIE_REORDER", "\xff")
    ies += ie.pack("GTPIE_RECOVERY", "\x01")
    ies += ie.pack("GTPIE_TEI_DI", pack("!I", 0xdddd1))
    ies += ie.pack("GTPIE_TEI_C", pack("!I", 0xcccc1))
    ies += ie.pack("GTPIE_CHARGING_ID", pack("!I", 1))
    ies += ie.pack("GTPIE_EUA", "\x21\xc9\x0a\x00\x01")
    ies += ie.pack("GTPIE_GSN_ADDR", s_net.ip_str2b("2.2.2.3"))
    ies += ie.pack("GTPIE_GSN_ADDR", s_net.ip_str2b("2.2.2.4"))
    ies += ie.pack("GTPIE_GSN_ADDR", s_net.ip_str2b("2.2.2.5"))
    ies += ie.pack("GTPIE_GSN_ADDR", s_net.ip_str2b("2.2.2.6"))
    ies += ie.pack("GTPIE_QOS_PROFILE", "\x01\x09\x11\x01\x29\x01\x01\x01\x11\x05\x01\x01")

    gtp_rsp.set_payload(ies)
    udp.set_payload(gtp_rsp.to_buffer())
    ip.set_payload(udp.to_buffer())
    eth.set_payload(ip.to_buffer())
    buf = eth.to_buffer()
    s_net.buff2pcap(buf, "gtp_rsp")



    
    #print init.get_value()
    #sctp.set_chunks(init.get_value() + init_ack.get_value() + cookie_echo.get_value() + cookie_ack.get_value() + cookie_echo.get_value() + cookie_ack.get_value() + 
    #        abort.get_value() + sd.get_value() + sd_ack.get_value() + sd_comp.get_value() + sack.get_value() + hb.get_value() + hb_ack.get_value() + error.get_value())
    #sctp.set_chunks(init.get_value())
    #buf = sctp.get_value()
    #ip.set_data_len(len(buf))
    #buf = eth.get_value() + ip.get_value() + sctp.get_value()

    #eth.dump()
    #ip.dump()
    #sctp.dump()
    print "len=%d\n"%len(buf)
    print repr(buf)
    #s_net.win_data2pcap(buf, "test")

if "__main__" == __name__:
    main()
