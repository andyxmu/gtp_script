#!/usr/bin/python
import string, glob, os, sys
import datetime, time
import unittest
import s_gtp
sys.path.append("../../")
sys.path.append("../")
import s_dut
import s_net_toolkit as s_net
import s_base_toolkit
import s_udp, s_ip, s_eth
import s_socket_daemon
import ipaddr
import ordered_dict
from struct import *

class Gtp_Dut(s_dut.Dut):
    def show_gsn(self):
        for spu_id in range(0, self.SPU_NUM):
            # -->spu
            print >> self.log, self.enter_spu(5, spu_id)
            print >> self.log, self.do_spu("show usp gtp gsn content")
            print >> self.log, self.exit_spu()
            # -->spu

    def show_tunnel(self):
        print >> self.log, self.enter_cli()
        print >> self.log, self.do_cli("show security gprs gtp tunnels | no-more")
        print >> self.log, self.exit_cli()

    def clear_tunnel(self):
        print >> self.log, self.enter_cli()
        print >> self.log, self.do_cli("clear security gprs gtp tunnel all")
        print >> self.log, self.exit_cli()


# mac:
# wing0 --> wing1
#   pc:eth1 --> dut:4/0/0 --+
#                           X
#   pc:eth2 <-- dut:4/0/1 --+
#
# wing1 --> wing0
#   pc:eth1 <-- dut:4/0/0 --+
#                           X
#   pc:eth2 --> dut:4/0/1 --+
#
#   eth1: 00:50:56:97:6F:82
#   eth2: 00:50:56:8F:03:3B
#   dut4/0/1: FF:FF:FF:FF:FF:FF
#   dut4/0/2: FF:FF:FF:FF:FF:FF

mac_eth1 = "00:50:56:AC:00:68"
mac_eth2 = "00:50:56:AC:00:7A"
mac_eth3 = "00:50:56:AC:02:98"
mac_eth4 = "00:50:56:AC:02:99"

#base on vlan
mac_dut400 = "00:24:dc:20:55:28" 
mac_dut401 = "00:24:dc:20:55:29" 
mac_dut402 = "00:24:dc:20:55:2a" 
mac_dut403 = "00:24:dc:20:55:2b" 

def print_topology():
    print >> log, "# mac: \n# wing0 --> wing1 \n#   pc:eth1 --> dut:4/0/0 --+ \n#                           X \n#   pc:eth2 <-- dut:4/0/1 --+ \n# \n# wing1 --> wing0 \n#   pc:eth1 <-- dut:4/0/0 --+ \n#                           X \n#   pc:eth2 --> dut:4/0/1 --+ \n# \n#   eth1: %s \n#   eth2: %s \n#   dut4/0/1: %s \n#   dut4/0/2: %s"%(mac_eth1, mac_eth2, mac_dut401, mac_dut402)

# ip --> conform to the ip_list.
# udp 
port = [s_gtp.GTP1C_PORT, s_gtp.GTP1C_PORT]
ip_list = [["1.1.1.1", "3.3.3.3"], ["2.2.2.2", "4.4.4.4"]]

# layer 2
eth = [s_eth.S_Eth(), s_eth.S_Eth(), s_eth.S_Eth(), s_eth.S_Eth()]
# layer 3
ip = [s_ip.S_Ip(), s_ip.S_Ip(), s_ip.S_Ip(), s_ip.S_Ip()]
# layer 4 - common sctp
udp = [s_udp.S_Udp(), s_udp.S_Udp()]
# application layer
gtp = [s_gtp.S_Gtpv1(), s_gtp.S_Gtpv1()]

gtp_ie = {"GTP_CREATE_PDP_REQ":ordered_dict.OrderedDict(), "GTP_CREATE_PDP_RSP":ordered_dict.OrderedDict(), \
          "GTP_DELETE_PDP_REQ":ordered_dict.OrderedDict(), "GTP_DELETE_PDP_RSP":ordered_dict.OrderedDict()}

show_packet_detail = False 

def do_init():
    # eth1->dut:4/0/1
    eth[0].set_mac(mac_eth1, mac_dut400)
    eth[0].set_inf("eth1")
    eth[1].set_mac(mac_eth2, mac_dut401)
    eth[1].set_inf("eth2")

    eth[2].set_mac(mac_eth3, mac_dut402)
    eth[2].set_inf("eth3")
    eth[3].set_mac(mac_eth4, mac_dut403)
    eth[3].set_inf("eth4")

    # 1.1.1.1 -> 2.2.2.2
    ip[0].set_ip(ip_list[0][0], ip_list[1][0])
    ip[0].set_proto(s_ip.udp)
    # 2.2.2.2 -> 1.1.1.1
    ip[1].set_ip(ip_list[1][0], ip_list[0][0])
    ip[1].set_proto(s_ip.udp)
    # 3.3.3.3 -> 4.4.4.4 
    ip[2].set_ip(ip_list[0][1], ip_list[1][1])
    ip[2].set_proto(s_ip.sctp)
    # 4.4.4.4 -> 3.3.3.3 
    ip[3].set_ip(ip_list[1][1], ip_list[0][1])
    ip[3].set_proto(s_ip.sctp)

    udp[0].set_port(port[0], port[1])
    udp[1].set_port(port[1], port[0])

    gtp[0].set_flags(1, 0, 1, 0)
    gtp[0].set_msg_type("GTP_CREATE_PDP_REQ")
    gtp[0].set_teid(0)
    gtp[0].set_seq(0x1234)

    gtp[1].set_flags(1, 0, 1, 0)
    gtp[1].set_msg_type("GTP_CREATE_PDP_RSP")
    gtp[1].set_teid(0xcccc0)
    gtp[1].set_seq(0x1234)

    ies = gtp_ie["GTP_CREATE_PDP_REQ"]
    ies["GTPIE_IMSI"] = pack("!Q", 123456789012345)
    ies["GTPIE_RECOVERY"] = "\x0a"
    ies["GTPIE_SELECTION_MODE"] = "\x00"
    ies["GTPIE_TEI_DI"] = pack("!I", 0xdddd0)
    ies["GTPIE_TEI_C"] = pack("!I", 0xcccc0)
    ies["GTPIE_NSAPI"] = "\x0d"
    ies["GTPIE_EUA"] = "\xf1\x21"
    ies["GTPIE_APN"] = "auto-ut.gprs.juniper.net"
    ies["GTPIE_GSN_ADDR[0]"] = s_net.ip_str2b("1.1.1.1")
    ies["GTPIE_GSN_ADDR[1]"] = s_net.ip_str2b("3.3.3.3")
    ies["GTPIE_MSISDN"] = "\x91\x81\x19\x70\x83\x90\xf9"
    ies["GTPIE_QOS_PROFILE"] = "\x01\x09\x11\x01\x29\x01\x01\x01\x11\x05\x01\x01"

    ies = gtp_ie["GTP_CREATE_PDP_RSP"]
    ies["GTPIE_CAUSE"] = pack("!B", 128)
    ies["GTPIE_REORDER"] = "\xff"
    ies["GTPIE_RECOVERY"] = "\x01"
    ies["GTPIE_TEI_DI"] = pack("!I", 0xdddd1)
    ies["GTPIE_TEI_C"] = pack("!I", 0xcccc1)
    ies["GTPIE_CHARGING_ID"] = pack("!I", 1)
    ies["GTPIE_EUA"] = "\x21\xc9\x0a\x00\x01"
    ies["GTPIE_GSN_ADDR[0]"] = s_net.ip_str2b("2.2.2.2")
    ies["GTPIE_GSN_ADDR[1]"] = s_net.ip_str2b("4.4.4.4")
    ies["GTPIE_QOS_PROFILE"] = "\x01\x09\x11\x01\x29\x01\x01\x01\x11\x05\x01\x01"

    ies = gtp_ie["GTP_DELETE_PDP_REQ"]
    ies["GTPIE_TEARDOWN"] = "\xfe"
    ies["GTPIE_NSAPI"] = "\x0d"

    ies = gtp_ie["GTP_DELETE_PDP_RSP"]
    ies["GTPIE_CAUSE"] = pack("!B", 128)


def send_gtp(direction, ies, to_pcap = False):
    eth_ = eth[direction]
    ip_ = ip[direction]
    udp_ = udp[direction]
    gtp_ = gtp[direction]

    buf = ""
    ie = s_gtp.S_Gtpiev1()
    for key in ies:
        print >> log, key
        t = key.rstrip("[0123456789]")
        buf += ie.pack(t, ies[key])

    gtp_.set_payload(buf)
    udp_.set_payload(gtp_.to_buffer())
    ip_.set_payload(udp_.to_buffer())
    eth_.set_payload(ip_.to_buffer())
    if not to_pcap:
        sd.send(eth_)
    else:
        sd.send_to_pcap("gtp%d"%direction, eth_)

def verify_gtp(direction):
    if not sd.recv(eth[direction], 1):
        print >> log, "faliure:%s"%sd.errmsg
        return False

    if show_packet_detail:
        eth_ = s_eth.S_Eth()
        ip_ = s_ip.S_Ip()
        udp_ = s_udp.S_Udp()

        udp_.from_buffer(ip_.from_buffer(eth_.from_buffer(sd.buff)))

        eth_.dump()
        ip_.dump()
        udp_.dump()

    return True

def show_title(msg):
    print >> log, "******************************************"
    print >> log, msg
    print >> log, "******************************************"

def show_ut_title(msg):
    print >> log, "||||||||||||||||||||||||||||||||||||||||||"
    print >> log, "++++++++++++++++++++++++++++++++++++++++++"

    print >> log, msg
    
    print >> log, "++++++++++++++++++++++++++++++++++++++++++"
    print >> log, "||||||||||||||||||||||||||||||||||||||||||"




def create():
    show_title("SEND CREATE PDP REQUEST")
    send_gtp(0, gtp_ie["GTP_CREATE_PDP_REQ"])
    if not verify_gtp(1):
        print >> log, "***[FAILURE]***"
        return False

    show_title("SEND CREATE PDP RESPONSE")
    send_gtp(1, gtp_ie["GTP_CREATE_PDP_RSP"])
    if not verify_gtp(0):
        print >> log, "***[FAILURE]***"
        return False
    return True

def close():
    show_title("SEND DELETE PDP REQUEST")
    gtp[0].set_teid(0xcccc1)
    gtp[0].set_msg_type("GTP_DELETE_PDP_REQ")
    send_gtp(0, gtp_ie["GTP_DELETE_PDP_REQ"])
    if not verify_gtp(1):
        print >> log, "***[FAILURE]***"
        return False
    
    show_title("SEND DELETE PDP RESPONSE")
    gtp[1].set_msg_type("GTP_DELETE_PDP_RSP")
    send_gtp(1, gtp_ie["GTP_DELETE_PDP_RSP"])
    if not verify_gtp(0):
        print "***[FAILURE]***"
        return False
    return True


class Demo_UT(unittest.TestCase):
    def setUp(self):
        print >> log, "\n"
        self.dut = Gtp_Dut("10.208.130.234", 22, log)
        self.assertTrue(self.dut.login("root", "netscreen1"))

    def tearDown(self):
        print >> log, "\n"
        self.dut.logout()

    def test_setup_tunnel(self):
        show_ut_title("SETUP TUNNEL AND CHECK GSN")
        self.dut.clear_tunnel()
        time.sleep(2)
        self.assertTrue(create())
        self.dut.show_tunnel()
        self.dut.show_gsn()

        self.assertTrue(close())
        self.dut.show_tunnel()

    def test_u2(self):
        show_ut_title("CASE2")

    def test_u3(self):
        show_ut_title("CASE3")

    def test_u4(self):
        show_ut_title("CASE4")



    
do_init()
log = s_base_toolkit.S_Log(datetime.datetime.now().strftime("log/gtp-%Y-%m-%d_%H-%M-%S.log"))
print_topology()
sd = s_socket_daemon.S_Socket_Daemon(eth, s_ip.udp)
sd.startup()

if "__main__" == __name__:
    unittest.main()
