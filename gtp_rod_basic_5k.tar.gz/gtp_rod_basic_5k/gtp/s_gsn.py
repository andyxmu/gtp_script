#!/usr/bin/python
import string, glob, os, sys 
sys.path.append("../")
import s_net_toolkit as s_net
import s_gtp, s_udp, s_ip, s_eth, s_cfg
import s_socket_daemon
import struct
import s_dut

# GTP Version
GTP_V0 = 0 
GTP_V1 = 1 
GTP_V2 = 2
 
class S_Gsn(object):
    def __init__(self, eth):
        self.eth = eth                 # eth layer for sending msg
        self.ip  = s_ip.S_Ip()         # ip layer 
        self.ip.set_proto(s_ip.udp)    
        self.udp = s_udp.S_Udp()       # udp layer
        self.gtp = s_gtp.S_Gtpv1()     # gtp layer
        self.ie  = s_gtp.S_Gtpiev1()   
        self.ver = 0
        self.seq = 1                   # seq for control message
        self.pdu_seq = 1               # seq for data message
        self.restart_cnt = "\x01"
        self.ip_addr = ""              # self ipv4 address
        self.ip_addr2 = ""             # self ipv4 address for gsn pool
        self.ip_alt_addr = ""          # self ipv6 address
        self.ip_nat_addr = ""          # self nated address
        self.msg = self.gtp.create_pdp_req()

    def set_daemon(self, daemon):
        self.daemon = daemon

    def send(self, ies, pg_buf = "", to_pcap = False): 
        buf = ""
        for key in ies:
            print key
            t = key.rstrip("[0123456789]")
            buf += self.ie.pack(t, ies[key])

        self.gtp.set_payload(buf)
        udp_pl = self.gtp.to_buffer()
        if pg_buf != "":
            udp_pl += pg_buf
        self.udp.set_payload(udp_pl)
        self.ip.set_payload(self.udp.to_buffer())
        self.eth.set_payload(self.ip.to_buffer())
        if not to_pcap:
            ret = self.daemon.send(self.eth)
        else:
            ret = self.daemon.send_to_pcap("gtp%d"%self.seq, self.eth)
        if not ret:
            return False
        else:
            self.seq += 1
            return True
       
    def send_gpdu(self, pdu_buf, to_pcap = False):
        buf = pdu_buf
        self.gtp.set_payload(buf)
        udp_pl = self.gtp.to_buffer()
 
        self.udp.set_payload(udp_pl)
        self.ip.set_payload(self.udp.to_buffer())
        self.eth.set_payload(self.ip.to_buffer())
        if not to_pcap:
            return self.daemon.send(self.eth)
        else:
            if not self.daemon.send_to_pcap("gtp_pdu%d"%self.pdu_seq, self.eth):
                return False
            else:
                self.pdu_seq += 1
                return True
 
    def recv(self, detail = False):
        if not self.daemon.recv(self.eth):
            print "faliure:%s"%self.daemon.errmsg
            return False
        
        eth_ = s_eth.S_Eth()     
        ip_ = s_ip.S_Ip()       
        udp_ = s_udp.S_Udp()  
        if self.ver == GTP_V0:
            gtp_ = s_gtp.S_Gtpv0()
        elif self.ver == GTP_V1:
            gtp_ = s_gtp.S_Gtpv1()  
        elif self.ver == GTP_V2:
            gtp_ = s_gtp.S_Gtpv2()
    
        #gtp_.from_buffer(udp_.from_buffer(ip_.from_buffer(eth_.from_buffer(self.daemon.buff))))

        if detail:
            eth_.dump()             
            ip_.dump()             
            udp_.dump()          
        
        return True 

if "__main__" == __name__:
    pass

