#!/usr/bin/python
import string, glob, os, sys, datetime, time
sys.path.append("../") 
import s_net_toolkit as s_net
import s_base_toolkit
import s_gtp, s_udp, s_ip, s_eth, s_cfg
import s_socket_daemon
import struct
import s_gsn
import s_tunnel
import s_dut, s_gtp_dut
from s_gtp import *
from struct import *
from ctypes import *

# GTP Version
GTP_V0 = 0
GTP_V1 = 1
GTP_V2 = 2
GTP_V1_U = 3

def pack_apn(apn):
    strs = apn.split(".")
    apn_str = ""
    for i in range(0, len(strs)):
        apn_str += pack("!B%ds"%len(strs[i]), len(strs[i]), strs[i])
    return apn_str

def get_gtp_ies_v0(msg_type, gsn, context = 0, context_list = [], uid = 0):
    if msg_type == "GTP_CREATE_PDP_REQ":
        ies = gsn.gtp.create_pdp_req()
        ies["GTPIE_RECOVERY"] = gsn.restart_cnt
        ies["GTPIE_FL_DI"] = pack("!H", context.utnl[0].dl_teid)
        ies["GTPIE_FL_C"] = pack("!H", context.ctnl.dl_teid)
        ies["GTPIE_APN"] = pack_apn(context.apn)
        ies["GTPIE_GSN_ADDR[0]"] = s_net.ip_str2b(context.ctnl.dl_ip)
        ies["GTPIE_GSN_ADDR[1]"] = s_net.ip_str2b(context.utnl[0].dl_ip)
    elif msg_type == "GTP_CREATE_PDP_RSP":
        ies = gsn.gtp.create_pdp_rsp()
        ies["GTPIE_RECOVERY"] = gsn.restart_cnt
        ies["GTPIE_FL_DI"] = pack("!H", context.utnl[0].ul_teid)
        ies["GTPIE_FL_C"] = pack("!H", context.ctnl.ul_teid)
        ies["GTPIE_GSN_ADDR[0]"] = s_net.ip_str2b(context.ctnl.ul_ip)
        ies["GTPIE_GSN_ADDR[1]"] = s_net.ip_str2b(context.utnl[0].ul_ip)
    elif msg_type == "GTP_UPDATE_PDP_REQ":
        ies = gsn.gtp.update_pdp_req()
        ies["GTPIE_RECOVERY"] = gsn.restart_cnt
        ies["GTPIE_FL_DI"] = pack("!H", context.utnl[0].dl_teid)
        ies["GTPIE_FL_C"] = pack("!H", context.ctnl.dl_teid)
        ies["GTPIE_GSN_ADDR[0]"] = s_net.ip_str2b(context.ctnl.dl_ip)
        ies["GTPIE_GSN_ADDR[1]"] = s_net.ip_str2b(context.utnl[0].dl_ip)
    elif msg_type == "GTP_UPDATE_PDP_RSP":
        ies = gsn.gtp.update_pdp_rsp()
        ies["GTPIE_RECOVERY"] = gsn.restart_cnt
        ies["GTPIE_FL_DI"] = pack("!H", context.utnl[0].ul_teid)
        ies["GTPIE_FL_C"] = pack("!H", context.ctnl.ul_teid)
        ies["GTPIE_GSN_ADDR[0]"] = s_net.ip_str2b(context.ctnl.ul_ip)
        ies["GTPIE_GSN_ADDR[1]"] = s_net.ip_str2b(context.utnl[0].ul_ip)
    elif msg_type == "GTP_DELETE_PDP_REQ":
        ies = gsn.gtp.delete_pdp_req()
    elif msg_type == "GTP_DELETE_PDP_RSP":
        ies = gsn.gtp.delete_pdp_rsp()
    elif msg_type == "GTP_SGSN_CONTEXT_REQ":
        ies = gsn.gtp.sgsn_context_req()
        ies["GTPIE_FL_C"] = pack("!H", context_list[0].fwd_ctnl.dl_teid)
    elif msg_type == "GTP_SGSN_CONTEXT_RSP":
        ies = gsn.gtp.sgsn_context_rsp()
        ies["GTPIE_IMSI"] = pack("!Q", context_list[0].imsi)
        ies["GTPIE_FL_C"] = pack("!H", context_list[0].fwd_ctnl.ul_teid)
        pdp_num = 0
        for j in range(0, len(context_list)):
            ctxt = context_list[j]
            for i in range(0, context.utnl_num):
                key = "GTPIE_PDP_CONTEXT[%d]"%pdp_num
                pdp_ctxt = s_gtp.S_Gtpv0pdp()
                pdp_ctxt.set_nsapi(ctxt.utnl[i].uid)
                pdp_ctxt.set_up_flc(ctxt.ctnl.ul_teid)
                pdp_ctxt.set_pdp_addr(ctxt.ue_ip)
                pdp_ctxt.set_ggsnc(context_list[0].fwd_ctnl.ul_ip)
                ies[key] = pdp_ctxt.to_buffer()
                pdp_num += 1
    elif msg_type == "GTP_SGSN_CONTEXT_ACK":
        ies = gsn.gtp.sgsn_context_ack()
        for i in range(0, context.utnl_num):
            ies["GTPIE_FL_DII[%d]"%i] = pack("!BH", context.fwd_utnl[i].dl_teid)
        ies["GTPIE_GSN_ADDR"] = s_net.ip_str2b(context.fwd_utnl[0].dl_ip) 
    elif msg_type == "GTP_ECHO_REQ":
        ies = gsn.gtp.echo_req()
    elif msg_type == "GTP_ECHO_RSP":
        ies = gsn.gtp.echo_rsp()
        ies["GTPIE_RECOVERY"] = gsn.restart_cnt
    else:
        ies = 0
    return ies

def get_gtp_ies_v1(msg_type, gsn, context, uidx):
    if msg_type == "GTP_CREATE_PDP_REQ":
        ies = gsn.gtp.create_pdp_req() 
        ies["GTPIE_IMSI"] = pack("!Q", context.imsi)
        ies["GTPIE_RECOVERY"] = gsn.restart_cnt
        ies["GTPIE_TEI_DI"] = pack("!I", context.utnl[uidx].dl_teid)
        ies["GTPIE_TEI_C"] = pack("!I", context.ctnl.dl_teid)
        ies["GTPIE_NSAPI"] = pack("!B", context.utnl[uidx].uid)
        ies["GTPIE_APN"] = pack_apn(context.apn)
        ies["GTPIE_GSN_ADDR[0]"] = s_net.ip_str2b(context.ctnl.dl_ip)
        ies["GTPIE_GSN_ADDR[1]"] = s_net.ip_str2b(context.utnl[uidx].dl_ip)
    elif msg_type == "GTP_CREATE_PDP_RSP":
        ies = gsn.gtp.create_pdp_rsp()
        ies["GTPIE_RECOVERY"] = gsn.restart_cnt
        ies["GTPIE_TEI_DI"] = pack("!I", context.utnl[uidx].ul_teid)
        ies["GTPIE_TEI_C"] = pack("!I", context.ctnl.ul_teid)
        ies["GTPIE_GSN_ADDR[0]"] = s_net.ip_str2b(context.ctnl.ul_ip)
        ies["GTPIE_GSN_ADDR[1]"] = s_net.ip_str2b(context.utnl[uidx].ul_ip)
    elif msg_type == "GTP_UPDATE_PDP_REQ":
        ies = gsn.gtp.update_pdp_req()
        ies["GTPIE_RECOVERY"] = gsn.restart_cnt
        ies["GTPIE_TEI_DI"] = pack("!I", context.utnl[uidx].dl_teid)
        ies["GTPIE_TEI_C"] = pack("!I", context.ctnl.dl_teid)
        ies["GTPIE_NSAPI"] = pack("!B", context.utnl[uidx].uid)
        ies["GTPIE_GSN_ADDR[0]"] = s_net.ip_str2b(context.ctnl.dl_ip)
        ies["GTPIE_GSN_ADDR[1]"] = s_net.ip_str2b(context.utnl[uidx].dl_ip)
    elif msg_type == "GTP_UPDATE_PDP_RSP":
        ies = gsn.gtp.update_pdp_rsp()
        ies["GTPIE_RECOVERY"] = gsn.restart_cnt
        ies["GTPIE_TEI_DI"] = pack("!I", context.utnl[uidx].ul_teid)
        ies["GTPIE_TEI_C"] = pack("!I", context.ctnl.ul_teid)
        ies["GTPIE_GSN_ADDR[0]"] = s_net.ip_str2b(context.ctnl.ul_ip)
        ies["GTPIE_GSN_ADDR[1]"] = s_net.ip_str2b(context.utnl[uidx].ul_ip)
    elif msg_type == "GTP_DELETE_PDP_REQ":
        ies = gsn.gtp.delete_pdp_req()
        ies["GTPIE_NSAPI"] = pack("!B", context.utnl[uidx].uid)
    elif msg_type == "GTP_DELETE_PDP_RSP":
        ies = gsn.gtp.delete_pdp_rsp()
    elif msg_type == "GTP_CREATE_SEC_PDP_REQ":
        ies = gsn.gtp.create_sec_pdp_req()
        ies["GTPIE_TEI_DI"] = pack("!I", context.utnl[uidx].dl_teid)
        ies["GTPIE_NSAPI[0]"] = pack("!B", context.utnl[uidx].uid) 
        ies["GTPIE_NSAPI[1]"] = pack("!B", context.utnl[uidx].pri_uid)
        ies["GTPIE_GSN_ADDR[0]"] = s_net.ip_str2b(context.ctnl.dl_ip) 
        ies["GTPIE_GSN_ADDR[1]"] = s_net.ip_str2b(context.utnl[uidx].dl_ip) 
    elif msg_type == "GTP_CREATE_SEC_PDP_RSP":
        ies = gsn.gtp.create_sec_pdp_rsp()
        ies["GTPIE_TEI_DI"] = pack("!I", context.utnl[uidx].ul_teid) 
        ies["GTPIE_GSN_ADDR[0]"] = s_net.ip_str2b(context.ctnl.ul_ip) 
        ies["GTPIE_GSN_ADDR[1]"] = s_net.ip_str2b(context.utnl[uidx].ul_ip)
    elif msg_type == "GTP_SGSN_CONTEXT_REQ":
        ies = gsn.gtp.sgsn_context_req()
        ies["GTPIE_TEI_C"] = pack("!I", context.fwd_ctnl.dl_teid)
        ies["GTPIE_GSN_ADDR"] = s_net.ip_str2b(context.fwd_ctnl.dl_ip)
    elif msg_type == "GTP_SGSN_CONTEXT_RSP":
        ies = gsn.gtp.sgsn_context_rsp()
        ies["GTPIE_IMSI"] = pack("!Q", context.imsi)
        ies["GTPIE_TEI_C"] = pack("!I", context.fwd_ctnl.ul_teid)
        for i in range(0, context.utnl_num):
            key = "GTPIE_PDP_CONTEXT[%d]"%i
            pdp_ctxt = s_gtp.S_Gtpv1pdp()
            pdp_ctxt.set_pdp_addr(context.ue_ip)
            pdp_ctxt.set_teic(context.ctnl.ul_teid)
            pdp_ctxt.set_teiu(context.utnl[i].ul_teid)
            pdp_ctxt.set_ggsnc(context.ctnl.ul_ip)
            pdp_ctxt.set_ggsnu(context.utnl[i].ul_ip)
            ies[key] = pdp_ctxt.to_buffer()
    elif msg_type == "GTP_SGSN_CONTEXT_ACK":
        ies = gsn.gtp.sgsn_context_ack()
        for i in range(0, context.utnl_num):
            key = "GTPIE_TEI_DII[%d]"%i
            ies[key] = pack("!BI", context.fwd_utnl[i].uid, context.fwd_utnl[i].dl_teid)
    elif msg_type == "GTP_ECHO_REQ":
        ies = gsn.gtp.echo_req()
    elif msg_type == "GTP_ECHO_RSP":
        ies = gsn.gtp.echo_rsp()
        ies["GTPIE_RECOVERY"] = gsn.restart_cnt
    else:
        return 0
    return ies

def get_gtp_ies_v2(msg_type, gsn, context, uidx = 0):
    if msg_type == "GTP_CREATE_SESS_REQ":
        ies = gsn.gtp.create_sess_req()
        ies["GTPIE_IMSI"] = pack("!Q", context.imsi)
        ies["GTPIE_F_TEID"] = gsn.ie.pack_f_teid_v4(S58_SGW_C, context.ctnl.dl_teid, \
                                    int(ipaddr.IPAddress(context.ctnl.dl_ip)))
        ies["GTPIE_APN"] = pack_apn(context.apn)
        ies["GTPIE_PAA"] = gsn.ie.pack_paa(int(ipaddr.IPAddress(context.ue_ip)))
        ies["GTPIE_EBI"] = pack("!B", context.utnl[uidx].pri_uid)
        if uidx:
            ies["GTPIE_BEAR_CTXT[0]"] = gsn.ie.pack_bearer_ctxt(0, context.utnl[uidx].uid, 0, 0, \
                                    gsn.ie.pack_f_teid_v4(S58_SGW_U, context.utnl[uidx].dl_teid, \
                                    int(ipaddr.IPAddress(context.utnl[uidx].dl_ip))), 0, 0)
        else:
            for i in range(0, context.utnl_num):
                key = "GTPIE_BEAR_CTXT[%d]"%i
                ies[key] = gsn.ie.pack_bearer_ctxt(0, context.utnl[i].uid, 0, 0, \
                                    gsn.ie.pack_f_teid_v4(S58_SGW_U, context.utnl[i].dl_teid, \
                                    int(ipaddr.IPAddress(context.utnl[i].dl_ip))), 0, 0)
    elif msg_type == "GTP_CREATE_SESS_RSP":
        ies = gsn.gtp.create_sess_rsp()
        ies["GTPIE_F_TEID"] = gsn.ie.pack_f_teid_v4(S58_PGW_C, context.ctnl.ul_teid, \
                                    int(ipaddr.IPAddress(context.ctnl.ul_ip)))
        ies["GTPIE_PAA"] = gsn.ie.pack_paa(int(ipaddr.IPAddress(context.ue_ip)))
        for i in range(0, context.utnl_num):
            key = "GTPIE_BEAR_CTXT[%d]"%i
            ies[key] = gsn.ie.pack_bearer_ctxt(16, context.utnl[i].uid, 0, 0, \
                                    gsn.ie.pack_f_teid_v4(S58_PGW_U, context.utnl[i].ul_teid, \
                                    int(ipaddr.IPAddress(context.utnl[i].ul_ip))), 0, 0)
    elif msg_type == "GTP_CREATE_SESS_REQ_S4":
        ies = gsn.gtp.create_sess_req_s4()
        ies["GTPIE_IMSI"] = pack("!Q", context.imsi)
        ies["GTPIE_F_TEID"] = gsn.ie.pack_f_teid_v4(S4_SGSN_C, context.ctnl.dl_teid, \
                                    int(ipaddr.IPAddress(context.ctnl.dl_ip)))
        ies["GTPIE_F_TEID_1_INS"] = gsn.ie.pack_f_teid_v4(S58_PGW_C, 0x1, int(ipaddr.IPAddress("3.0.0.5")))
        ies["GTPIE_APN"] = pack("!B%ds"%len(context.apn), len(context.apn), context.apn)
        for i in range(0, context.utnl_num):
            key = "GTPIE_BEAR_CTXT[%d]"%i
            ies[key] = gsn.ie.pack_bearer_ctxt(0, context.utnl[i].uid, 0, 0, \
                                    gsn.ie.pack_f_teid_v4(S4_SGSN_U, context.utnl[i].dl_teid, \
                                    int(ipaddr.IPAddress(context.utnl[i].dl_ip))), 0, 0)
    elif msg_type == "GTP_CREATE_SESS_RSP_S4":
        ies = gsn.gtp.create_sess_rsp_s4()
        ies["GTPIE_F_TEID"] = gsn.ie.pack_f_teid_v4(S4_SGSN_C, context.ctnl.ul_teid, \
                                    int(ipaddr.IPAddress(context.ctnl.ul_ip)))
        ies["GTPIE_F_TEID_1_INS"] = gsn.ie.pack_f_teid_v4(S4_SGW_C, context.ctnl.ul_teid, \
                                    int(ipaddr.IPAddress(context.ctnl.ul_ip)))
        ies["GTPIE_PAA"] = gsn.ie.pack_paa(int(ipaddr.IPAddress(context.ue_ip)))
        for i in range(0, context.utnl_num):
            key = "GTPIE_BEAR_CTXT[%d]"%i
            ies[key] = gsn.ie.pack_bearer_ctxt(16, context.utnl[i].uid, 0, 0, \
                                    gsn.ie.pack_f_teid_v4(S4_SGW_U, context.utnl[i].ul_teid, \
                                    int(ipaddr.IPAddress(context.utnl[i].ul_ip))), 0, 0)
    elif msg_type == "GTP_CREATE_BEAR_REQ":
        ies = gsn.gtp.create_bear_req()
        ies["GTPIE_EBI"] = pack("!B", context.pri_uid)
        for i in range(uidx, context.utnl_num):
            key = "GTPIE_BEAR_CTXT[%d]"%i
            ies[key] = gsn.ie.pack_bearer_ctxt(0, context.utnl[i].uid, 0, \
                                    gsn.ie.pack_f_teid_v4(S58_PGW_U, context.utnl[i].ul_teid, \
                                    int(ipaddr.IPAddress(context.utnl[i].ul_ip))))
    elif msg_type == "GTP_CREATE_BEAR_RSP":
        ies = gsn.gtp.create_bear_rsp()
        for i in range(uidx, context.utnl_num):
            key = "GTPIE_BEAR_CTXT[%d]"%i
            ies[key] = gsn.ie.pack_bearer_ctxt(16, context.utnl[i].uid, 0, 0, \
                                    gsn.ie.pack_f_teid_v4(S58_SGW_U, context.utnl[i].dl_teid, \
                                    int(ipaddr.IPAddress(context.utnl[i].dl_ip))),\
                                    gsn.ie.pack_f_teid_v4(S58_PGW_U, context.utnl[i].ul_teid, \
                                    int(ipaddr.IPAddress(context.utnl[i].ul_ip))))
    elif msg_type == "GTP_MODIFY_BEAR_REQ":
        ies = gsn.gtp.modify_bear_req()
        ies["GTPIE_F_TEID"] = gsn.ie.pack_f_teid_v4(S58_SGW_C, context.ctnl.dl_teid, \
                                                    int(ipaddr.IPAddress(context.ctnl.dl_ip)))
        for i in range(0, context.utnl_num):
            key = "GTPIE_BEAR_CTXT[%d]"%i
            ies[key] = gsn.ie.pack_bearer_ctxt(0, context.utnl[i].uid, 0, \
                                    gsn.ie.pack_f_teid_v4(S58_SGW_U, context.utnl[i].dl_teid, \
                                    int(ipaddr.IPAddress(context.utnl[i].dl_ip))))
    elif msg_type == "GTP_MODIFY_BEAR_RSP":
        ies = gsn.gtp.modify_bear_rsp()
        ies["GTPIE_EBI"] = pack("!B", context.pri_uid)
        for i in range(0, context.utnl_num):
            key = "GTPIE_BEAR_CTXT[%d]"%i
            ies[key] = gsn.ie.pack_bearer_ctxt(16, context.utnl[i].uid)
    elif msg_type == "GTP_DELETE_SESS_REQ":
        ies = gsn.gtp.delete_sess_req()
        ies["GTPIE_EBI"] = pack("!B", context.pri_uid)
    elif msg_type == "GTP_DELETE_SESS_RSP":
        ies = gsn.gtp.delete_sess_rsp()
    elif msg_type == "GTP_DELETE_BEAR_REQ":
        ies = gsn.gtp.delete_bear_req()
        ies["GTPIE_EBI"] = pack("!B", context.pri_uid)
    elif msg_type == "GTP_DELETE_BEAR_RSP":
        ies = gsn.gtp.delete_bear_rsp()
        ies["GTPIE_BEAR_CTXT"] = self.ie.pack_bearer_del(context.utnl[uidx].uid, 16)
    elif msg_type == "GTP_SGSN_CONTEXT_REQ":
        ies = gsn.gtp.context_req()
        ies["GTPIE_IMSI"] = context.imsi
        ies["GTPIE_F_TEID"] = self.ie.pack_f_teid_v4(s_gtp.S4_SGSN_C, context.fwd_ctnl.dl_teid, \
                                        int(ipaddr.IPAddress(context.fwd_ctnl.dl_ip))) # new MME/SGSN control teid & ip
    elif msg_type == "GTP_SGSN_CONTEXT_RSP":
        ies = gsn.gtp.context_rsp()
        ies["GTPIE_IMSI"] = context.imsi
        ies["GTPIE_F_TEID"] = self.ie.pack_f_teid_v4(s_gtp.S4_SGSN_C, context.fwd_ctnl.ul_teid, \
                                        int(ipaddr.IPAddress(context.fwd_ctnl.ul_ip)))           # old MME/SGSN control teid & ip
    elif msg_type == "GTP_SGSN_CONTEXT_ACK":
        ies = gsn.gtp.context_ack()
        ies["GTPIE_CAUSE"] = pack("!B", 16)
        ies["GTPIE_INDICAT"] = pack("!BB", 0x01, 0x00)
    elif msg_type == "GTP_ECHO_REQ":
        ies = gsn.gtp.echo_req()
        ies["GTPIE_RECOVERY"] = gsn.restart_cnt
    elif msg_type == "GTP_ECHO_RSP":
        ies = gsn.gtp.echo_rsp()
        ies["GTPIE_RECOVERY"] = gsn.restart_cnt
    else:
        return 0
    return ies

def get_gtp_ies(msg_type, gsn, context = 0, uidx = 0):
    ies = ""
    if gsn.ver == GTP_V0:
        ies = get_gtp_ies_v0(msg_type, gsn, context)
    elif gsn.ver == GTP_V1 or gsn.ver == GTP_V1_U:
        ies = get_gtp_ies_v1(msg_type, gsn, context, uidx)
    elif gsn.ver == GTP_V2:
        ies = get_gtp_ies_v2(msg_type, gsn, context, uidx)
    return ies

def get_comm_pdu_buf(inner_src_ip, inner_dst_ip, inner_src_port, inner_dst_port, buf_len):
    inner_ip = s_ip.S_Ip()
    inner_udp = s_udp.S_Udp()
    data_buffer = ""  
  
    for buf_num in range(0, buf_len):
        data_buffer += pack("!H", 0x1)
    
    inner_ip.set_proto(s_ip.udp)
    inner_ip.set_ip(inner_src_ip, inner_dst_ip)
    inner_udp.set_port(inner_src_port, inner_dst_port)
    inner_udp.set_payload(data_buffer)
    inner_ip.set_payload(inner_udp.to_buffer())
    return inner_ip.to_buffer()

def set_gsn_gtp_header(gsn, msg_type, seq, teid, tid = 0):
    if gsn.ver == GTP_V0:
        gsn.gtp.set_flabel(teid)
        if tid:
            gsn.gtp.set_tid(tid)
    else:
        gsn.gtp.set_teid(teid)
    gsn.gtp.set_msg_type(msg_type)
    gsn.gtp.set_seq(seq)

class S_GtpScenario(object):
    def __init__(self, log):
        tester_cfg = s_cfg.Tester()
        dut_cfg = s_cfg.Dut()
        s_cfg.load(s_gtp_dut.gear_cfg_file, [tester_cfg, dut_cfg])
        s_cfg.print_topology(log, tester_cfg, dut_cfg)
        
        self.links = [s_eth.S_Eth(), s_eth.S_Eth()]
        self.links[0].set_mac(tester_cfg.net_ifs[0].mac, dut_cfg.net_ifs[0].mac)
        self.links[0].set_inf(tester_cfg.net_ifs[0].if_name)
        self.links[1].set_mac(tester_cfg.net_ifs[1].mac, dut_cfg.net_ifs[1].mac)
        self.links[1].set_inf(tester_cfg.net_ifs[1].if_name)
        self.links[0].dump()
        self.links[1].dump() 
                
        self.daemon = s_socket_daemon.S_Socket_Daemon(self.links, s_ip.udp)
        self.daemon.startup()

        self.dut = s_gtp_dut.Gtp_Dut(dut_cfg.mgt_if.ip, dut_cfg.mgt_if.port, log)
        if not self.dut.login(dut_cfg.mgt_if.user, dut_cfg.mgt_if.passwd):
            print >> log, "fail to login DUT[%s]."%dut_cfg.mgt_if.ip
        self.dut.spc_list = dut_cfg.spc_list

        self.log = log
        self.seq = 1

        self.context = s_tunnel.S_GtpCtxt()
    def gsn_init(self, gsn, dst_ip):
        gsn.set_daemon(self.daemon)
        gsn.ip.set_ip(gsn.ip_addr, dst_ip)
        if gsn.ver == GTP_V0:
           gsn.udp.set_port(s_gtp.GTP0_PORT, s_gtp.GTP0_PORT)
           gsn.gtp = s_gtp.S_Gtpv0()
           gsn.ie = s_gtp.S_Gtpiev0()
        elif gsn.ver == GTP_V1:
           gsn.udp.set_port(s_gtp.GTP1C_PORT, s_gtp.GTP1C_PORT)
           gsn.gtp = s_gtp.S_Gtpv1()
           gsn.ie = s_gtp.S_Gtpiev1()
        elif gsn.ver == GTP_V1_U:
           gsn.udp.set_port(s_gtp.GTP1U_PORT, s_gtp.GTP1U_PORT)
           gsn.gtp = s_gtp.S_Gtpv1()
           gsn.ie = s_gtp.S_Gtpiev1()
        else:
           gsn.udp.set_port(s_gtp.GTP1C_PORT, s_gtp.GTP1C_PORT)
           gsn.gtp = s_gtp.S_Gtpv2()
           gsn.ie = s_gtp.S_Gtpiev2()
                   
    def gsn_send(self, src_gsn, dst_gsn, to_pcap = False):
        if not src_gsn.send(src_gsn.msg, to_pcap = to_pcap):
            return False
        if not dst_gsn.recv():
            return False
        return True
                
    def gsn_send_gpdu(self, src_gsn, dst_gsn, to_pcap = False):
        if not src_gsn.send_gpdu(src_gsn.msg, to_pcap):
            return False
        if not dst_gsn.recv():
            return False
        return True

    def gsn_send_pg_msg(self, src_gsn, dst_gsn, pg_msg, to_pcap = False):
        if not src_gsn.send(src_gsn.msg, pg_msg, to_pcap):
            return False
        if not dst_gsn.recv():
            return False
        return True
                
    def get_context(self):
        self.dut.enter_cli()
        info = self.dut.do_cli("show security gprs gtp tunnel | display xml | no-more")
        context_list = s_tunnel.parse(info)
        self.dut.exit_cli()
        return context_list
    
    def clear_box(self):
        self.dut.clear_env()
        self.context.clean_up()

class S_ScenarioComm(S_GtpScenario):
    def create_context(self, src_gsn, dst_gsn, ggsn_pool = False):
        if not ggsn_pool:
            self.gsn_init(src_gsn, dst_gsn.ip_addr)
        else:
            self.gsn_init(src_gsn, dst_gsn.ip_addr2)
        self.gsn_init(dst_gsn, src_gsn.ip_addr)

        if src_gsn.ver == GTP_V2:
            req_msg_type = "GTP_CREATE_SESS_REQ"
            rsp_msg_type = "GTP_CREATE_SESS_RSP"
        else:
            req_msg_type = "GTP_CREATE_PDP_REQ"
            rsp_msg_type = "GTP_CREATE_PDP_RSP"

        set_gsn_gtp_header(src_gsn, req_msg_type, src_gsn.seq, 0, self.context.tid)
        src_gsn.msg = get_gtp_ies(req_msg_type, src_gsn, self.context, 0)

        set_gsn_gtp_header(dst_gsn, rsp_msg_type, src_gsn.seq, self.context.ctnl.dl_teid, self.context.tid)
        dst_gsn.msg = get_gtp_ies(rsp_msg_type, dst_gsn, self.context, 0)

        print >> self.log, "---create pdp req---"
        if not self.gsn_send(src_gsn, dst_gsn):
            return False
        print >> self.log, "....verifying [ok]"

        print >> self.log, "---create pdp rsp---"
        if not self.gsn_send(dst_gsn, src_gsn):
            return False
        print >> self.log, "....verifying [ok]"

        # verify tunnels on dut
        time.sleep(10)
        print >> self.log, "---check tunnel state---"
        context_list = self.get_context()      
        if len(context_list) and \
           s_tunnel.context_compare(self.context, context_list[0]):
            print >> self.log, "....verifying [ok]"
        else:
            return False

        return True

    def create_sec_context(self, src_gsn, dst_gsn):
        self.gsn_init(src_gsn, dst_gsn.ip_addr)
        self.gsn_init(dst_gsn, src_gsn.ip_addr)

        uidx = self.context.utnl_num - 1
        set_gsn_gtp_header(src_gsn, "GTP_CREATE_PDP_REQ", src_gsn.seq, self.context.ctnl.ul_teid)
        src_gsn.msg = get_gtp_ies("GTP_CREATE_SEC_PDP_REQ", src_gsn, self.context, uidx)

        set_gsn_gtp_header(dst_gsn, "GTP_CREATE_PDP_RSP", src_gsn.seq, self.context.ctnl.dl_teid)
        dst_gsn.msg = get_gtp_ies("GTP_CREATE_SEC_PDP_RSP", dst_gsn, self.context, uidx)

        print >> self.log, "---create secondary pdp req---"
        if not self.gsn_send(src_gsn, dst_gsn):
            return False
        print >> self.log, "....verifying [ok]"

        print >> self.log, "---create secondary pdp rsp---"
        if not self.gsn_send(dst_gsn, src_gsn):
            return False
        print >> self.log, "....verifying [ok]"

        time.sleep(5)
        # verify tunnels on dut
        print >> self.log, "---check tunnel state---"
        context_list = self.get_context()
        if len(context_list) and \
           s_tunnel.context_compare(self.context, context_list[0]):
            print >> self.log, "....verifying [ok]"
        else:
            return False

        return True

    def update_context(self, src_gsn, dst_gsn, uidx = 0):
        self.gsn_init(src_gsn, dst_gsn.ip_addr)
        self.gsn_init(dst_gsn, src_gsn.ip_addr)

        if src_gsn.ver == GTP_V2:
            req_msg_type = "GTP_MODIFY_BEAR_REQ"
            rsp_msg_type = "GTP_MODIFY_BEAR_RSP"
        else:
            req_msg_type = "GTP_UPDATE_PDP_REQ"
            rsp_msg_type = "GTP_UPDATE_PDP_RSP"

        set_gsn_gtp_header(src_gsn, req_msg_type, src_gsn.seq, self.context.ctnl.ul_teid)
        src_gsn.msg = get_gtp_ies(req_msg_type, src_gsn, self.context, uidx)

        set_gsn_gtp_header(dst_gsn, rsp_msg_type, src_gsn.seq, self.context.ctnl.dl_teid)
        dst_gsn.msg = get_gtp_ies(rsp_msg_type, dst_gsn, self.context, uidx)

        print >> self.log, "---update pdp req---"
        if not self.gsn_send(src_gsn, dst_gsn):
            return False
        print >> self.log, "....verifying [ok]"

        print >> self.log, "---update pdp rsp---"
        if not self.gsn_send(dst_gsn, src_gsn):
            return False
        print >> self.log, "....verifying [ok]"

        # verify tunnels on dut
        print >> self.log, "---check tunnel state---"
        context_list = self.get_context()
        if len(context_list) and \
           s_tunnel.context_compare(self.context, context_list[0]):
            print >> self.log, "....verifying [ok]"
        else:
            return False

        return True

    def delete_context(self, src_gsn, dst_gsn, uidx = 0):
        self.gsn_init(src_gsn, dst_gsn.ip_addr)
        self.gsn_init(dst_gsn, src_gsn.ip_addr)

        if src_gsn.ver == GTP_V2:
            req_msg_type = "GTP_DELETE_SESS_REQ"
            rsp_msg_type = "GTP_DELETE_SESS_RSP"
        else:
            req_msg_type = "GTP_DELETE_PDP_REQ"
            rsp_msg_type = "GTP_DELETE_PDP_RSP"

        set_gsn_gtp_header(src_gsn, req_msg_type, src_gsn.seq, self.context.ctnl.ul_teid)
        src_gsn.msg = get_gtp_ies(req_msg_type, src_gsn, self.context, uidx)

        set_gsn_gtp_header(dst_gsn, rsp_msg_type, src_gsn.seq, self.context.ctnl.dl_teid)
        dst_gsn.msg = get_gtp_ies(rsp_msg_type, dst_gsn, self.context, uidx)

        print >> self.log, "---delete pdp req---"
        if not self.gsn_send(src_gsn, dst_gsn):
            return False
        print >> self.log, "....verifying [ok]"

        print >> self.log, "---delete pdp rsp---"
        if not self.gsn_send(dst_gsn, src_gsn):
            return False
        print >> self.log, "....verifying [ok]"

        print >> self.log, "---check tunnel state---"
        self.context.del_utnl(uidx)
        context_list = self.get_context()
        if len(context_list):
            if s_tunnel.context_compare(self.context, context_list[0]):
                print >> self.log, "....verifying [ok]"
            else:
                return False
        else:
            print >> self.log, "....verifying [ok]"

        return True

    def echo_msg(self, src_gsn, dst_gsn):
        self.gsn_init(src_gsn, dst_gsn.ip_addr)
        self.gsn_init(dst_gsn, src_gsn.ip_addr)

        set_gsn_gtp_header(src_gsn, "GTP_ECHO_REQ", src_gsn.seq, 0)
        if src_gsn.ver == GTP_V0:
            src_gsn.gtp.set_tid(0)
        src_gsn.msg = get_gtp_ies("GTP_ECHO_REQ", src_gsn)

        set_gsn_gtp_header(dst_gsn, "GTP_ECHO_RSP", src_gsn.seq, 0)
        if dst_gsn.ver == GTP_V0:
            dst_gsn.gtp.set_tid(0)
        dst_gsn.msg = get_gtp_ies("GTP_ECHO_RSP", dst_gsn)

        print >> self.log, "---echo req---"
        if not self.gsn_send(src_gsn, dst_gsn): 
            return False
        print >> self.log, "....verifying [ok]"

        print >> self.log, "---echo rsp---"
        if not self.gsn_send(dst_gsn, src_gsn):
            return False
        print >> self.log, "....verifying [ok]"
                
        return True

    def send_data_traffic(self, sgsn, ggsn, uidx, pkt_num = 1, ueip = "1.1.1.1", pkt_seq = 0, pkt_len = 512, port = 80):
        self.gsn_init(sgsn, ggsn.ip_addr)
        self.gsn_init(ggsn, sgsn.ip_addr)

        if pkt_seq == 0:
            seq = sgsn.pdu_seq
        else:
            seq = pkt_seq
        
        for i in range(0, pkt_num):
            set_gsn_gtp_header(sgsn, "GTP_GPDU", seq + i, self.context.utnl[uidx].ul_teid)
            sgsn.msg = get_comm_pdu_buf(ueip, "2.2.2.2", port, port, pkt_len)

            set_gsn_gtp_header(ggsn, "GTP_GPDU", seq + i, self.context.utnl[uidx].dl_teid)
            ggsn.msg = get_comm_pdu_buf("2.2.2.2", ueip, port, port, pkt_len)

            print >> self.log, "---uplink data traffic---"
            if not self.gsn_send_gpdu(sgsn, ggsn):
                return False
            print >> self.log, "....verifying [ok]"

            print >> self.log, "---downlink data traffic---"
            if not self.gsn_send_gpdu(ggsn, sgsn):
                return False
            print >> self.log, "....verifying [ok]"

        return True
                
class S_ScenarioHandover(S_GtpScenario):
    context_list = []
    def context_handover(self, sgsn_old, sgsn_new):
        if sgsn_old.ip_addr2 != "":
            self.gsn_init(sgsn_new, sgsn_old.ip_addr2)
        else:
            self.gsn_init(sgsn_new, sgsn_old.ip_addr)
        self.gsn_init(sgsn_old, sgsn_new.ip_addr)
                
        set_gsn_gtp_msg(sgsn_new, "GTP_SGSN_CONTEXT_REQ", self.seq, context_list = self.context_list)          
        print >> self.log, "---sgsn context req---"
        if not self.gsn_send(sgsn_new, sgsn_old):
            return False
        print >> self.log, "....verifying [ok]"

        set_gsn_gtp_msg(sgsn_old, "GTP_SGSN_CONTEXT_RSP", self.seq, context_list = self.context_list, teid = self.context_list[0].fwd_ctnl.dl_teid)         
        print >> self.log, "---sgsn context rsp---"
        if not self.gsn_send(sgsn_old, sgsn_new):
            return False
        print >> self.log, "....verifying [ok]"

        set_gsn_gtp_msg(sgsn_new, "GTP_SGSN_CONTEXT_ACK", self.seq, context_list = self.context_list, teid = self.context_list[0].fwd_ctnl.ul_teid)         
        print >> self.log, "---sgsn context ack---"
        if not self.gsn_send(sgsn_new, sgsn_old):
            return False
        print >> self.log, "....verifying [ok]"

        print >> self.log, "---check tunnel state---"
        context_list = self.get_context()
        if len(context_list) and \
           s_tunnel.context_list_compare(self.context_list, context_list):
            print >> self.log, "....verifying [ok]"
        else:
            return False
                
        self.seq += 1
        return True
                
    def fwd_reloc_handover(self, sgsn_old, sgsn_new):
        self.gsn_init(sgsn_new, sgsn_old.ip_addr)
        self.gsn_init(sgsn_old, sgsn_new.ip_addr)
                
        set_gsn_gtp_msg(sgsn_old, "GTP_FWD_RELOC_REQ", self.context_list, self.seq)             
        print >> self.log, "---forward relocation req---"
        if not self.gsn_send(src_gsn, dst_gsn):
            return False
        print >> self.log, "....verifying [ok]"

        set_gsn_gtp_msg(sgsn_old, "GTP_SGSN_CONTEXT_RSP", self.context_list, self.seq, teid = 0)         
        print >> self.log, "---forward relocation rsp---"
        if not self.gsn_send(src_gsn, dst_gsn):
            return False
        print >> self.log, "....verifying [ok]"

        print >> self.log, "---check tunnel state---"
        context_list = self.get_context()
        if len(context_list) and \
            s_tunnel.context_list_compare(self.context_list, context_list):
            print >> self.log, "....verifying [ok]"
        else:
            return False
                
        self.seq += 1
        return True     
        
def set_gsn_gtp_msg(gsn, msg_type, seq, context = 0, context_list = [], uid = 0, teid = 0, tid = 0):
    if gsn.ver == GTP_V0:
        gsn.gtp.set_flabel(teid)
        if tid:
            gsn.gtp.set_tid(tid)
    else:
        gsn.gtp.set_teid(teid)
    gsn.gtp.set_msg_type(msg_type)
    gsn.gtp.set_seq(seq)
        
    if msg_type == "GTP_GPDU":
        return
                
    if gsn.ver == GTP_V0:
        gsn.msg = get_gtp_ies_v0(msg_type, gsn, context, context_list, uid)
    elif gsn.ver == GTP_V1:
        gsn.msg = get_gtp_ies_v1(msg_type, gsn, context, context_list, uid)
    elif gsn.ver == GTP_V2:
        gsn.msg = get_gtp_ies_v2(msg_type, gsn, context, context_list, uid)   

if "__main__" == __name__:
    log = s_base_toolkit.S_Log(datetime.datetime.now().strftime("log/gtp-%Y-%m-%d_%H-%M-%S.log"))
    pc_cfg = s_cfg.Tester()
    dut_cfg = s_cfg.Dut()
    s_cfg.load("vm03-mud-sl.xml", [pc_cfg, dut_cfg])
    s_cfg.print_topology(log, pc_cfg, dut_cfg)

    links = [s_eth.S_Eth(), s_eth.S_Eth()]
    links[0].set_mac(pc_cfg.net_ifs[0].mac, dut_cfg.net_ifs[0].mac)
    links[0].set_inf(pc_cfg.net_ifs[0].if_name)
    links[1].set_mac(pc_cfg.net_ifs[1].mac, dut_cfg.net_ifs[1].mac)
    links[1].set_inf(pc_cfg.net_ifs[1].if_name)
    links[0].dump()
    links[1].dump()

    sgsn = s_gsn.S_Gsn(links[0])
    ggsn = s_gsn.S_Gsn(links[1])
    sgsn.ip_addr = "20.0.1.16"
    sgsn.ver = GTP_V1

    ggsn.ip_addr = "20.1.11.16"
    ggsn.ver = GTP_V1
    
    sd = s_socket_daemon.S_Socket_Daemon(links, s_ip.udp)
    sd.startup()
    time.sleep(1)

    scenario = S_ScenarioNormal(sd, log)

    #scenario.context = s_tunnel.S_GtpCtxt()
    scenario.context.ctnl.dl_teid = 0x1
    scenario.context.ctnl.dl_ip = "20.0.11.1"
    scenario.context.ctnl.ul_teid = 0x1
    scenario.context.ctnl.ul_ip = "20.1.11.1"

    scenario.context.utnl[0].dl_teid = 0x1
    scenario.context.utnl[0].dl_ip = "20.0.11.1"
    scenario.context.utnl[0].ul_teid = 0x1
    scenario.context.utnl[0].ul_ip = "20.1.11.1"
    scenario.context.utnl[0].uid = 5
    if not scenario.create_context(sgsn, ggsn):
        print "**FAILURE**"

    # show tunnel 

    # update tunnel
    new_sgsn = s_gsn.S_Gsn(links[0])
    new_sgsn.ip_addr = "20.0.1.18"
    new_sgsn.ver = GTP_V1

    new_context = s_tunnel.S_GtpCtxt()
    new_context.ctnl.dl_teid = 0x2
    new_context.ctnl.dl_ip = "20.0.11.2"
    new_context.ctnl.ul_teid = scenario.context.ctnl.ul_teid 
    new_context.ctnl.ul_ip   = scenario.context.ctnl.ul_ip 

    new_context.utnl[0].dl_teid = 0x2
    new_context.utnl[0].dl_ip = "20.0.11.2"
    new_context.utnl[0].ul_teid = 0x2
    new_context.utnl[0].ul_ip = "20.1.11.2"
    new_context.utnl[0].uid = 5    

    if not scenario.update_context(new_sgsn, ggsn, new_context):
        print "**FAILURE**"

    # show tunnel 

    if not scenario.delete_context(new_sgsn, ggsn, scenario.context, 0):
        print "**FAILURE**"

    # show tunnel 

