import string, glob, os, sys
import inspect
from ctypes import *

class S_Socket:
    def __init__(self):
        script_path = os.path.abspath(os.path.dirname(inspect.getfile(inspect.currentframe())))
        self.dll = CDLL(script_path + "/s_socket/s_socket.so")

        # open socket
        self.dll.s_open_socket.argtypes = [c_char_p, c_char_p]
        self.dll.s_open_socket.restypes = [c_int]

        # close socket
        self.dll.s_close_socket.argtypes = [c_int]

        # send packet
        self.dll.s_send_packet.argtypes = [c_int, c_char_p, c_uint]
        self.dll.s_send_packet.restypes = [c_int]

        # recv packet
        self.dll.s_recv_packet.argtypes = [c_int, c_char_p, c_uint]
        self.dll.s_recv_packet.restypes = [c_int]

        # set filter
        self.dll.s_set_filter.argtypes = [c_int, c_char_p, c_uint, c_uint]
        self.dll.s_set_filter.restypes = [c_int]

        # set timeout
        self.dll.s_set_recv_timeout.argtypes = [c_int, c_uint]
        self.dll.s_set_recv_timeout.restypes = [c_int]


        self.s = c_int(-1)
        self.RECV_BUFF = create_string_buffer(4096)

    def set_filter(self, mac, eth_type, proto):
        return self.dll.s_set_filter(self.s, mac, eth_type, proto)

    def set_recv_timeout(self, timeout):
        return self.dll.s_set_recv_timeout(self.s, timeout)


    def open(self, dev):
        err_buf = create_string_buffer(1024)
        self.s = self.dll.s_open_socket(dev, err_buf)

        if self.s < 0:
            print "Socket %s open failure: %s"%(dev, string_at(err_buf, 1024))
            return False
        return True

    def close(self):
        self.dll.s_close_socket(self.s)
        self.s = c_int(-1)

    def send(self, buf):
        if self.s < 0:
            print "Bad socket"
            return False

        if self.dll.s_send_packet(self.s, buf, len(buf)) < 0:
            print "Packet send failure"
            return False
        return True

    def recv(self):
        if self.s < 0:
            print "Bad socket"
            return ""

        rlen = self.dll.s_recv_packet(self.s, self.RECV_BUFF, len(self.RECV_BUFF))

        if rlen <= 0:
            return ""
        return string_at(self.RECV_BUFF, rlen)



