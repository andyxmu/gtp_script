import string, glob, os
import datetime
import cStringIO
import ipaddr
from struct import *

# ip = "a.b.c.d"
def ip_str2b(str_ip):
    str_iplist = str_ip.split(".", 3)
    return pack("BBBB", 
            string.atoi(str_iplist[0], 10), 
            string.atoi(str_iplist[1], 10),
            string.atoi(str_iplist[2], 10),
            string.atoi(str_iplist[3], 10))

def ip_b2str(b):
    return "%d.%d.%d.%d"%(ord(b[0]), ord(b[1]), ord(b[2]), ord(b[3]))

# mac= 00:00:00:00:00:00
def mac_str2b(str_mac):
    str_maclist = str_mac.split(":", 5)
    return pack("BBBBBB", 
            string.atoi(str_maclist[0], 16),
            string.atoi(str_maclist[1], 16),
            string.atoi(str_maclist[2], 16),
            string.atoi(str_maclist[3], 16),
            string.atoi(str_maclist[4], 16),
            string.atoi(str_maclist[5], 16))

def mac_b2str(mac):
    return "%02x:%02x:%02x:%02x:%02x:%02x"%(ord(mac[0]), ord(mac[1]), ord(mac[2]), ord(mac[3]), ord(mac[4]), ord(mac[5]))

def mac_b2str_10(mac):
    return "%03d:%03d:%03d:%03d:%03d:%03d"%(ord(mac[0]), ord(mac[1]), ord(mac[2]), ord(mac[3]), ord(mac[4]), ord(mac[5]))

def buff2pcap(data, file_name):
    t2p = "text2pcap"
    fout = file(file_name + ".txt", 'w')
    print_buff2txt(data, fout)
    fout.close()
    os.system("%s %s.txt %s.pcap"%(t2p, file_name, file_name))
    os.remove("%s.txt"%file_name)

def text2pcap(file_name):
    t2p = "text2pcap"
    os.system("%s %s %s.pcap"%(t2p, file_name, file_name))

def print_buff2txt(data_, fout):
    len_total = len(data_)
    print >> fout, "000000"

    if not (len_total % 16):
        data_track = range(len_total/16)

        len_track = len_total/16
    else:
        data_track = range(len_total/16 + 1)
        len_track = len_total/16 + 1
   
    for i in range (0, len_track):
        data_track[i] = "%04x" %(0 + 16*i)

    for i in range(0, len_track):
        print >> fout, data_track[i],
        for j in range(0, 16):
            if (j+16*i) < len_total:
                print  >> fout, "%02x" %(ord(data_[j+16*i])),
        print >> fout, '  '
    print  >> fout, ''

# ip6 = 
# style1: "a:b:c:d:e:f:g:h"
# style2: "a:b::f:g:h"
# style3: "a:b:c:d:e:f:1.1.1.1"
# style4: "a:b::e:f:1.1.1.1"
# style5: "::1.1.1.1"
# style6: "::"
def ip6_str2b(str_ip6):
    return ipaddr.IPv6Address(str_ip6).packed

def ip6_b2str(b):
    return repr(ipaddr.IPv6Address(ipaddr.Bytes(b)))

def main():
    #a = 1234

    #print hton(i2b(a, 4))
    #print i2b(a, 1)
    #print b2i(i2b(a, 4))

    #ip = "1.2.3.4"
    #ip_num = ip_str2i(ip)
    #print ip_num
    #print i2b(ip_num, 4)

    #print_data2txt(i2b(ip_num, 4), "test")

    # ip6 = 
    # style1: "a:b:c:d:e:f:g:h"
    # style2: "a:b::f:g:h"
    # style3: "a:b:c:d:e:f:1.1.1.1"
    # style4: "a:b::e:f:1.1.1.1"
    # style5: "::1.1.1.1"
    # style6: "::"
    buff = ip6_str2b("1:2:a:b:c:d:e:f")
    print repr(buff)

    buff = ip6_str2b("1:2::d:e:f")
    print repr(buff)

    buff = ip6_str2b("a:b:c:d:e:f:1.1.1.1")
    print repr(buff)

    buff = ip6_str2b("a:b::e:f:1.1.1.1")
    print repr(buff)
    print ip6_b2str(buff)

    buff = ip6_str2b("a:0:0:d::1.1.1.1")
    print repr(buff)
    print ip6_b2str(buff)


    buff = ip6_str2b("::1.1.1.1")
    print repr(buff)
    print ip6_b2str(buff)

    buff = ip6_str2b("::")
    print repr(buff)
    

if "__main__" == __name__:
    main()
