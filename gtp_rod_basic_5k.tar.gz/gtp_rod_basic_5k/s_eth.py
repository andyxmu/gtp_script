import string, glob, os
import s_net_toolkit as s_net
from struct import *

IPv4 = 0x0800
IPv6 = 0x86dd

class S_Eth:
    def __init__(self):
        self.set_mac("0x00:0x00:0x00:0x00:0x00:0x00", "0x00:0x00:0x00:0x00:0x00:0x00")
        self.set_v4()
        self.inf = "ethx" # eg. eth1, eth2 ... ethx
        self.payload = ""

    def to_buffer(self):
        return self.dst_mac + self.src_mac + self.eth_type + self.payload

    def set_payload(self, payload):
        if 0x60 == ord(payload[0]) & 0xF0:
            self.set_v6()
        elif 0x40 == ord(payload[0]) & 0xF0:
            self.set_v4()
        else:
            raise IOError("It's not a v4 or v6 IP packet.")
        self.payload = payload

    def set_mac(self, src, dst):
        self.src_mac = s_net.mac_str2b(src)
        self.dst_mac = s_net.mac_str2b(dst) 

    def set_v4(self):
        self.eth_type = pack("!H", IPv4)

    def set_v6(self):
        self.eth_type = pack("!H", IPv6)

    def set_inf(self, inf):
        self.inf = inf

    def get_inf(self):
        return self.inf

    def from_buffer(self, b):
        self.dst_mac = b[:6]
        self.src_mac = b[6:12]
        self.eth_type = b[12:14]
        return b[14:]

    def dump(self):
        print "**Eth**"
        print "|-->dst_mac[%s],src_mac[%s],type[%s]"% \
                (s_net.mac_b2str(self.dst_mac), s_net.mac_b2str(self.src_mac), \
                repr(self.eth_type))

def main():
    eth = S_Eth()
    eth.set_v6()
    eth.set_mac("0x00:0x10:0xdb:0xb9:0x8f:0x65", "0x00:0x50:0x56:0x97:0x17:0x7e")
    eth.dump()
    print eth.to_buffer()


if "__main__" == __name__:
    main()
