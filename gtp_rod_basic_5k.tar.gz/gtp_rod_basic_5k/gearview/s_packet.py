import struct

class S_Packet(object):
    def __init__(self):
        self.out_if = 0
        self.pkt_len = 0
        self.pkt_data = ""

    def read(self, ifile):
        self.out_if = struct.unpack("B", ifile.read(1))[0]
        self.pkt_len = struct.unpack("I", ifile.read(4))[0]
        self.pkt_data = ifile.read(self.pkt_len)

    def dump(self):
        print self.pkt_len
