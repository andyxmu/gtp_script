import xml.etree.ElementTree as et

class S_Inf(object):
    def __init__(self):
        self.name = "if"
        self.mac = "4a:d7:05:0d:4a:00"
        self.ip = "192.168.1.1"

    @staticmethod
    def name():
        return "Inf"

    def from_xml(self, root):
        self.name = root.find("name").text
        self.mac = root.find("mac").text
        self.ip = root.find("ip-addr").text

    def dump(self):
        print "%s:"%S_Inf.name()
        print self.name
        print self.mac
        print self.ip
