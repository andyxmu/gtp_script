import sys
sys.path.append("../")
import s_common
from s_common import *

def read_string(ifile):
    str_len = struct.unpack("i", ifile.read(4))[0]
    return ifile.read(str_len)

if "__main__" == __name__:
    numbers = enum(ONE = 1, TWO = 2, THREE = 3)
    print numbers.ONE
    print numbers.TWO
    print numbers.THREE
