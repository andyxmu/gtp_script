import s_gearview_common
from s_gearview_common import *
import struct
import s_check_point

class S_Flow_Action(object):
    def __init__(self):
        self.name = "flow-action"
        self.cmd_type = 0
        self.CMD_TYPE = s_common.enum(CLI_CMD = 0, CFG_CMD = 1, SHELL_CMD = 2)
        self.cmd_type = self.CMD_TYPE.CLI_CMD
        self.cmd = "show"
        self.check_lst = []


    def read(self, ifile):
        self.check_lst = []
        self.name = s_common.read_string(ifile)
        self.cmd_type = struct.unpack("i", ifile.read(4))[0]
        self.cmd = s_common.read_string(ifile)

        sizeof_check_lst = struct.unpack("i", ifile.read(4))[0]
        for i in range(sizeof_check_lst):
            point = s_check_point.S_Check_Point()
            point.read(ifile)
            self.check_lst.append(point)

    def dump(self):
        print "%s <> %d <> %s"%(self.name, self.cmd_type, self.cmd)
        


if "__main__" == __name__:
    check_lst = []
    for i in range(10):
        check_lst.append(i)

    print check_lst
    f = open("", "rb") 
        
