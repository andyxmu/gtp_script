import s_gearview_common
from s_gearview_common import *
import struct

class S_Check_Point(object):
    def __init__(self):
        self.OP_TYPE = enum(EQUAL= 0, UNEQUAL = 1, GREATER_THAN = 2, LESS_THAN = 3, IN = 4)
        self.field = ""
        self.value = ""
        self.op = 0

    def read(self, ifile):
        self.field = read_string(ifile)
        self.op = struct.unpack("i", ifile.read(4))[0]
        self.value= read_string(ifile)
