import string 

class S_Endpoint(object):
    def __init__(self):
        self.ip = 0
        self.port = 0 

    def to_string(self):
        print "%s %d"%(self.ip, self.port)
        

class S_Wing(object):
    def __init__(self):
        self.src_ep = S_Endpoint()
        self.dst_ep = S_Endpoint()
        self.proto = 0

    @staticmethod
    def name():
        return "Wing"

    def read_ep(self, node, ep):
        ep.ip = string.atoi(node.find("ip").text, 10)
        ep.port = string.atoi(node.find("port").text, 10)

    def from_xml(self, root):
        self.read_ep(root.find("src-ep"), self.src_ep)
        self.read_ep(root.find("dst-ep"), self.dst_ep)
        self.proto = string.atoi(root.find("proto").text)

    def dump(self):
        print "src-ep:%s"%self.src_ep.to_string()
        print "dst-ep:%s"%self.dst_ep.to_string()
        print "proto:%d"%self.proto

class S_Session(object):
    def __init__(self):
        self.wing = [S_Wing(), S_Wing()]
        self.selected = False

    @staticmethod
    def name():
        return "Session"

    def from_xml(self, root):
        wings = root.findall(S_Wing.name())
        for i in range(len(wings)):
            self.wing[i].from_xml(wings[i])
        self.selected = ("TRUE" == root.find("Selected").text)
        
    def dump(self):
        print "wing0:"
        self.wing[0].dump()
        print "wing1:"
        self.wing[1].dump()
        print self.selected

