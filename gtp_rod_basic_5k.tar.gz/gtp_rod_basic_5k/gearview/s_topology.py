#!/usr/bin/python
import xml.etree.ElementTree as et
import s_dut_cfg, s_tester_cfg, s_inf

class S_Topology(object):
    def __init__(self):
        self.dut = s_dut_cfg.S_Dut_Cfg()
        self.tester = s_tester_cfg.S_Tester_Cfg()

    @staticmethod
    def name():
        return "Topology"

    def from_xml(self, root):
        self.dut.from_xml(root.find(s_dut_cfg.S_Dut_Cfg.name()))
        self.tester.from_xml(root.find(s_tester_cfg.S_Tester_Cfg.name()))

    def dump(self):
        self.tester.dump()
        self.dut.dump()

if "__main__" == __name__:
    topo = S_Topology()
    topo.from_xml("../../prj/a.xml")
    topo.dump()
