import s_inf
import xml.etree.ElementTree as et

class S_Tester_Cfg(object):
    def __init__(self):
        self.mgt = "10.0.0.1/22"
        self.username = "root"
        self.passwd = "12345"
        self.inf = [s_inf.S_Inf() for i in range(2)]

    @staticmethod
    def name():
        return "Tester"

    def from_xml(self, root):
        if None == root:
            return;

        self.mgt = root.find("mgt").text
        self.username = root.find("username").text
        self.passwd = root.find("passwd").text

        ifs = root.findall(s_inf.S_Inf.name())
        for i in range(len(ifs)):
            self.inf[i].from_xml(ifs[i])

    def dump(self):
        print S_Tester_Cfg.name() + ":"
        print self.mgt
        print self.username
        print self.passwd
        for i in range(len(self.inf)):
            print "%d"%i
            self.inf[i].dump()


