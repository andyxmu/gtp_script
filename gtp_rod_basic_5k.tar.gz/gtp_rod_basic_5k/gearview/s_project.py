import s_gearview_common, s_dut, s_tester, s_flow_action, s_packet
from s_gearview_common import *
import xml.etree.ElementTree as et
import s_topology as s_topo
import sys 
import s_session
import struct

class S_Project(object):
    def __init__(self):
        self.topo_cfg = s_topo.S_Topology() 
        self.session_lst = []
        self.action_lst = []
        self.ACTION_TYPE = \
            enum(PACKET = 0, FLOW_ACTION = 1)

    def read(self, filename):
        tree = et.ElementTree()
        root = tree.parse(filename)

        node = root.find(s_topo.S_Topology.name())

        if None == node:
            return

        self.topo_cfg.from_xml(node)

        sessions = root.findall(s_session.S_Session.name())

        for s in sessions:
            session = s_session.S_Session()
            session.from_xml(s)
            self.session_lst.append(session)

        ifile = open(filename + ".flow", "rb")
        num = struct.unpack("I", ifile.read(4))[0]
        for i in range(num):
            t = struct.unpack("H", ifile.read(2))[0]

            if self.ACTION_TYPE.PACKET == t:
                action = s_packet.S_Packet()
                action.read(ifile)
                self.action_lst.append(action)
            elif self.ACTION_TYPE.FLOW_ACTION == t:
                action = s_flow_action.S_Flow_Action()
                action.read(ifile)
                self.action_lst.append(action)

    def dump(self):
        self.topo_cfg.dump()

        for s in self.session_lst:
            s.dump()

        for a in self.action_lst:
            a.dump()

            

if "__main__" == __name__:
    project = S_Project()
    project.read("../../prj/test.xml")
    project.dump()
