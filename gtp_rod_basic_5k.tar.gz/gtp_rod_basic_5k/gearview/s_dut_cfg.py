import s_inf
import xml.etree.ElementTree as et

class S_Dut_Cfg(object):
    def __init__(self):
        self.mgt = "10.0.0.1/22"
        self.username = "root"
        self.passwd = "12345"
        self.dut_type = 0
        self.inf = [s_inf.S_Inf() for i in range(4)]

    @staticmethod
    def get_dut_type(t):
        if 0 == t:
            return "standalone"
        return "ha"

    @staticmethod
    def name():
        return "Dut"

    def from_xml(self, root):
        if None == root:
            return

        self.mgt = root.find("mgt").text
        self.username = root.find("username").text
        self.passwd = root.find("passwd").text
        dut_type = root.find("type").text
        if S_Dut_Cfg.get_dut_type(0)  == dut_type:
            self.dut_type = 0
        else:
            self.dut_type = 1

        ifs = root.findall(s_inf.S_Inf.name())
        for i in range(len(ifs)):
            self.inf[i].from_xml(ifs[i])

    def dump(self):
        print "%s:"%S_Dut_Cfg.name()
        print S_Dut_Cfg.get_dut_type(self.dut_type)
        print self.mgt
        print self.username
        print self.passwd
        for i in range(len(self.inf)):
            print "%d"%i
            self.inf[i].dump()


