#!/usr/bin/python
import string, glob, os, sys
import s_project
import datetime
sys.path.append("../")
import s_net_toolkit as s_net
import s_base_toolkit
import s_ip, s_eth, ipaddr, s_dut
import s_socket_daemon
import socket
import struct
import time

#sd = s_socket_daemon.S_Socket_Daemon(eth, s_ip.sctp)
#enter_demo()

log = s_base_toolkit.S_Log(datetime.datetime.now().strftime("logs/Dut%Y-%m-%d_%H-%M-%S.log"))
eth = [s_eth.S_Eth(), s_eth.S_Eth()]
dut = s_dut.Dut("", 0, log)

def set_static_route(project):
    session_lst = project.session_lst
    dut_cfg = project.topo_cfg.dut

    for s in session_lst:
        if not s.selected:
            continue

        addr = ipaddr.IPAddress(s.wing[0].dst_ep.ip)
        print "set routing-options static route %s  next-hop %s"%(str(addr), dut_cfg.inf[1].ip)
        addr = ipaddr.IPAddress(s.wing[1].dst_ep.ip)
        print "set routing-options static route %s  next-hop %s"%(str(addr), dut_cfg.inf[0].ip)

def main():
    global eth, dut
    if len(sys.argv) != 2:
        print "Usage: runner.py script-name"
        return

    project = s_project.S_Project()
    project.read(sys.argv[1])

    tester = project.topo_cfg.tester
    dut_cfg = project.topo_cfg.dut
    mgt_ip_port = dut_cfg.mgt.split("\\")

    dut = s_dut.Dut(mgt_ip_port[0], string.atoi(mgt_ip_port, 10))

    for i in range(2):
        eth[i].set_mac(tester.inf[i].mac, dut_cfg.inf[i].mac)
        eth[i].set_inf(tester.inf[i].name)

    set_static_route(project)

if "__main__" == __name__:
    main()
