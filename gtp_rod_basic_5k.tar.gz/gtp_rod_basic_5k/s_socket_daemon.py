#!/usr/bin/python
import string, glob, os
import s_net_toolkit as s_net
import s_eth, s_ip
import multiprocessing
import time
import s_socket
import s_pcap

def create(eths, proto):
    return S_Socket_Daemon(eths, proto)

class S_Socket_Daemon:
    # init daemon with the inpur eth array
    def __init__(self, eths, proto):
        # interface
        self.eths = eths
        # Initialze filter
        self.proto = proto

    # send packet to peer endpoint
    def send(self, eth):
        buf = eth.to_buffer()
        #print "send %d through %s"%(len(buf), eth.get_inf())

        s = self.s_map[eth.get_inf()]
        if not s.send(buf):
            print "Packet send failure"
            return False
        return True

    # daemon on the interface
    def read_and_queue(self, index):
        print "recv:%s"%self.eths[index].inf
        eth = self.eths[index]
        pcap = s_pcap.S_Pcap()

        #"tcpdump proto 132 and ether dst 01:02:03:04:05:06 -s 0 -dd"
        #"tcpdump -i eth1 \(ip6 protochain 17 or ip proto 17\) and ether dst 00:50:56:ac:00:68"
        if not pcap.open(eth.get_inf(), "(ip proto %d or ip6 protochain %d) and ether dst %s"%(self.proto, self.proto, s_net.mac_b2str(eth.src_mac))):
            print "Bad socket"
            return
            
        exit_event = self.exit_map[eth.get_inf()]
        while not exit_event.is_set():
            msg = pcap.recv() 
            if 0 == len(msg): 
                #print "%s Error:%d"%(eth.get_inf(), 0)
                continue
            #print "receive something from %s, msg len is %d"%(eth.get_inf(), len(msg))
            self.q[index].put(msg)

        pcap.close()

    def recv(self, eth, TIMEOUT = 3):
        try:
            self.buff = self.q_map[eth.get_inf()].get(True, TIMEOUT)
            return True
        except Exception, e:
            self.errmsg = "receiving packet is timeout."
        return False

    def startup(self):
        # queue for each eth 
        self.q = [multiprocessing.Queue() for i in range(len(self.eths))]
        # daemon for each eth
        self.d = [multiprocessing.Process(target = self.read_and_queue, args = (i,)) for i in range(len(self.eths))]

        # initialzie daemon and sockets
        for i in range(0, len(self.eths)):
            self.d[i].daemon = True

        # initialzie queue map and socket map
        self.q_map = {}
        self.s_map = {}
        self.exit_map = {}
        for i in range(0, len(self.eths)):
            self.q_map[self.eths[i].get_inf()] = self.q[i]
            self.s_map[self.eths[i].get_inf()] = s_socket.S_Socket()
            self.exit_map[self.eths[i].get_inf()] = multiprocessing.Event()

        for eth in self.eths:
            print "open :%s"%eth.inf
            self.exit_map[eth.get_inf()].clear()
            self.s_map[eth.get_inf()].open(eth.get_inf())

        for d in self.d:
            d.start()

    def shutdown(self):
        # close send socket
        for eth in self.eths:
            self.s_map[eth.get_inf()].close()
            self.exit_map[eth.get_inf()].set()
            print "shutdown:%s"%eth.get_inf

        # waiting and close daemon
        for d in self.d:
            d.join()

    def dump_queue(self):
        i = 0
        for q in self.q:
            print "%d[%s]:%d"%(i, self.eths[i].get_inf(), q.qsize())
            i += 1

    def clear_queue(self):
        for q in self.q:
            while 0 != q.qsize():
                try:
                    q.get(True)
                except Exception, e:
                    print repr(e)
                    break

    # send packet to file
    def send_to_pcap(self, filename, eth):
        try:
            s_net.buff2pcap(eth.to_buffer(), filename)
        except Exception, e:
            print "Please check whether text2pcap has been installed."

    def send_to_file(self, fout, eth):
        try:
            s_net.print_buff2txt(eth.to_buffer(), fout)
        except Exception, e:
            print "Failed to print to a text."


