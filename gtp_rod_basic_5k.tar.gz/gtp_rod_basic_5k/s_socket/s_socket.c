#include <stdio.h>
#include <sys/socket.h>
#include <netpacket/packet.h>
#include <net/if.h>
#include <linux/if_ether.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <net/if_arp.h>
#include <string.h>
#include <sys/types.h>
#include <asm/types.h>
#include <linux/filter.h>
#include <sys/ioctl.h>
//#include <pcap.h>
#include "s_socket.h"

#define RETRY_TIMES             4

static size_t strlcpy(char *, const char *, size_t);
static int get_iface_index(int fd, const int8_t *device, char *errbuf);

int  s_recv_packet(int s, u_char *data, size_t rd_len)
{
    if (NULL == data)
        return -1;

    return (int)recv(s, (void*)data, rd_len, 0);
}

int s_send_packet(int s, const u_char *data, size_t len)
{
    int retcode;
        
    if (NULL == data || len <= 0 || s < 0)
        return -1;
                
    int retry_times = RETRY_TIMES;

    while (retry_times > 0)
    {
        retcode = (int)send(s, (void *)data, len, 0);
        /* out of buffers, or hit max PHY speed, silently retry */
        if (retcode >= 0) {
            break;
        }
        
        retry_times--;
    } 

    return retcode;
}

void s_close_socket(int s)
{
    close(socket);
}

static void 
init_the_filter(struct sock_fprog *s_filter, const char* mac, unsigned int eth_type, unsigned int proto)
{
    unsigned char*  p;
    char*           m;
    char            mac_buf[24];
    int             i = 0;

    memcpy(mac_buf, mac, 24);

    ((unsigned char*)&s_filter->filter[1].k)[0] = eth_type;
    ((unsigned char*)&s_filter->filter[1].k)[1] = (eth_type >> 8);
    ((unsigned char*)&s_filter->filter[3].k)[0] = proto;

    m = mac_buf;

    // set mac_h
    p = (unsigned char*)&s_filter->filter[7].k;
    for (i = 1; i >= 0; i--) {
        m[3] = '\0';
        p[i] = atoi(m);
        m += 4;
    }

    // set mac_l
    p = (unsigned char*)&s_filter->filter[5].k;
    for (i = 3; i >= 0; i--) {
        m[3] = '\0';
        p[i] = atoi(m);
        m += 4;
    }

#ifdef DEBUG
    printf("********\nethtype:0x%0x\nproto:0x%0x\nmac_h:0x%0x\nmac_l:0x%0x\n********\n",
            s_filter->filter[1].k,
            s_filter->filter[3].k,
            s_filter->filter[7].k,
            s_filter->filter[5].k);
#endif
}

// tcpdump proto 132 and ether dst 01:02:03:04:05:06 -s 0 -dd
int s_set_filter(int s, const char* mac, unsigned int eth_type, unsigned int proto)
{
    struct sock_filter BPF_code[]= {
            { 0x28, 0, 0, 0x0000000c },
            { 0x15, 0, 7, 0x00000800 }, // eth type
            { 0x30, 0, 0, 0x00000017 },
            { 0x15, 0, 5, 0x00000084 }, // protocol
            { 0x20, 0, 0, 0x00000002 },
            { 0x15, 0, 3, 0x568f033b }, // mac-low
            { 0x28, 0, 0, 0x00000000 },
            { 0x15, 0, 1, 0x00000050 }, // mac-high
            { 0x6, 0, 0, 0x0000ffff },  // By default, recevied packet size will be limited to 0x60, now delete this limition.
            { 0x6, 0, 0, 0x00000000 }}; 

    struct sock_fprog s_filter; 
    s_filter.len = 10;
    s_filter.filter = BPF_code;

    init_the_filter(&s_filter, mac, eth_type, proto);

#ifdef DEBUG
    printf("set filter...\n");
#endif

    /* Attach the filter to the socket */
    return setsockopt(s, SOL_SOCKET, SO_ATTACH_FILTER, &s_filter, sizeof(struct sock_fprog));
}

int s_set_recv_timeout(int s, unsigned int timeout_sec)
{
    struct  timeval tv;
    tv.tv_sec = timeout_sec;
    tv.tv_usec = 0;
    return setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, (char*)&tv, sizeof(struct timeval));
}

int s_open_socket(const char* device, char* errbuf)
{
    int mysocket;
    //sendpacket_t /sp;
    struct ifreq ifr;
    struct sockaddr_ll sa;
    int n = 1, err;
    socklen_t errlen = sizeof(err);

   
    // open our socket //
    if ((mysocket = socket(PF_PACKET, SOCK_RAW, htons(ETH_P_ALL))) < 0) {
        snprintf(errbuf, ERRBUF_SIZE, "socket: %s", strerror(errno));
        return errno;
    }

    //memset(&sa, 0, sizeof(sa)); 
    // get the interface id for the device //
    if ((sa.sll_ifindex = get_iface_index(mysocket, device, errbuf)) < 0) {
        close(mysocket);
        return -1; 
    }

    // bind socket to our interface id //
    sa.sll_family = AF_PACKET;
    sa.sll_protocol = htons(ETH_P_ALL);
    if (bind(mysocket, (struct sockaddr *)&sa, sizeof(sa)) < 0) {
        snprintf(errbuf, ERRBUF_SIZE, "bind error: %s", strerror(errno));
        close(mysocket);
        return -1;
    }

#ifdef DEBUG
    printf("ifindex = %d\n", sa.sll_ifindex);
#endif
    
    // check for errors, network down, etc... //
    if (getsockopt(mysocket, SOL_SOCKET, SO_ERROR, &err, &errlen) < 0) {
        snprintf(errbuf, ERRBUF_SIZE, "error opening %s: %s", device, 
                strerror(errno));
        close(mysocket);
        return -1;
    }
    
    if (err > 0) {
        snprintf(errbuf, ERRBUF_SIZE, "error opening %s: %s", device, 
                strerror(err));
        close(mysocket);
        return -1;
    }

    // get hardware type for our interface //
    memset(&ifr, 0, sizeof(ifr));
    strlcpy(ifr.ifr_name, device, sizeof(ifr.ifr_name));
    
    if (ioctl(mysocket, SIOCGIFHWADDR, &ifr) < 0) {
        close(mysocket);
        snprintf(errbuf, ERRBUF_SIZE, "Error getting hardware type: %s", strerror(errno));
        return -1;
    }

    // make sure it's not loopback (PF_PACKET doesn't support it) //
    if (ifr.ifr_hwaddr.sa_family != ARPHRD_ETHER) {
        warnx("Unsupported physical layer type 0x%04x on %s.  Maybe it works, maybe it wont."
        "  See tickets #123/318", ifr.ifr_hwaddr.sa_family, device);
    }

    
//#ifdef SO_BROADCAST
//    //
//     / man 7 socket
//     /
//     / Set or get the broadcast flag. When  enabled,  datagram  sockets
//     / receive packets sent to a broadcast address and they are allowed
//     / to send packets to a broadcast  address.   This  option  has no
//     / effect on stream-oriented sockets.
//     // 
//    if (setsockopt(mysocket, SOL_SOCKET, SO_BROADCAST, &n, sizeof(n)) == -1) {
//        snprintf(errbuf, ERRBUF_SIZE,
//                "SO_BROADCAST: %s\n", strerror(errno));
//        close(mysocket);
//        return -1;
//    }
//#endif  //  SO_BROADCAST  //
//   
 
    // prep & return our sp handle //
    //sp = (sendpacket_t /)safe_malloc(sizeof(sendpacket_t));
    //strlcpy(sp->device, device, sizeof(sp->device));
    //sp->handle.fd = mysocket;
    //sp->handle_type = SP_TYPE_PF_PACKET;*/
    
    return mysocket;
}


/*
 *  * Copy src to string dst of size siz.  At most siz-1 characters
 *   * will be copied.  Always NUL terminates (unless siz == 0).
 *    * Returns strlen(src); if retval >= siz, truncation occurred.
 *     */
static size_t
strlcpy(char *dst, const char *src, size_t siz)
{
    char *d = dst;
    const char *s = src;
    size_t n = siz;
    /* Copy as many bytes as will fit */
    if (n != 0 && --n != 0) {
        do {
            if ((*d++ = *s++) == 0)
            break;
        } while (--n != 0);
    }
    /* Not enough room in dst, add NUL and traverse rest of src */
    if (n == 0) {
        if (siz != 0)
        *d = '\0';                /* NUL-terminate dst */
        while (*s++);
    }
    return(s - src - 1);        /* count does not include NUL */
}

// get the interface index (necessary for sending packets w/ PF_PACKET) 
static int 
get_iface_index(int fd, const int8_t *device, char *errbuf) 
{
    struct ifreq ifr;

    memset(&ifr, 0, sizeof(ifr));
    strlcpy(ifr.ifr_name, device, sizeof(ifr.ifr_name));

    if (ioctl(fd, SIOCGIFINDEX, &ifr) == -1) {
        snprintf(errbuf, ERRBUF_SIZE, "ioctl SIOCGIFINDEX: %s", strerror(errno));
        return (-1);
    }

    return ifr.ifr_ifindex;
}              



