#ifndef __S_SOCKET_H
#define __S_SOCKET_H

#define ERRBUF_SIZE     1024
#define SEND_BUFF_SIZE  4096 
#define RECV_BUFF_SIZE  4096 

#define DEBUG           0


extern int  s_send_packet(int s, const u_char *data, size_t len);
extern int  s_recv_packet(int s, u_char *data, size_t len);
extern void s_close_socket(int s);
extern int  s_open_socket(const char* device, char* errbuf);
#endif
