#include <stdio.h>
#include <sys/socket.h>
#include <fcntl.h>
#include <netpacket/packet.h>
#include <net/if.h>
#include <linux/if_ether.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <net/if_arp.h>
#include <string.h>
#include <sys/types.h>
#include <pcap.h>
#include "s_socket.h"

typedef unsigned int    uint32_t;
typedef unsigned char   uint8_t;

typedef struct s_pkt_hdr_
{
    int         inf_id;
    uint32_t    pkt_len;
    uint8_t*    pkt;
} s_pkt_hdr_t;

char*       inf_name[] = {"eth0", "eth1", "eth2", "eth3", "eth4"};
int         inf[sizeof(inf_name)];

char        errbuf[ERRBUF_SIZE];
uint8_t     send_buffer[SEND_BUFF_SIZE]; 

enum
{
    S_OK = 0,
    S_FAILURE,
    S_EOF
};

int read_packet(int fin, s_pkt_hdr_t* pkt_hdr)
{
    int ret = read(fin, &pkt_hdr->inf_id, sizeof(pkt_hdr->inf_id));
    //printf("ret = %d,inf_id = %d\n", ret, pkt_hdr->inf_id);

    if (ret != sizeof(pkt_hdr->inf_id)) {
        printf("read inf_id failure, error=%d\n", ret); 
        return S_FAILURE;
    }

    if (-1 == pkt_hdr->inf_id)
        return S_EOF;

    if (pkt_hdr->inf_id >= sizeof(inf_name)) {
        printf("inf doesn't exist, inf_id=%u\n", pkt_hdr->inf_id); 
        return S_FAILURE;
    }

    ret = read(fin, &pkt_hdr->pkt_len, sizeof(pkt_hdr->pkt_len));

    if (ret != sizeof(pkt_hdr->pkt_len)) {
        printf("read pkt_len failure, error=%d\n", ret); 
        return S_FAILURE;
    }

    //printf("ret = %d,pkt_len = %d\n", ret, pkt_hdr->inf_id);
    if (pkt_hdr->pkt_len > SEND_BUFF_SIZE) {
        printf("pkt_len exceeds read buffer, pkt_len=%u,send_buffer=%d\n", 
               pkt_hdr->pkt_len, SEND_BUFF_SIZE); 
        return S_FAILURE;
    }

    ret = read(fin, send_buffer, pkt_hdr->pkt_len);
    if (ret != pkt_hdr->pkt_len) {
        printf("read pkt failure, error=%d\n", ret); 
        return S_FAILURE;
    }

    pkt_hdr->pkt = send_buffer;

    
    return S_OK;
}

void init_inf(void)
{
    int i = 0;
    for (i = 0; i < sizeof(inf_name) / sizeof(int); i++) {
        inf[i] = s_open_socket(inf_name[i], errbuf);
        if (-1 == inf[i]) {
            printf("open socket at %s is failure:%s", inf_name[i], errbuf);
        }
    }
}

void uninit_inf(void)
{
    int i = 0;
    for (i = 0; i < sizeof(inf_name) / sizeof(int); i++) {
        if (inf[i] != 1)
            s_close_socket(inf[i]);
    }
}

int main(int argc, char *argv[])
{
    s_pkt_hdr_t pkt_hdr;

    if (argc != 2) {
        printf("cmd packet_file_name\n");
        return 0;
    }

    int fin = open(argv[1], O_RDONLY, "rb");
    if (0 == fin) {
        printf("Open file %s failure:%s", argv[2], errbuf);
        return 0;
    }

    init_inf();

    int ret = 0;
    while (S_OK == (ret = read_packet(fin, &pkt_hdr))) {
        //printf("inf_id=%d,pkt_len=%d\n", pkt_hdr.inf_id, pkt_hdr.pkt_len);
        printf(".");
        if (s_send_packet(inf[pkt_hdr.inf_id], pkt_hdr.pkt, pkt_hdr.pkt_len) <= 0) {
            printf("send failure:%d\n", pkt_hdr.pkt_len);
            break;
        }
    }

    if (ret != S_EOF)
        printf("some errors cause sending paket failure.");

    printf("finished..\n");

    uninit_inf();
    close(fin);

    return 0;
}
