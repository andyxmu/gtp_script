#include <pcap.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

/* default snap length (maximum bytes per packet to capture). */
#define SNAP_LEN 4096 

typedef struct s_pcap_
{
    pcap_t*     pcap;               /* packet capture handle */
    struct      bpf_program fp;     /* compiled filter program (expression) */
    bpf_u_int32 mask;		    /* mask */
} s_pcap_t;

void* s_open_pcap(const char* dev, const char* filter_exp, char* errbuf)
{
    s_pcap_t*   handle;                 /* packet capture handle */
    int         promisc = 1;            /* disable promisc */

#ifdef DEBUG
    printf("Device: %s\n", dev);
#endif

    handle = malloc(sizeof(s_pcap_t));
    if (!handle) {
        fprintf(stderr, "Couldn't alloc s_pcap:%s: %s\n", dev, errbuf);
        return NULL;
    }
    memset(handle, 0, sizeof(s_pcap_t));
    //handle->mask = 0xffffffff;//PCAP_NETMASK_UNKNOWN; 

    handle->pcap = pcap_open_live(dev, SNAP_LEN, promisc, 1000, errbuf);
    if (handle->pcap == NULL) {
        fprintf(stderr, "Couldn't open device %s: %s\n", dev, errbuf);
        goto free_handle;
    }

    /* make sure we're capturing on an Ethernet device [2] */
    if (pcap_datalink(handle->pcap) != DLT_EN10MB) {
        fprintf(stderr, "%s is not an Ethernet\n", dev);
        goto free_pcap;
    }

    /* compile the filter expression */
    if (pcap_compile(handle->pcap, &handle->fp, (char*)filter_exp, 0, handle->mask) == -1) {
        fprintf(stderr, "Couldn't parse filter %s: %s\n",
                filter_exp, pcap_geterr(handle->pcap));
        goto free_pcap;
    }

    /* apply the compiled filter */
    if (pcap_setfilter(handle->pcap, &handle->fp) == -1) {
        fprintf(stderr, "Couldn't install filter %s: %s\n",
                filter_exp, pcap_geterr(handle->pcap));
        goto free_all;
    }

    return (void*)handle;

free_all:
    pcap_freecode(&handle->fp);
free_pcap:
    pcap_close(handle->pcap);
free_handle:
    free(handle);
    return NULL;
}

const char* s_recv_packet(void* handle, int* len)
{
    const char*         data = NULL;
    struct pcap_pkthdr  pkt_hdr;     /* packet header */ 

    if (!handle || !len)
        return NULL;

    data = pcap_next(((s_pcap_t*)handle)->pcap, &pkt_hdr); 
    *len = pkt_hdr.caplen;
    if (*len <= 0 || *len > SNAP_LEN) {
        *len = 0;
        return "";
    }
    return data;
}

void s_close_pcap(void* pcap)
{
    s_pcap_t* handle = (s_pcap_t*)pcap;

    pcap_freecode(&handle->fp);
    pcap_close(handle->pcap);
    free(handle);
}

//int main()
//{
//    char errbuff[512];
//    int p = s_open_pcap("eth2", "dst port 60000", errbuff);
//    int len = 0;
//
//    if (p == 0)
//        return -1;
//
//    const char* buff = s_recv_packet(p, &len);
//    if (len)
//        printf("Got something\n");
//    else
//        printf("Nothing here!\n");
//
//    s_close_pcap(p);
//    return 0;
//}
