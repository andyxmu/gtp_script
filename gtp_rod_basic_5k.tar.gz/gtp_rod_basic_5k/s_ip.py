import string, glob, os
import s_net_toolkit as s_net
import ipaddr, s_ip4, s_ip6

from ctypes import *
from struct import *

sctp = 132
udp = 17

class S_Ip:
    def __init__(self):
        self.proto = 0
        self.in_init = True
        self.set_ip("0.0.0.0", "0.0.0.0")
        self.in_init = False 
        self.payload = ""

    def set_payload(self, payload):
        self.ip.set_data_len(len(payload))
        self.payload = payload

    def set_ip(self, src_ip, dst_ip):
        s_ip = ipaddr.IPAddress(src_ip)
        d_ip = ipaddr.IPAddress(dst_ip)

        if s_ip.version != d_ip.version:
            raise TypeError("source ip and destination ip must be the same type, all ipv4 or ipv6.")

        if 4 == s_ip.version:
            self.ip = s_ip4.S_Ip4()
        else:
            self.ip = s_ip6.S_Ip6()

        self.ip.src_ip = s_ip
        self.ip.dst_ip = d_ip

        if 0 != self.proto:
            self.ip.set_proto(self.proto)

        if not self.in_init:
            print "IP:src=%s, dst=%s"%(repr(self.ip.src_ip), repr(self.ip.dst_ip))


    @property
    def src_ip(self):
        return self.ip.src_ip

    @property
    def dst_ip(self):
        return self.ip.dst_ip

    @property
    def  protocol(self):
        return self.ip.protocol

    def set_proto(self, proto):
        self.proto = proto
        self.ip.set_proto(proto)

    def to_buffer(self):
        return self.ip.to_buffer() + self.payload
        
    def from_buffer(self, b):
        if 0x60 == ord(b[0]) & 0xF0:
            self.ip = s_ip6.S_Ip6()
        elif 0x40 == ord(b[0]) & 0xF0:
            self.ip = s_ip4.S_Ip4()
        else:
            raise TypeError("It's not a valid ip header.")
        return self.ip.from_buffer(b) 

    def dump(self):
        self.ip.dump()
                

def test_v4():
    # v4 test
    ip = S_Ip()
    ip.set_ip("1.1.1.1", "2.2.2.2")
    ip.set_payload("1234578")
    buf = ip.to_buffer()
    ip.dump()
    print int(ip.src_ip)

    ip2 = S_Ip()
    ip2.from_buffer(buf)
    ip2.dump()
    print "len=%d\n"%len(buf)
    print buf

def test_v6():
    # v6 test
    ip = S_Ip()
    ip.set_ip("::1.1.1.100", "::2.2.2.200")
    ip.set_payload("1234578")
    buf = ip.to_buffer()
    ip.dump()

    print "len=%d\n"%len(buf)
    ip2 = S_Ip()
    ip2.from_buffer(buf)
    print repr(ip2.ip.src_ip)
    print repr(ip2.ip.dst_ip)
    ip2.dump()



def main():
    print "v4 test:"
    test_v4()

    print "v6 test"
    test_v6()
    
    
if "__main__" == __name__:
    main()
